# iTron Distributed Intelligence — deployed source export

This archive contains the complete tracked source code for deployed version 20.

- Site: https://ppgui.com
- Sites origin: https://di.n2wm787gnp.chatgpt.site
- Source commit: a0918f480aa7ced05fee704d100cb0cd0add9d73
- Deployment status: succeeded (verified October 1, 2026, Pacific time)

The `itron-distributed-intelligence/` directory is an exact export of that commit.
It includes application source, supplied/repackaged data, assets, tests, dependency
lockfile, server routes, and the Edge Agent and Gateway Agent runtimes.
Git history, node_modules, build output, and local environment secrets are not included.

## Run locally

Use Node.js 22.12 or later and npm. From the source directory:

```sh
npm ci
npm run dev -- --port 5174
```

Open http://127.0.0.1:5174 in a browser.

```sh
npm test
npm run build
```

See README.md for numerical test prerequisites and data provenance. See
edge/README.md and gateway/README.md for the standalone agent interfaces.
Browser analysis downloads the pinned Pyodide runtime and numerical packages on first use.

For Google Maps / Street View, configure your MAPS_EMBED_KEY separately in
an ignored .env.local for development or your host's runtime environment.
Production runtime secrets are intentionally not copied into this source export.

The .openai/hosting.json file retains the existing Sites project association.
Exporting this code did not change or redeploy the website.
