"""Numerical run-book regression checks against the exact published bundle."""
import os
os.environ['MULTICONDUCTOR_DISABLE_NUMBA'] = '1'
import gzip, hashlib, importlib.util, json, pickle, sys, tempfile, zipfile
from copy import deepcopy
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as directory:
    with zipfile.ZipFile(ROOT/'public/powerflow/multiconductor.zip') as archive:
        archive.extractall(directory)
    sys.path.insert(0, directory)
    spec = importlib.util.spec_from_file_location('study_adapter', ROOT/'public/analysis/runner.py')
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    raw = gzip.decompress((ROOT/'public/powerflow/models/p3rhs1_1247--p3rdt1322.pkl.bin').read_bytes())
    original_hash = hashlib.sha256(raw).hexdigest()
    defaults = {k: {f['key']: f['value'] for f in v['fields']} for k, v in runner.DEFINITIONS.items()}
    results = {}
    for kind, settings in defaults.items():
        result = runner.run_analysis(raw, kind, settings)
        assert result['completed'] and isinstance(result['converged'], bool), kind
        json.dumps(result, allow_nan=False)
        results[kind] = result
        print(kind, result['message'], flush=True)
    assert results['power_flow']['solved']
    assert results['short_circuit']['metrics'][1]['value'] > 0
    resistive = runner.run_analysis(raw, 'short_circuit', {**defaults['short_circuit'], 'fault_r_ohm': 1})
    assert resistive['metrics'][1]['value'] < results['short_circuit']['metrics'][1]['value']
    assert results['protection']['metrics'][3]['value'] == .02
    assert len(results['contingency']['tables']['cases']) == 1
    assert not results['optimal_power_flow']['converged']
    assert results['optimal_power_flow']['tables']['capability_exceedances']
    assert results['grid_equivalent']['converged']
    assert results['grid_equivalent']['tables']['validation'][0]['current_mismatch_max'] < 1e-6
    allocated = runner.run_analysis(raw, 'load_allocation', {**defaults['load_allocation'], 'target_scale': 1.1})
    assert allocated['converged'] and abs(allocated['metrics'][2]['value']) <= .5
    assert allocated['metrics'][3]['value'] > 0
    scan = results['hosting_capacity']['tables']['capacity_scan']
    assert len(scan) == 11 and all(row['feasible'] for row in scan)
    constrained = runner.run_analysis(raw, 'hosting_capacity', {**defaults['hosting_capacity'], 'max_vm_pu': 1.0319})
    assert 0 < constrained['metrics'][0]['value'] < constrained['metrics'][1]['value'] < 2
    # An unused open-tie terminal can be omitted; an attached isolated load cannot.
    net = pickle.loads(raw)
    runner.mc.run_pf(net, run_control=False)
    screened, omitted = runner.hosting_voltage_rows(net)
    assert len(omitted) == 3 and np.isfinite(screened.vm_pu).all()
    runner.mc.create_asymmetric_load(net, bus=527, from_phase=1, to_phase=0, p_mw=.01, q_mvar=.003)
    screened, _ = runner.hosting_voltage_rows(net)
    assert (527, 1) in screened.index and not np.isfinite(screened.loc[(527, 1), 'vm_pu'])
    assert hashlib.sha256(raw).hexdigest() == original_hash
    print('All numerical analysis checks passed.', flush=True)
