"""Native parity checks for the exact browser adapter and bundled solver.

Run with numpy/scipy/pandas/pandapower installed and
MULTICONDUCTOR_DISABLE_NUMBA=1 to use the same kernels as Pyodide.
"""
import gzip
import importlib.util
import json
from pathlib import Path
import pickle
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'public/powerflow/multiconductor.zip'))
import numpy as np
import multiconductor as mc
from multiconductor.pycci.state_estimator import extract_se_matrices, UnobservableNetworkError
spec = importlib.util.spec_from_file_location('browser_estimation', ROOT / 'public/state-estimation/runner.py')
adapter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(adapter)
OPTIONS = dict(source='synthetic', tol=1e-6, objective_tol=1e-10, max_iter=50,
               bad_data_threshold=4, max_bad_data=0, sigma=.0005,
               sigma_power=.001, noise=True, seed=42)

def model_bytes(circuit):
    return gzip.decompress((ROOT / f'public/powerflow/models/{circuit}.pkl.bin').read_bytes())

class BrowserEstimatorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = model_bytes('p3rhs1_1247--p3rdt1205')
        net = pickle.loads(cls.raw)
        mc.run_pf(net, tol_vmag_pu=1e-7, tol_vang_rad=1e-7, MaxIter=100, run_control=False)
        model = extract_se_matrices(net)
        voltage = np.asarray(net.model.E).reshape(-1)
        variable, covered, rows = set(model.variable_nodes), set(), []
        for bus, phase in net.bus.index:
            node = int(net.model.terminal_to_y_lookup[int(bus)*4+int(phase)])
            if node not in variable or node in covered:
                continue
            covered.add(node)
            for kind, value in [('vr', voltage[node].real), ('vi', voltage[node].imag)]:
                rows.append(dict(measurement_type=kind,element_type='bus',element=int(bus),
                                 phase=int(phase),value=float(value),std_dev=.0005))
        cls.rows = rows
        cls.baseline_voltage = net.res_bus.vm_pu.copy()

    def test_noisy_measurements_are_actually_estimated(self):
        result = adapter.run_estimation(model_bytes('p3rhs1_1247--p3rdt1322'), OPTIONS)
        self.assertTrue(result['converged'])
        self.assertEqual(result['measurement_count'], 5410)
        self.assertEqual(result['state_count'], 2164)
        self.assertEqual(result['observability_rank'], 2164)
        self.assertAlmostEqual(result['voltage_min'], .9895441, places=6)
        self.assertAlmostEqual(result['chi_square'], 3188.8188, places=2)
        self.assertGreater(result['p_value'], .6)
        self.assertTrue(any(abs(row['residual'] or 0) > 1e-5 for row in result['tables']['res_measurement']))
        json.dumps(result, allow_nan=False)

    def test_import_has_no_power_flow_and_responds_to_changed_observations(self):
        options = {**OPTIONS, 'source':'import'}
        changed = [dict(row) for row in self.rows]
        changed[0]['value'] += .002
        with patch.object(mc, 'run_pf', side_effect=AssertionError('Import must not run power flow')):
            original = adapter.run_estimation(self.raw, options, self.rows)
            perturbed = adapter.run_estimation(self.raw, options, changed)
        self.assertTrue(original['converged'])
        self.assertTrue(perturbed['converged'])
        self.assertEqual(original['degrees_of_freedom'], 0)
        self.assertIsNone(original['p_value'])
        first = lambda r: next(row['vm_pu'] for row in r['tables']['res_bus'] if row['index']==self.rows[0]['element'] and row['phase']==self.rows[0]['phase'])
        self.assertGreater(abs(first(perturbed)-first(original)), .001)
        self.assertEqual(original['measurement_source'], 'import')
        json.dumps(perturbed, allow_nan=False)

    def test_incomplete_measurements_are_not_observable(self):
        with self.assertRaises(UnobservableNetworkError):
            adapter.run_estimation(self.raw, {**OPTIONS,'source':'import'}, self.rows[:2])

    def test_nonconvergence_and_missing_model_measurements_are_explicit(self):
        result = adapter.run_estimation(model_bytes('p3rhs1_1247--p3rdt1322'), {**OPTIONS,'max_iter':1})
        self.assertFalse(result['converged'])
        self.assertFalse(result['solved'])
        with self.assertRaisesRegex(ValueError, 'no measurement rows'):
            adapter.run_estimation(self.raw, {**OPTIONS,'source':'model'})
        with self.assertRaises(ValueError):
            adapter.run_estimation(self.raw, {**OPTIONS,'sigma':0})

if __name__ == '__main__':
    unittest.main()
