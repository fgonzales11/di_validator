// Actual WASM integration test; provide a Pyodide 0.28.3 module path (see README).
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const {loadPyodide}=await import(pathToFileURL(resolve(process.argv[2])));
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { runForecast, MODEL_NAMES } from '../src/forecast-model.mjs';

const product = new URL('../', import.meta.url);
const began = performance.now();
const py = await loadPyodide({ packageCacheDir: process.env.PYODIDE_CACHE_DIR });
await py.loadPackage(['numpy', 'pandas', 'scikit-learn', 'micropip', 'tqdm', 'rich']);
const wheel = 'skforecast-0.22.0-py3-none-any.whl';
const wheelBytes = await fs.readFile(new URL('public/forecasting/'+wheel, product));
assert.equal(createHash('sha256').update(wheelBytes).digest('hex'), '75cb96b926d10d57a24b3cf86345d71e86e638cfb2aeb55005d054ecb6d41a31');
py.FS.writeFile('/home/pyodide/' + wheel, new Uint8Array(wheelBytes));
const runtimeSource=await fs.readFile(new URL('public/forecasting/runtime.mjs',product),'utf8');
const bootstrap=runtimeSource.match(/await py\.runPythonAsync\(`([\s\S]*?)`\);/)[1];
await py.runPythonAsync(bootstrap.replaceAll('${wheel}',wheel));
const source = await fs.readFile(new URL('public/forecasting/models.py', product));
const sourceSha256 = createHash('sha256').update(source).digest('hex');
py.FS.writeFile('/home/pyodide/forecast_models.py', new Uint8Array(source));
await py.runPythonAsync('from forecast_models import forecast_json');
const dependencies = JSON.parse(await py.runPythonAsync(`
import json, importlib.metadata
json.dumps({d.metadata['Name']:d.version for d in importlib.metadata.distributions()},sort_keys=True)
`));
const bootstrapSeconds = (performance.now() - began) / 1000;
let fits = 0;
const fitPredict = async payload => {
  fits++;
  py.globals.set('_forecast_payload', JSON.stringify(payload));
  try {
    const result = JSON.parse(await py.runPythonAsync('forecast_json(_forecast_payload)'));
    result.artifact.runtime = 'Pyodide 0.28.3 / WebAssembly';
    result.artifact.sourceSha256 = sourceSha256;
    if (payload.model === 'skforecast_boosting') {
      result.artifact.packageSha256 = createHash('sha256').update(wheelBytes).digest('hex');
      result.artifact.jit = 'Disabled: skforecast NumPy functions run without Numba JIT';
    }
    return result;
  } finally { py.globals.delete('_forecast_payload'); }
};
const models = Object.keys(MODEL_NAMES);
const config = { horizon:24, validationWindows:3, contextLength:168, seasonLength:24,
  lags:16, trees:20, maxDepth:6, minLeaf:2, seed:42, models };
const series = {
  timestamps:Array.from({length:400}, (_,i) => Date.UTC(2025,0,1) + i*3600000),
  values:Array.from({length:400}, (_,i) => 30+4*Math.sin(2*Math.PI*i/24)+2*Math.sin(2*Math.PI*i/168)+0.013*i+0.2*Math.cos(i*1.37)),
  channel:'load', unit:'kW', source:'Synthetic deterministic integration fixture', synthetic:true,
};
const timings = {};
async function run(name, data) {
  const start = performance.now();
  const result = await runForecast(data, config, { fitPredict, yieldControl:async()=>{} });
  timings[name] = (performance.now()-start)/1000;
  assert.deepEqual(result.models.map(m=>m.model),models);
  assert.ok(result.models.every(m=>m.status==='completed'), JSON.stringify(result.models.map(m=>({model:m.model,error:m.error}))));
  return result;
}
const base = await run('baseline',series);
assert.deepEqual(await run('deterministicRepeat',series),base);
const firstValidation = base.splits[0];
const validationPoison = structuredClone(series);
for(let i=firstValidation.testStartIndex;i<firstValidation.testEndIndexExclusive;i++) validationPoison.values[i]+=200+i%5;
const changedValidation = await run('validationPoison',validationPoison);
for (let i=0;i<models.length;i++) {
  assert.deepEqual(changedValidation.models[i].predictions.validation[0].prediction,base.models[i].predictions.validation[0].prediction,models[i]+' leaked validation target');
  assert.notDeepEqual(changedValidation.models[i].validation,base.models[i].validation,models[i]+' failed to score changed validation targets');
}
const holdoutPoison = structuredClone(series);
const holdoutSplit = base.splits.at(-1);
for(let i=holdoutSplit.testStartIndex;i<holdoutSplit.testEndIndexExclusive;i++) holdoutPoison.values[i]+=200+i%5;
const changedHoldout = await run('holdoutPoison',holdoutPoison);
assert.equal(changedHoldout.selectedModel,base.selectedModel);
for(let i=0;i<models.length;i++) {
  const original=base.models[i],changed=changedHoldout.models[i];
  assert.deepEqual(changed.validation,original.validation,models[i]+' leaked holdout into validation score');
  assert.deepEqual(changed.predictions.validation,original.predictions.validation,models[i]+' leaked holdout into validation prediction');
  assert.equal(changed.intervalRadius,original.intervalRadius,models[i]+' leaked holdout into interval calibration');
  for(const field of ['prediction','lower','upper']) assert.deepEqual(changed.predictions.holdout[field],original.predictions.holdout[field],models[i]+' leaked holdout into '+field);
  assert.notDeepEqual(changed.holdout,original.holdout,models[i]+' failed to score changed holdout');
  assert.notDeepEqual(changed.predictions.future.prediction,original.predictions.future.prediction,models[i]+' final refit ignored latest observations');
  assert.equal(original.artifact.trainedThrough,series.timestamps.at(-1));
  assert.equal(original.predictions.future.timestamps[0],series.timestamps.at(-1)+3600000);
  assert.ok(original.predictions.future.prediction.every(Number.isFinite));
  if(['random_forest','skforecast_boosting'].includes(models[i])) {
    assert.equal(original.artifact.trainedFrom,series.timestamps[232]);
    assert.equal(original.artifact.trainingRows,144);
    assert.deepEqual(original.artifact.lags,[...Array.from({length:16},(_,j)=>j+1),24]);
    assert.equal(original.artifact.sklearnVersion,'1.7.0');
    assert.equal(original.artifact.calendarBasis,'UTC');
    assert.equal(original.artifact.seed,42);
    assert.equal(original.artifact.sourceSha256,sourceSha256);
  }
  if(models[i]==='skforecast_boosting') {
    assert.equal(original.artifact.providerVersion,'0.22.0');
    assert.equal(original.artifact.parameters.early_stopping,false);
    assert.equal(original.artifact.estimator,'HistGradientBoostingRegressor');
  }
  if(models[i]==='random_forest') {
    assert.equal(original.artifact.parameters.n_jobs,1);
    assert.equal(original.artifact.estimator,'RandomForestRegressor');
    assert.ok(Math.abs(Object.values(original.artifact.featureImportances).reduce((s,v)=>s+v,0)-1)<1e-12);
  }
}
for(const model of ['random_forest','skforecast_boosting']) {
  const times=series.timestamps.slice(0,168),future=series.timestamps.slice(168,192);
  const zero=await fitPredict({model,config,values:Array(168).fill(0),times,future});
  assert.deepEqual(zero.prediction,Array(24).fill(0));
}
const report = {
  passed:true, runtime:'actual Pyodide 0.28.3 WebAssembly, Node v'+process.versions.node,
  sourceSha256, dependencies, bootstrapSeconds,timings,pythonFits:fits,
  assertions:['All four exact integrated models completed','Repeat fully deterministic','Validation targets excluded from their own fit','Holdout excluded from validation, selection, predictions and calibrated bands','Latest observed targets used in final future refit','Training endpoints and feature metadata correct','Both Python models predict exact constant zero'],
  selectedModel:base.selectedModel,
  models:base.models.map(m=>({model:m.model,validationMAE:m.validation.mae,holdoutMAE:m.holdout.mae,futureHead:m.predictions.future.prediction.slice(0,5),artifact:m.artifact})),
};
console.log(JSON.stringify({...report,models:report.models.map(({model,validationMAE,holdoutMAE})=>({model,validationMAE,holdoutMAE}))},null,2));
