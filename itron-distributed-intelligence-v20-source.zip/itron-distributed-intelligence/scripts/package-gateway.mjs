import {mkdtempSync,mkdirSync,copyFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {execFileSync} from 'node:child_process';
const root=new URL('../',import.meta.url),stage=mkdtempSync(join(tmpdir(),'itron-gateway-'));
try{for(const [from,to] of [['src/gateway-engine.mjs','gateway-engine.mjs'],['src/gateway-adapter.mjs','gateway-adapter.mjs'],['gateway/gateway-runner.mjs','gateway-runner.mjs'],['gateway/README.md','README.md']])copyFileSync(new URL(from,root),join(stage,to));mkdirSync(new URL('public/gateway',root),{recursive:true});execFileSync('tar',['-czf',new URL('public/gateway/gateway-runtime.tar.gz',root).pathname,'-C',stage,'README.md','gateway-engine.mjs','gateway-adapter.mjs','gateway-runner.mjs']);console.log('Packaged dependency-free gateway runtime.')}finally{rmSync(stage,{recursive:true,force:true})}
