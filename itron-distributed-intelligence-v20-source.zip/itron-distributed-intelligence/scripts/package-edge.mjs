import {mkdtempSync,mkdirSync,copyFileSync,rmSync,writeFileSync,statSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {execFileSync} from 'node:child_process';
import {EDGE_ENGINE_VERSION} from '../src/edge-quality.mjs';
const root=new URL('../',import.meta.url),stage=mkdtempSync(join(tmpdir(),'itron-edge-'));
const files=[['src/edge-quality.mjs','edge-quality.mjs'],['edge/edge-runner.mjs','edge-runner.mjs'],['edge/README.md','README.md'],['edge/example.ndjson','example.ndjson']];
try{
  for(const [from,to] of files)copyFileSync(new URL(from,root),join(stage,to));
  const directory=new URL('public/edge/',root),archive=new URL('edge-runtime.tar.gz',directory);
  mkdirSync(directory,{recursive:true});
  execFileSync('tar',['-czf',archive.pathname,'-C',stage,...files.map(([,to])=>to)]);
  const manifest={version:EDGE_ENGINE_VERSION,compressedBytes:statSync(archive).size,sourceBytes:files.filter(([,to])=>to.endsWith('.mjs')).reduce((sum,[from])=>sum+statSync(new URL(from,root)).size,0),maxNumericBufferBytes:65536,dependencies:0,runtime:'Node.js 22+'};
  writeFileSync(new URL('manifest.json',directory),JSON.stringify(manifest)+'\n');
  console.log(`Packaged Edge Agent runtime: ${manifest.compressedBytes} bytes compressed.`);
}finally{rmSync(stage,{recursive:true,force:true})}
