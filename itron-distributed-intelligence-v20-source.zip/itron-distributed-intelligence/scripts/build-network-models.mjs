// Small first-party technical symbols for Google Model3DElement. Dimensions in
// meters, authored Z-up (east, north, up) for the Maps model coordinate system.
// No textures, external resources, glTF extensions or runtime Three.js scene.
import {BoxGeometry,CylinderGeometry,Color} from 'three';
import {mkdir,writeFile} from 'node:fs/promises';
const root=new URL('../public/models/',import.meta.url);
await mkdir(root,{recursive:true});
const colors=['#a77947','#64747c','#d7e2e4','#238cac','#ffffff'];
function model(name,parts){
  const chunks=[],views=[],accessors=[],primitives=[];let byteLength=0;
  function attribute(array,type,componentType,limits=false){
    const bytes=Buffer.from(array.buffer,array.byteOffset,array.byteLength),view=views.length;
    views.push({buffer:0,byteOffset:byteLength,byteLength:bytes.length});chunks.push(bytes);byteLength+=bytes.length;
    if(byteLength%4){const pad=Buffer.alloc(4-byteLength%4);chunks.push(pad);byteLength+=pad.length}
    const count=array.length/(type==='VEC3'?3:1),accessor={bufferView:view,componentType,count,type};
    if(limits){accessor.min=[0,1,2].map(k=>Math.min(...Array.from({length:count},(_,i)=>array[i*3+k])));accessor.max=[0,1,2].map(k=>Math.max(...Array.from({length:count},(_,i)=>array[i*3+k])))}
    accessors.push(accessor);return accessors.length-1;
  }
  for(const {geometry,material} of parts){
    // Three primitives are Y-up; rotate into Maps Z-up before serialization.
    geometry.rotateX(Math.PI/2);
    primitives.push({attributes:{POSITION:attribute(geometry.attributes.position.array,'VEC3',5126,true),NORMAL:attribute(geometry.attributes.normal.array,'VEC3',5126)},indices:attribute(geometry.index.array,'SCALAR',5123),material});
  }
  const document={asset:{version:'2.0',generator:'iTron illustrative network geometry'},scene:0,scenes:[{nodes:[0]}],nodes:[{mesh:0}],meshes:[{name,primitives}],materials:colors.map(hex=>{const c=new Color(hex);return {pbrMetallicRoughness:{baseColorFactor:[c.r,c.g,c.b,1],metallicFactor:.05,roughnessFactor:.85},doubleSided:false}}),buffers:[{byteLength}],bufferViews:views,accessors};
  const raw=Buffer.from(JSON.stringify(document)),json=Buffer.alloc(Math.ceil(raw.length/4)*4,0x20);raw.copy(json);
  const binary=Buffer.concat(chunks),header=Buffer.alloc(12),jsonHeader=Buffer.alloc(8),binHeader=Buffer.alloc(8);
  header.writeUInt32LE(0x46546c67);header.writeUInt32LE(2,4);header.writeUInt32LE(28+json.length+binary.length,8);
  jsonHeader.writeUInt32LE(json.length);jsonHeader.writeUInt32LE(0x4e4f534a,4);binHeader.writeUInt32LE(binary.length);binHeader.writeUInt32LE(0x004e4942,4);
  return writeFile(new URL(name+'.glb',root),Buffer.concat([header,jsonHeader,json,binHeader,binary]));
}
const box=(x,y,z,w,h,d,material)=>({geometry:new BoxGeometry(w,h,d).translate(x,y,z),material});
const cylinder=(x,y,z,top,bottom,height,material)=>({geometry:new CylinderGeometry(top,bottom,height,8).translate(x,y,z),material});
for(const phases of [1,2,3]){
  const offsets=phases===3?[-1.5,0,1.5]:phases===2?[-1.5,1.5]:[0];
  const parts=[cylinder(0,5.25,0,.18,.3,10.5,0),box(0,9.85,0,phases===1?1:4.4,.25,.32,0),box(0,9.6,0,.5,.5,.43,1)];
  for(const x of offsets){parts.push(cylinder(x,10.2,0,.14,.14,.5,2),cylinder(x,10.06,0,.23,.23,.08,2),cylinder(x,10.23,0,.23,.23,.08,2),cylinder(x,10.4,0,.23,.23,.08,2))}
  await model('pole-'+phases,parts);
}
// T is explicitly a 3D symbol, not an assumed pole- or pad-mounted enclosure.
await model('transformer-symbol',[box(0,1.5,0,2.6,3,.4,3),box(0,2.25,.24,1.8,.35,.14,4),box(0,1.4,.24,.35,1.6,.14,4),box(0,2.25,-.24,1.8,.35,.14,4),box(0,1.4,-.24,.35,1.6,.14,4)]);
console.log('Wrote 3 pole variants and neutral transformer symbol.');
