import {build} from 'vite';
import {mkdir, copyFile, rm, readFile} from 'node:fs/promises';
await rm('dist', {recursive:true,force:true});
await build();
const pages={};
for(const base of ['', '/outage-analyzer', '/transformer-analyzer']){
  const html=await readFile('dist/client'+base+'/index.html','utf8');
  for(const path of [base||'/',base+'/',base+'/index.html'])pages[path]=html;
}
await build({configFile:false,define:{__CLIENT_PAGES__:JSON.stringify(pages)},publicDir:false,build:{ssr:'server/index.mjs',outDir:'dist/server',target:'es2022',rollupOptions:{output:{entryFileNames:'index.js'}}}});
await mkdir('dist/.openai',{recursive:true});
await copyFile('.openai/hosting.json','dist/.openai/hosting.json');
