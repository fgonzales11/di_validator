#!/usr/bin/env python3
"""Export the user's trusted SMARTDS PKLs into the static GridScope schemas.

Run using a Python environment with numpy/scipy/pandas/networkx/pandapower.
The bundled multiconductor code is used, never a balanced surrogate.
No source PKL is modified. Published models add CIRCUIT_ID=CIRCUIT_KEY only;
source SHA-256 and repackaged SHA-256 are retained separately.
"""
from __future__ import annotations
import argparse, collections, datetime, gzip, hashlib, json, math, os, pathlib, pickle, sys, time
os.environ.setdefault('MULTICONDUCTOR_DISABLE_NUMBA','1')
ROOT=pathlib.Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--source',type=pathlib.Path,required=True)
parser.add_argument('--solver',type=pathlib.Path,default=ROOT.parent/'public/powerflow/multiconductor.zip')
parser.add_argument('--output',type=pathlib.Path,default=ROOT.parent/'public')
args=parser.parse_args()
sys.path.insert(0,str(args.solver.resolve()))
import numpy as np
import pandas as pd
import networkx as nx
import multiconductor as mc

DEFAULT='p3rhs1_1247--p3rdt1322'
PARAMETERS=dict(tol_vmag_pu=1e-6,tol_vang_rad=1e-6,MaxIter=100,run_control=True)
START=int(datetime.datetime(2026,9,1,tzinfo=datetime.timezone.utc).timestamp()*1000)
END=int(datetime.datetime(2026,9,15,tzinfo=datetime.timezone.utc).timestamp()*1000)
solver_sha=hashlib.sha256(args.solver.read_bytes()).hexdigest()
output=args.output.resolve();(output/'data').mkdir(parents=True,exist_ok=True);(output/'powerflow/models').mkdir(parents=True,exist_ok=True)

def sha(value):return hashlib.sha256(value).hexdigest()
def f(value,digits=9):
    try:
        value=float(value)
        return round(value,digits) if math.isfinite(value) else None
    except (TypeError,ValueError):return None

def extent(values):
    clean=[float(v) for v in values if f(v) is not None]
    return (min(clean),max(clean)) if clean else (None,None)

def write(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n')

def active(table):return table[table.in_service.fillna(False).astype(bool)] if 'in_service' in table else table

def power(table,column):
    table=active(table)
    return float((table[column].fillna(0)*table.get('scaling',1)).sum())*1000

files=sorted(args.source.glob('*.pkl'),key=lambda p:(p.stem!=DEFAULT,p.stem))
if len(files)!=11:raise ValueError(f'Expected 11 supplied SMARTDS models, found {len(files)}')
# Source coordinates determine one shared metric projection for every view.
nets=[]
for p in files:
    raw=p.read_bytes();net=pickle.loads(raw)
    if str(net.get('CIRCUIT_KEY',p.stem))!=p.stem:raise ValueError(f'Circuit identity mismatch: {p}')
    geo=net.get('bus_geo',net.get('bus_geodata')).groupby(level=0,sort=False).first()
    if not np.isfinite(geo[['Longitude','Latitude']].to_numpy()).all():raise ValueError(f'Missing bus coordinates: {p}')
    nets.append((p,raw,net,geo))
default_geo=nets[0][3]
origin={'lon':float(default_geo.Longitude.mean()),'lat':float(default_geo.Latitude.mean())}
def project(lon,lat):return [round((float(lon)-origin['lon'])*111320*math.cos(math.radians(origin['lat'])),3),round(-(float(lat)-origin['lat'])*111320,3)]
def point(geo,bus):
    r=geo.loc[int(bus)];return project(r.Longitude,r.Latitude)

circuits=[];models=[];model_sources=[];base_circuits=[];txs=[];top_lines=[];top_buses=[];top_switches=[];top_transformers=[];top_generators=[];service_points=[];links={};model_profiles=[];load_inputs=[]
for order,(p,raw,net,geo) in enumerate(nets):
    circuit=p.stem;network=circuit;substation=circuit.split('--')[0];dt=circuit.split('--')[-1].removeprefix('p3rdt');title='P3R '+('HS0' if 'rhs0' in substation else 'HS1')+' · DT'+dt
    source_sha=sha(raw)
    # Preserve model electrical values and native IDs; set only the app identity alias.
    net['CIRCUIT_ID']=circuit
    bundled=pickle.dumps(net,protocol=4);bundled_sha=sha(bundled)
    compressed=gzip.compress(bundled,compresslevel=9,mtime=0)
    (output/'powerflow/models'/f'{circuit}.pkl.bin').write_bytes(compressed)
    print('Solving',circuit,flush=True);started=time.perf_counter();mc.run_pf(net,**PARAMETERS);seconds=time.perf_counter()-started
    if not net.model.solved:raise ValueError(f'Power flow did not converge: {circuit}')
    if not net.res_trafo.index.equals(net.trafo1ph.sort_index().index):raise ValueError(f'Winding result identities changed: {circuit}')
    phases=net.res_bus[net.res_bus.index.get_level_values('phase').isin([1,2,3])]
    energized=phases.vm_pu[np.isfinite(phases.vm_pu)&(phases.vm_pu>0)]
    cmin,cmax=extent(energized)
    bounds=[float(geo.Longitude.min()),float(geo.Latitude.min()),float(geo.Longitude.max()),float(geo.Latitude.max())]
    center=project(geo.Longitude.mean(),geo.Latitude.mean());corners=[project(bounds[0],bounds[1]),project(bounds[2],bounds[3])]
    span=max(abs(corners[0][0]-corners[1][0]),abs(corners[0][1]-corners[1][1]))
    bus_id=lambda bus:f'{network}/bus/{int(bus)}'
    tx_id=lambda index:f'{network}/trafo1ph/{int(index)}'
    for bus,location in geo.iterrows():
        x,z=project(location.Longitude,location.Latitude)
        top_buses.append({'id':bus_id(bus),'circuit':circuit,'latitude':float(location.Latitude),'longitude':float(location.Longitude),'x':x,'z':z})
    bus_groups=net.bus.groupby(level=0,sort=False)
    graph=nx.Graph();graph.add_nodes_from(int(b) for b in bus_groups.groups)
    for _,row in active(net.line).iterrows():graph.add_edge(int(row.from_bus),int(row.to_bus))
    for _,row in net.switch.iterrows():
        if row.et=='b' and bool(row.closed):graph.add_edge(int(row.bus),int(row.element))
    components={bus:i for i,nodes in enumerate(nx.connected_components(graph)) for bus in nodes}
    secondary_roots=collections.defaultdict(set);transformer_meta={}
    for idx,rows in net.trafo1ph.groupby(level=0,sort=False):
        ratings=rows.reset_index().groupby('bus',sort=False).vn_kv.max();high=float(ratings.max());low=float(ratings.min());regulator=abs(high-low)<1e-8
        buses=[int(b) for b in ratings.index]
        primary=[int(b) for b,v in ratings.items() if float(v)>=high-1e-8]
        secondary=[int(b) for b,v in ratings.items() if float(v)<high-1e-8]
        if regulator:
            primary=[buses[0]];secondary=buses[1:]
        else:
            for b in secondary:secondary_roots[components[b]].add(int(idx))
        transformer_meta[int(idx)]={'primary':primary,'secondary':secondary,'regulator':regulator,'high':high,'low':low,'buses':buses}
    # All known loads must have one exact connection, with no proximity assignment.
    loads_by_tx=collections.defaultdict(list);gens_by_tx=collections.defaultdict(list)
    circuit_points=[]
    for idx,rows in net.asymmetric_load.groupby(level=0,sort=False):
        buses=sorted(int(b) for b in rows.bus.unique());targets=set().union(*(secondary_roots[components[b]] for b in buses))
        if len(targets)!=1:raise ValueError(f'Ambiguous/unlinked load {circuit}/{idx}: {targets}')
        transformer_index=next(iter(targets));loads_by_tx[transformer_index].append(rows)
        bus=buses[0]
        if len(buses)!=1:raise ValueError(f'Load group spans multiple buses: {circuit}/{idx}')
        x,z=point(geo,bus);spid=f'{network}/load/{int(idx)}';target_id=tx_id(transformer_index)
        bus_rows=net.bus.xs(bus,level=0);result_bus=net.res_bus.xs(bus,level=0);result_phases=result_bus[result_bus.index.isin([1,2,3])];valid=result_phases.vm_pu[np.isfinite(result_phases.vm_pu)&(result_phases.vm_pu>0)]
        phase_ids=sorted({int(v) for v in list(rows.from_phase)+list(rows.to_phase) if int(v)!=0});phase_pairs=[[int(r.from_phase),int(r.to_phase)] for _,r in rows.iterrows()]
        anchor_bus=transformer_meta[transformer_index]['secondary'][0];ax,az=point(geo,anchor_bus)
        sp={'id':spid,'label':str(rows.name.iloc[0]),'name':str(rows.name.iloc[0]),'circuit':circuit,'modelIndex':int(idx),'assetBasis':'modeled_load','locationBasis':'model','coordinateSource':'SMARTDS model bus coordinates','bus':bus_id(bus),'busIndex':bus,'x':x,'z':z,'longitude':f(geo.loc[bus,'Longitude']),'latitude':f(geo.loc[bus,'Latitude']),'transformerId':target_id,'anchor':{'transformerId':target_id,'bus':bus_id(anchor_bus),'x':ax,'z':az},'phases':phase_ids,'phaseConnections':phase_pairs,'phaseLabel':' · '.join('ABC'[i-1] if 1<=i<=3 else str(i) for i in phase_ids),'inputLoadKw':f(power(rows,'p_mw')),'inputLoadKvar':f(power(rows,'q_mvar')),'nominalVoltageKv':f(bus_rows.vn_kv.max()),'nominalPhaseVoltageKv':f(bus_rows.vn_kv.max()/math.sqrt(3)),'baselinePhaseVoltages':[{'phase':int(phase),'voltagePu':f(r.vm_pu),'angleDegrees':f(r.va_degree)} for phase,r in result_phases.iterrows()],'baselineVoltagePu':f(valid.min()),'baselineVoltageMaxPu':f(valid.max()),'inService':bool(rows.in_service.any()),'customerType':str(rows.type.iloc[0]),'inventoryType':'SMARTDS modeled load group'}
        links[spid]=target_id;service_points.append(sp);circuit_points.append(sp)
    for idx,rows in net.asymmetric_sgen.groupby(level=0,sort=False):
        buses=sorted(int(b) for b in rows.bus.unique());targets=set().union(*(secondary_roots[components[b]] for b in buses))
        for tid in targets:gens_by_tx[tid].append(rows)
        bus=buses[0];x,z=point(geo,bus)
        top_generators.append({'id':f'{network}/asymmetric_sgen/{int(idx)}','label':str(rows.name.iloc[0]),'circuit':circuit,'bus':bus_id(bus),'x':x,'z':z,'transformerIds':[tx_id(i) for i in sorted(targets)],'padmountTransformerIds':[],'inService':bool(rows.in_service.any()),'type':str(rows.type.iloc[0]),'inputGenerationKw':f(power(rows,'p_mw')),'inputGenerationKvar':f(power(rows,'q_mvar'))})
    line_length=0
    for idx,rows in net.line.groupby(level=0,sort=False):
        row=rows.iloc[0];line_length+=float(row.length_km)
        geom=net.line_geo.xs(idx,level=0).iloc[0]['coords'];points=[project(lon,lat) for lon,lat in geom]
        if len(points)<2:raise ValueError(f'Missing line route {circuit}/{idx}')
        st=str(row.std_type).lower();overhead=True if '_oh_' in st else False if '_ug_' in st else None
        top_lines.append({'id':f'L-{circuit}-{int(idx)}','label':str(row['name']),'circuit':circuit,'points':points,'overhead':overhead,'constructionBasis':'Conductor standard-type label' if overhead is not None else 'Not supplied','fromBus':bus_id(row.from_bus),'toBus':bus_id(row.to_bus),'phases':' · '.join('ABC'[i-1] for i in sorted({int(v) for v in rows.from_phase if 1<=int(v)<=3})),'lengthKm':f(row.length_km),'inService':bool(rows.in_service.any()),'modelIndex':int(idx)})
    # Include bus-switch metadata without inventing native line result indexes.
    for idx,rows in net.switch.groupby(level=0,sort=False):
        row=rows.iloc[0];bus=int(row.bus);target=int(row.element)
        top_switches.append({'id':f'{network}/switch/{int(idx)}','label':str(row['name']),'circuit':circuit,'modelIndex':int(idx),'fromBus':bus_id(bus),'toBus':bus_id(target) if row.et=='b' else None,'elementType':str(row.et),'element':target,'closed':bool(rows.closed.all()),'phases':sorted({int(v) for v in rows.phase}),'points':[point(geo,bus),point(geo,target)] if row.et=='b' else None})
    circuit_txs=[]
    for idx,rows in net.trafo1ph.groupby(level=0,sort=False):
        idx=int(idx);rows=rows.sort_index();meta=transformer_meta[idx];primary=meta['primary'];secondary=meta['secondary'];result_rows=net.res_trafo.loc[net.res_trafo.index.get_level_values(0)==idx]
        winding=[]
        for (key,w),(_,r) in zip(rows.iterrows(),result_rows.iterrows()):
            winding.append({'pKw':f(r.p_mw*1000),'qKvar':f(r.q_mvar*1000),'ratedKva':f(w.sn_mva*1000),'side':'primary' if int(key[1]) in primary else 'secondary','loadingPct':f(r.loading_percent),'voltagePu':f(r.vm_pu),'fromPhase':int(w.from_phase),'toPhase':int(w.to_phase),'busIndex':int(key[1]),'circuitIndex':int(key[2]),'coreLossKw':f(w.pfe_kw)})
        wp=[w for w in winding if w['side']=='primary'];ws=[w for w in winding if w['side']=='secondary'];rated=sum(w['ratedKva'] for w in wp);secondary_kva=sum(math.hypot(w['pKw'],w['qKvar']) for w in ws)
        selected_bus=secondary[0] if secondary else primary[0];x,z=point(geo,selected_bus)
        result_bus=net.res_bus.loc[(net.res_bus.index.get_level_values(0).isin(secondary))&(net.res_bus.index.get_level_values('phase').isin([1,2,3]))]
        vb=result_bus.vm_pu[np.isfinite(result_bus.vm_pu)&(result_bus.vm_pu>0)];sec_min,sec_max=extent(w['voltagePu'] for w in ws);prim_min,prim_max=extent(w['voltagePu'] for w in wp)
        all_load=pd.concat(loads_by_tx[idx]) if loads_by_tx[idx] else net.asymmetric_load.iloc[:0];all_gen=pd.concat(gens_by_tx[idx]) if gens_by_tx[idx] else net.asymmetric_sgen.iloc[:0]
        tx={'id':tx_id(idx),'label':('REG' if meta['regulator'] else 'TX')+'-'+dt+'-'+str(idx+1).zfill(4),'name':str(rows.name.iloc[0]),'circuit':circuit,'substation':substation,'modelIndex':idx,'mounting':'unknown','equipmentType':'regulator' if meta['regulator'] else 'distribution_transformer','isRegulator':meta['regulator'],'thermalEligible':not meta['regulator'],'connection':'regulator' if meta['regulator'] else 'center_tap' if len(ws)==2 and len(secondary)==1 else 'model_windings','x':x,'z':z,'bus':bus_id(selected_bus),'secondaryBusIndex':selected_bus,'windingBuses':[bus_id(b) for b in meta['buses']],'primaryBusIndices':primary,'secondaryBusIndices':secondary,'inService':bool(rows.in_service.any()),'ratedKva':f(rated),'primaryKv':f(meta['high']),'secondaryKv':f(meta['low']),'baselineConverged':True,'primaryPKw':f(sum(w['pKw'] for w in wp)),'primaryQKvar':f(sum(w['qKvar'] for w in wp)),'secondaryBusMinPu':f(vb.min()),'secondaryBusMaxPu':f(vb.max()),'inputLoadKw':f(power(all_load,'p_mw')),'inputLoadKvar':f(power(all_load,'q_mvar')),'inputGenerationKw':f(power(all_gen,'p_mw')),'inputGenerationKvar':f(power(all_gen,'q_mvar')),'secondaryKva':f(secondary_kva),'bankLoadingPct':f(secondary_kva/rated*100 if rated else None),'maxWindingLoadingPct':f(result_rows.loading_percent.max()),'secondaryMinPu':f(sec_min),'secondaryMaxPu':f(sec_max),'primaryMinPu':f(prim_min),'primaryMaxPu':f(prim_max),'lossKw':f(sum(w['pKw'] for w in winding)),'impedanceEstimated':False,'impedanceBasis':'Supplied modified SMARTDS model; reinforcement metadata retained','vkPercent':f(rows.vk_percent.max()),'vkrPercent':f(rows.vkr_percent.max()),'coreLossKw':f(sum(w['coreLossKw'] for w in wp)),'schematicMappedMeters':0,'modeledServicePoints':sum(s['transformerId']==tx_id(idx) for s in circuit_points),'windings':winding}
        txs.append(tx);circuit_txs.append(tx)
        top_transformers.append({key:tx[key] for key in ['id','label','circuit','mounting','equipmentType','isRegulator','thermalEligible','bus','windingBuses','x','z','inService']})
    count_reg=sum(t['isRegulator'] for t in circuit_txs);nominal=float(net.bus.xs(0,level=0).vn_kv.max())
    circuit_record={'id':circuit,'name':title,'circuitId':circuit,'network':network,'substation':substation,'area':substation,'x':center[0],'z':center[1],'extent':round(span*.7+50,3),'color':'#719fc9' if 'rhs1' in substation else '#73b99a','voltage':f'{nominal:g} kV','nominalVoltageKv':f(nominal),'phases':'A · B · C','servicePoints':len(circuit_points),'events':0,'outages':{'feeder':0,'transformer':0,'servicePoint':0},'restoredAt':0,'length':f(line_length,6),'transformers':len(circuit_txs),'distributionTransformers':len(circuit_txs)-count_reg,'regulators':count_reg,'inputLoadKw':f(power(net.asymmetric_load,'p_mw')),'inputLoadKvar':f(power(net.asymmetric_load,'q_mvar')),'inputGenerationKw':f(power(net.asymmetric_sgen,'p_mw')),'inputGenerationKvar':f(power(net.asymmetric_sgen,'q_mvar')),'baselineVoltageMinPu':f(cmin),'baselineVoltageMaxPu':f(cmax),'sourceVersion':net.get('source_version')}
    circuits.append(circuit_record)
    models.append({'key':network,'name':title,'substation':substation,'circuit':circuit,'url':f'models/{circuit}.pkl.bin','sha256':bundled_sha,'sourceSha256':source_sha,'buses':len(geo),'longitude':float(geo.Longitude.mean()),'latitude':float(geo.Latitude.mean()),'bounds':bounds,'bytes':len(bundled),'compressedBytes':len(compressed),'sourceFile':p.name})
    verification={'name':title,'solved':True,'iterations':int(net.model.iterations),'seconds':round(seconds,6),'voltageMinPu':f(cmin),'voltageMaxPu':f(cmax),'voltageViolations':int(((energized<.95)|(energized>1.05)).sum()),'parameters':PARAMETERS,'verificationBasis':'Fresh native multiconductor solve using the exact bundled source code; original PKL contains no saved solved results'}
    base_circuits.append({'id':circuit,'name':title,'substation':substation,'network':network,'modelSha256':bundled_sha,'sourceSha256':source_sha,'transformers':len(circuit_txs),'distributionTransformers':len(circuit_txs)-count_reg,'regulators':count_reg,'ratedKva':f(sum(t['ratedKva'] for t in circuit_txs if not t['isRegulator'])),'maxWindingLoadingPct':f(max(t['maxWindingLoadingPct'] for t in circuit_txs)),'secondaryMinPu':f(min(t['secondaryMinPu'] for t in circuit_txs if t['secondaryMinPu'] is not None)),'secondaryMaxPu':f(max(t['secondaryMaxPu'] for t in circuit_txs if t['secondaryMaxPu'] is not None)),'verification':verification})
    source_meta={'file':p.name,'sha256':source_sha,'bytes':len(raw),'bundleSha256':bundled_sha,'bundleBytes':len(bundled),'sourceVersion':str(net.get('source_version','')),'sourceUrl':str(net.get('source_url','')),'circuit':circuit,'distributionTransformers':len(circuit_txs)-count_reg,'regulators':count_reg,'modeledLoads':len(circuit_points),'buses':len(geo),'physicalLines':int(net.line.index.get_level_values(0).nunique()),'generators':int(net.asymmetric_sgen.index.get_level_values(0).nunique()),'measurementRows':len(net.measurement),'conversionTimestampUtc':net.get('conversion_timestamp_utc'),'hasRatingThresholdModification':'rating_threshold_update' in net,'hasCapacityUpgrade':'la_capacity_upgrade' in net,'modelVariant':net.get('core_product_alignment',{}).get('variant'),'operatingPoint':net.get('core_product_alignment',{}).get('operating_point'),'capacityPolicy':net.get('la_capacity_upgrade',{}).get('physical_model'),'profileFilesSupplied':False,'geometryNotes':net.get('geometry_completion',{}).get('interpretation')}
    model_sources.append(source_meta)
    # Baseline tables are useful to reproducibly seed scenario/model comparisons.
    model_profiles.append({'circuit':circuit,'inputLoadKw':circuit_record['inputLoadKw'],'inputGenerationKw':circuit_record['inputGenerationKw'],'profileBasis':'Snapshot inputs only; no time series supplied'})
    print('Solved',circuit,len(circuit_points),'modeled loads',len(circuit_txs),'transformer/regulator IDs',flush=True)

counts={'circuits':len(circuits),'substations':len({c['substation'] for c in circuits}),'modelBuses':sum(m['buses'] for m in models),'lineFeatures':len(top_lines),'modelSwitches':len(top_switches),'lineVertices':sum(len(l['points']) for l in top_lines),'modelTransformers':len(txs),'distributionTransformers':sum(not t['isRegulator'] for t in txs),'regulators':sum(t['isRegulator'] for t in txs),'generators':len(top_generators),'inventoryMeters':len(service_points),'mappedInventoryMeters':len(service_points),'modeledServicePoints':len(service_points),'modelLocatedServicePoints':len(service_points),'locatedServicePoints':len(service_points),'renderedServicePoints':len(service_points),'exactTransformerMeters':len(service_points),'unlocatedServicePoints':0,'outsideStudyServicePoints':0,'outsideOrUnassignedInventoryMeters':0,'recordedMeterLocations':0,'schematicServicePoints':0,'rawEventRows':0,'duplicateRestoreRows':0,'validEventPairs':0,'linkedEventPairs':0,'unassignedEventPairs':0,'qualifyingEpisodes':0,'derivedEpisodes':0,'exportedEventRecords':0,'distinctPairedServicePoints':0,'outageCells':0,'padmountTransformers':0,'generatorsAtTransformerBus':0,'generatorsAtPadmountTransformerBus':0}
notes=['SMARTDS SFO/P3R synthetic network models, using the user-supplied modified snapshots; not a utility as-built inventory.',f'{len(service_points):,} modeled load groups stand in for service points. They are not field meter/customer records.',f'{counts["distributionTransformers"]:,} distribution transformers and {counts["regulators"]} voltage regulators are represented by {len(txs):,} native transformer IDs.', 'Every modeled load is linked to exactly one distribution transformer through in-service line and closed bus-switch topology; no proximity matching.', 'Coordinates are supplied synthetic network model coordinates, projected in meters. Source display-stub/infill metadata is retained in model files.', 'Electrical models include prior modeled reinforcement/rating modifications. Original source and published bundle hashes are recorded separately.', 'Published model copies add CIRCUIT_ID equal to existing CIRCUIT_KEY; all supplied electrical model values are preserved.', 'No electrical measurements, historical outages, PON/PRN records or hourly profiles were supplied in the PKLs. Event arrays are empty.', 'September 1–15, 2026 UTC defines the virtual demonstration scenario window, not a source observation period.', 'Transformer mounting and field thermal test data are unknown. Winding ratings, impedance, core losses and solved results come from each supplied model.', 'Model baseline uses a fresh multiconductor power flow with device controls enabled. Network state estimation remains an independent calculation.']
reference_sha=sha('\n'.join(f'{m["file"]} {m["sha256"]}' for m in model_sources).encode())
provenance={'format':2,'dataset':'SMARTDS SFO/P3R modeled network variant','sourceDirectoryLabel':'di_validator/pkls','sourceVersion':'SMART-DS/v1.0/2018/SFO/P3R/base_timeseries','sources':model_sources,'referenceSha256':reference_sha,'solverSha256':solver_sha,'exportScriptSha256':sha(pathlib.Path(__file__).read_bytes()),'sourceCounts':counts,'coordinateSystem':{'projection':'local equirectangular display coordinates','origin':origin,'units':'meters','x':'east','z':'negative north','crsSource':'EPSG:4326'},'timezone':'UTC','virtualScenarioWindow':{'start':START,'end':END,'basis':'Virtual demonstration only; no dated source observations'},'notes':notes}
study={'name':'SMARTDS modeled distribution network','dataset':'smartds','start':START,'end':END,'timezone':'UTC','timeLabel':'Virtual scenario · UTC','timeBasis':'virtual_scenario','sourceObservationPeriod':None,'restorationTimeBasis':'virtual','sourceCounts':counts,'excludedCounts':{'outsideOrUnmatchedCompletedPairs':0,'unresolvedOrInvalidRecords':0,'completedPairsWithoutLocation':0},'auditStatusCounts':{},'notes':notes,'totals':{'servicePoints':len(service_points),'mappedServicePoints':len(service_points),'transformers':len(txs),'distributionTransformers':counts['distributionTransformers'],'regulators':counts['regulators'],'feeders':len(circuits),'events':0,'episodes':0,'servicePoint':0,'transformer':0,'feeder':0,'linkedEvents':0,'unassignedEvents':0}}
initial={'x':circuits[0]['x'],'z':circuits[0]['z'],'extent':circuits[0]['extent']}
dataset={'study':study,'circuits':circuits,'events':[],'outageEpisodes':[],'topology':{'buses':top_buses,'lines':top_lines,'switches':top_switches,'servicePoints':service_points,'outageCells':[],'transformers':top_transformers,'generators':top_generators},'worldUnitsPerMeter':1,'initialView':initial,'origin':origin,'defaultCircuit':DEFAULT}
write(output/'data/smartds.json',dataset)
write(output/'data/transformer-baseline.json',{'provenance':{**provenance,'baselineParameters':PARAMETERS,'baselineBasis':'Fresh native multiconductor solve'},'circuits':base_circuits,'transformers':txs})
write(output/'data/transformer-meter-groups.json',{'schemaVersion':2,'method':'Exact electrical connectivity: in-service lines and closed bus switches connect each modeled load group to one lower-voltage transformer winding component. No nearest-neighbor matching.','servicePointBasis':'modeled_load_group','links':links})
write(output/'data/provenance.json',provenance)
write(output/'powerflow/manifest.json',{'format':1,'dataset':'smartds','pyodide':'0.28.3','pandapower':'3.4.0','defaultCircuit':DEFAULT,'solver_sha256':solver_sha,'networks':models})
# Verification checks actual cross-file references before delivery.
assert len(service_points)==6091 and len(txs)==1720 and counts['regulators']==3
assert set(links)=={p['id'] for p in service_points}
assert set(links.values())<={t['id'] for t in txs}
assert all(m['sha256']==sha(gzip.decompress((output/'powerflow'/m['url']).read_bytes())) for m in models)
assert math.isclose(sum(p['inputLoadKw'] for p in service_points),sum(t['inputLoadKw'] for t in txs),abs_tol=1e-5)
write(output/'export-summary.json',{'counts':counts,'defaultCircuit':DEFAULT,'originalSourceBytes':sum(len(raw) for _,raw,_,_ in nets),'compressedBundleBytes':sum(m['compressedBytes'] for m in models),'baselineConverged':len(base_circuits),'minimumVoltagePu':min(c['verification']['voltageMinPu'] for c in base_circuits),'maximumVoltagePu':max(c['verification']['voltageMaxPu'] for c in base_circuits),'sourceHashCatalog':reference_sha,'solverSha256':solver_sha,'artifactFiles':[str(p.relative_to(output)) for p in sorted(output.rglob('*')) if p.is_file() and p.name!='export-summary.json']})
print(json.dumps({'output':str(output),'counts':counts,'verifiedModels':len(models)},indent=2),flush=True)
