"""Numerical parity of the published WASM Python adapter against DI Validator."""
from pathlib import Path
import sys, json, hashlib, unittest
ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'public/fault-detection'
sys.path.insert(0,str(ASSETS))
from runner import analyze_fault
class FaultParityTests(unittest.TestCase):
    def test_all_recordings_match_the_source_reference(self):
        manifest=json.loads((ASSETS/'manifest.json').read_text())
        references={r['record']:r for r in json.loads((ROOT/'src/fixtures/fault-reference.json').read_text())}
        statuses={}
        self.assertEqual(len(manifest['records']),99)
        for item in manifest['records']:
            raw=(ASSETS/item['url']).read_bytes();self.assertEqual(hashlib.sha256(raw).hexdigest(),item['sha256'])
            record=json.loads(raw);result=analyze_fault({'record':record,'include_arrays':False});actual=result['segments'][0];expected=references[item['id']]
            self.assertAlmostEqual(actual['onset'],expected['onset'],places=10)
            self.assertEqual(actual['fault_type_heuristic'],expected['fault_type_heuristic'])
            self.assertEqual(actual['distance']['status'],expected['distance']['status'])
            key='estimated_distance_km'
            if key in expected['distance']:self.assertAlmostEqual(actual['distance'][key],expected['distance'][key],places=8)
            else:self.assertNotIn(key,actual['distance'])
            status=actual['distance']['status'];statuses[status]=statuses.get(status,0)+1
        self.assertEqual(statuses,{'estimated':56,'out_of_range':43})
    def test_pipeline_provenance_matches_the_files_executed_in_wasm(self):
        manifest=json.loads((ASSETS/'manifest.json').read_text())
        for name,digest in manifest['runtime_files'].items():self.assertEqual(hashlib.sha256((ASSETS/name).read_bytes()).hexdigest(),digest)
    def test_changed_impedance_changes_distance_and_unknown_parameters_reject(self):
        record=json.loads((ASSETS/'waveforms/1A_val1.json').read_text())
        base=analyze_fault({'record':record,'include_arrays':False})['segments'][0]['distance']['estimated_distance_km']
        changed=analyze_fault({'record':record,'parameters':{'x1_ohm_km':.8},'include_arrays':False})['segments'][0]['distance']['estimated_distance_km']
        self.assertAlmostEqual(changed,base/2,places=10)
        with self.assertRaises(ValueError):analyze_fault({'record':record,'parameters':{'unknown':1}})
if __name__=='__main__':unittest.main()
