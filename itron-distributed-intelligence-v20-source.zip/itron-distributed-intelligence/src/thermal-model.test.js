import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {calculateSingleCable,calculateSteadyState,calculateThermalParameters,calculateTransientTemperatures,solveThermalStudy,DEFAULT_THERMAL_STUDY,sourceInputs,studyCSV,validateStudy} from './thermal-model.js';
const reference=JSON.parse(readFileSync(new URL('./fixtures/thermal-source.json',import.meta.url)));
const extra=JSON.parse(readFileSync(new URL('./fixtures/thermal-extra.json',import.meta.url)));
const {currents,cable_type:cable,duct_bank:bank,cols}=reference.inputs;
const near=(a,b,tolerance=1e-9)=>assert.ok(Math.abs(a-b)<tolerance,`${a} does not match ${b}`);
const compare=(actual,expected,tol)=>{assert.equal(actual.length,expected.length);actual.forEach((a,i)=>near(a,expected[i],tol));};
test('single cable, all thermal parameters and steady bank match original Python outputs',()=>{
 compare(calculateSingleCable(510,cable),reference.single_cable_510);
 const params=calculateThermalParameters(cable);Object.entries(reference.thermal_parameters).forEach(([key,v])=>near(params[key],v));
 compare(calculateSteadyState(currents,cable,bank,cols),reference.steady_state);
 compare(calculateSteadyState(currents,cable,reference.variant_duct_bank,cols),reference.variant_steady_state);
});
test('source heterogeneous cable arrays, zero loads, and donor orientation are preserved',()=>{
 for(const key of ['comfortable_demo','zero_load','heterogeneous','asymmetric_currents']){
  const e=extra[key];compare(calculateSteadyState(e.currents,e.cable_types||cable,bank,e.cols||cols),e.steady_state);
 }
 extra.heterogeneous.cable_types.forEach((c,i)=>Object.entries(extra.heterogeneous.thermal_parameters[i]).forEach(([key,v])=>near(calculateThermalParameters(c)[key],v)));
});
test('literal source RK4 matches variable-load Python temperature samples',()=>{
 const i=reference.inputs,r=calculateTransientTemperatures(currents,cable,bank,[],cols,i.time_step,i.total_time,i.load_profile,i.initial_temps);
 reference.transient.sample_indices.forEach((step,k)=>{
  near(r.time_array[step],reference.transient.time[k]);r.temperature_history.forEach((h,j)=>near(h[step],reference.transient.temperature_history_samples[j][k]));
 });
});
test('source transient independent equilibrium matches analytic RC; geometry does not alter it',()=>{
 const e=extra.constant_transient_short;
 const run=b=>calculateTransientTemperatures(e.currents,cable,b,[],1,e.step,e.duration,e.profile,e.initial);
 const r=run(bank);near(r.temperature_history[0].at(-1),e.final);near(r.temperature_history[0].at(-1),e.analytical,1e-7);
 assert.deepEqual(run(reference.variant_duct_bank),r);
});
test('coupled constant-load response follows analytic exponential toward bank steady state',()=>{
 const r=solveThermalStudy({...DEFAULT_THERMAL_STUDY,profile:'constant',duration:24});
 r.history.forEach((h,i)=>near(h.at(-1),r.steady[i]+(r.config.ambient-r.steady[i])*Math.exp(-24/r.config.response),1e-8));
 const settled=solveThermalStudy({...DEFAULT_THERMAL_STUDY,profile:'constant',initial:'equilibrium'});
 settled.history.forEach((h,i)=>h.forEach(t=>near(t,settled.steady[i])));
});
test('uniform capacity produces the requested steady-state limit',()=>{
 const r=solveThermalStudy(DEFAULT_THERMAL_STUDY),i=sourceInputs(r.config);
 near(Math.max(...calculateSteadyState(i.currents.map(v=>v*r.capacity),i.cable,i.bank,i.cols)),r.config.limit,1e-7);
 assert.equal(solveThermalStudy({...DEFAULT_THERMAL_STUDY,scale:0}).capacity,null);
});
test('coupled threshold crossing matches analytic first passage and source mode reports model units',()=>{
 const r=solveThermalStudy({...DEFAULT_THERMAL_STUDY,profile:'constant',limit:50,duration:24});
 const expected=-r.config.response*Math.log((r.steady[2]-50)/(r.steady[2]-r.config.ambient));
 near(r.stats[2].firstCrossing,expected,.002);near(r.stats[2].overTime,24-expected,.002);
 const source=solveThermalStudy({...DEFAULT_THERMAL_STUDY,model:'source',profile:'constant',duration:24});
 assert.equal(source.units,'model units');assert.ok(source.stats[2].final<source.steady[2]);
});
test('study validation rejects invalid values; supported bank size and exports stay aligned',()=>{
 for(const override of [{rows:1.5},{soil:0},{currents:[-1]},{model:'unknown'},{duration:NaN}])assert.throws(()=>validateStudy({...DEFAULT_THERMAL_STUDY,...override}));
 const r=solveThermalStudy({...DEFAULT_THERMAL_STUDY,rows:4,cols:4});assert.equal(r.history.length,16);assert.ok(r.history.flat().every(Number.isFinite));
 const csv=studyCSV(r).split('\n');assert.equal(csv.length,242);assert.equal(csv[0].split(',').length,19);
 compare(csv.at(-1).split(',').slice(3).map(Number),r.history.map(h=>h.at(-1)),1e-6);
});
test('unsupported source geometry is rejected in both study modes before producing results',()=>{
 for(const model of ['source','coupled']){
  assert.throws(()=>solveThermalStudy({...DEFAULT_THERMAL_STUDY,model,rows:4,cols:1,depth:18,vertical:18}),/supported range/);
  assert.throws(()=>solveThermalStudy({...DEFAULT_THERMAL_STUDY,model,rows:4,cols:4,soil:30,fill:200,depth:18,vertical:5,currents:Array(16).fill(100)}),/supported range/);
 }
});
