import './ductbank.css';
import {DEFAULT_THERMAL_STUDY,PROFILE_NAMES,SOURCE_SHA256,solveThermalStudy,validateStudy,studyCSV} from './thermal-model.js';

const clone=v=>JSON.parse(JSON.stringify(v));
const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const f=(v,d=1)=>Number.isFinite(v)?v.toFixed(d):'—';
const palette=['#1188b5','#7859b6','#d46c32','#249a84','#bb5282','#677daa','#b09219','#3998a8','#9252b7','#407e50','#ac4f4f','#74763d','#496bc2','#ad6498','#46955e','#aa833b'];
let result=solveThermalStudy(DEFAULT_THERMAL_STUDY),draft=clone(DEFAULT_THERMAL_STUDY),selected=2,cursor=240,baseline=null,mapMode='steady',showAll=true,setupOpen=false,error='',dirty=false,timer=null;
const unit=()=>result.units==='h'?'h':'mu';
const label=i=>`D${i+1}`;
const stateAt=i=>mapMode==='steady'?result.steady[i]:result.history[i][cursor];
const status=t=>t>=result.config.limit?'Above limit':t>=result.config.limit-10?'Near limit':'Within limit';
const tint=t=>t>=result.config.limit?'#d74951':t>=result.config.limit-10?'#c88718':'#168daf';
const titleForModel=c=>c.model==='coupled'?'Coupled approximation':'Source RC reference';
const field=(key,title,min,max,step=1)=>`<label>${title}<input name="${key}" type="number" min="${min}" max="${max}" step="${step}" value="${esc(draft[key])}" required></label>`;
const select=(key,title,options)=>`<label>${title}<select name="${key}">${Object.entries(options).map(([v,t])=>`<option value="${v}" ${draft[key]===v?'selected':''}>${t}</option>`).join('')}</select></label>`;
function selectedValues(){return result.stats[selected]}
function diagram(){
 const c=result.config,cols=c.cols,rows=c.rows,left=115,top=130,width=360,height=260,dx=width/Math.max(cols,2),dy=height/Math.max(rows,3);
 const bankW=(cols-1)*dx+105,bankH=(rows-1)*dy+92,x=left+(width-bankW)/2,y=top;
 const scale=6,bankWidth=11.5+(cols-1)*c.horizontal,bankHeight=11.5+(rows-1)*c.vertical;
 return `<svg class="ductbank-diagram" viewBox="0 0 590 505" role="group" aria-label="Ductbank cross-section. Select a duct for its temperature history.">
 <defs><pattern id="db-fill" width="9" height="9" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r=".7" fill="currentColor" opacity=".15"/></pattern></defs>
 <path class="db-ground" d="M35 57H555"/><path class="db-ground-sub" d="M35 65H555"/>
 <text x="35" y="38" class="db-dimension">GROUND SURFACE</text><text x="555" y="38" text-anchor="end" class="db-dimension">Nominal cross-section</text>
 <rect class="db-concrete" x="${x}" y="${y}" width="${bankW}" height="${bankH}" rx="8"/><rect x="${x}" y="${y}" width="${bankW}" height="${bankH}" rx="8" fill="url(#db-fill)"/>
 <path class="db-dim-line" d="M${x-22} 61V${top+46}m-5-5 5 5 5-5M${x-27} 67l5-6 5 6"/>
 <text class="db-dimension" x="${x-29}" y="103" text-anchor="end">${f(c.depth,0)} in*</text>
 ${Array.from({length:rows*cols},(_,i)=>{const cx=x+52.5+(i%cols)*dx,cy=y+46+Math.floor(i/cols)*dy,t=stateAt(i),color=tint(t);return `<g class="db-duct ${selected===i?'selected':''}" role="button" tabindex="0" aria-label="Select duct ${label(i)}, ${f(t)} degrees Celsius" aria-pressed="${selected===i}" data-duct="${i}"><title>${label(i)} · ${f(result.currents[i],0)} A · ${f(t)} °C · ${status(t)}</title><circle class="db-selected-ring" cx="${cx}" cy="${cy}" r="36"/><circle cx="${cx}" cy="${cy}" r="29" fill="${color}" fill-opacity=".12" stroke="${color}" stroke-width="2"/><circle class="db-wire" cx="${cx-7}" cy="${cy-8}" r="5"/><circle class="db-wire" cx="${cx+7}" cy="${cy-8}" r="5"/><circle class="db-wire" cx="${cx}" cy="${cy+3}" r="5"/><text x="${cx}" y="${cy+21}" text-anchor="middle" class="db-temp" fill="${color}">${f(t)}°</text><text x="${cx+35}" y="${cy+4}" class="db-duct-label">${label(i)}</text></g>`}).join('')}
 <path class="db-dim-line" d="M${x} ${y+bankH+28}H${x+bankW}M${x} ${y+bankH+20}v16m${bankW}-16v16"/>
 <text class="db-dimension" x="${x+bankW/2}" y="${y+bankH+48}" text-anchor="middle">${f(bankWidth)} in · ${cols} columns</text>
 <text class="db-dimension" x="${x+bankW+28}" y="${y+bankH/2}" transform="rotate(90 ${x+bankW+28} ${y+bankH/2})" text-anchor="middle">${f(bankHeight)} in · ${rows} rows</text>
 <text x="35" y="492" class="db-dimension">*Source depth parameter · diagram is schematic</text></svg>`;
}
function trace(){
 const c=result.config,s=selectedValues(),W=650,H=250,L=47,R=18,T=22,B=35,pw=W-L-R,ph=H-T-B;
 const values=showAll?result.history.flat():result.history[selected],comparison=baseline?.units===result.units&&baseline?.config.duration===c.duration?baseline.history[selected]:null;
 const min=Math.floor((Math.min(c.ambient,...values,...(comparison||[]))-5)/10)*10,max=Math.ceil((Math.max(c.limit,...values,...(comparison||[]))+5)/10)*10;
 const X=t=>L+t/c.duration*pw,Y=t=>T+(max-t)/(max-min)*ph;
 const points=history=>history.map((v,i)=>`${X(result.time[i]).toFixed(2)},${Y(v).toFixed(2)}`).join(' ');
 return `<svg class="thermal-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Transient conductor temperature against ${result.units==='h'?'hours':'unverified model time units'}, selected duct ${label(selected)}">
 ${Array.from({length:5},(_,i)=>{const val=min+(max-min)*i/4;return `<path class="db-chart-grid" d="M${L} ${Y(val)}H${W-R}"/><text x="${L-9}" y="${Y(val)+4}" text-anchor="end">${f(val,0)}°</text>`}).join('')}
 ${Array.from({length:7},(_,i)=>`<text x="${X(c.duration*i/6)}" y="${H-10}" text-anchor="middle">${f(c.duration*i/6,0)} ${unit()}</text>`).join('')}
 <path class="db-limit-line" d="M${L} ${Y(c.limit)}H${W-R}"/><text class="db-limit-label" x="${W-R}" y="${Y(c.limit)-6}" text-anchor="end">${f(c.limit,0)}° limit</text>
 ${showAll?result.history.map((h,i)=>i===selected?'':`<polyline fill="none" stroke="${palette[i]}" stroke-opacity=".38" stroke-width="1.5" points="${points(h)}"/>`).join(''):''}
 ${comparison?`<polyline class="db-baseline-trace" points="${points(comparison)}"/>`:''}
 <polyline fill="none" stroke="${palette[selected]}" stroke-width="3" points="${points(result.history[selected])}"/>
 <path class="db-cursor" d="M${X(result.time[cursor])} ${T}V${H-B}"/><circle cx="${X(result.time[cursor])}" cy="${Y(result.history[selected][cursor])}" r="5" fill="${palette[selected]}" stroke="var(--surface)" stroke-width="2"/>
 </svg><div class="thermal-chart-legend"><span><i style="background:${palette[selected]}"></i>${label(selected)} · ${f(result.history[selected][cursor])} °C</span>${baseline?`<span><i class="db-baseline-key"></i>${comparison?'Pinned baseline':'Baseline curve unavailable for this time axis'}</span>`:''}<span class="muted">${result.units==='h'?'Elapsed hours':'mu = unverified source time units'}</span></div>`;
}
function loadChart(){
 const W=650,H=66,L=47,R=18,T=9,B=16,pw=W-L-R,ph=H-T-B;
 return `<svg class="thermal-load-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Applied load multiplier over the study"><text x="7" y="32">Load</text><polygon points="${L},${H-B} ${result.loads.map((v,i)=>`${L+i/240*pw},${T+(1.6-v)/1.6*ph}`).join(' ')} ${W-R},${H-B}"/><text x="${W-R}" y="${H-3}" text-anchor="end">${f(Math.min(...result.loads),2)}–${f(Math.max(...result.loads),2)} × circuit current</text></svg>`;
}
function statistics(){
 const s=selectedValues(),h=result.stats[result.hottest],now=result.history[selected][cursor],c=result.config;
 const metrics=[
  ['CONDUCTOR · '+label(selected),now,[['Minimum',f(s.min)+' °C'],['Maximum',f(s.max)+' °C'],['Average',f(s.average)+' °C']]],
  ['BANK PEAK · '+label(result.hottest),result.peak,[['At time',f(result.time[result.history[result.hottest].indexOf(h.max)],1)+' '+unit()],['Above limit',f(h.overTime,1)+' '+unit()],['Margin',f(c.limit-h.max)+' °C']]],
  ['STEADY · '+label(selected),s.steady,[['Self rise',f(s.self-c.ambient)+' °C'],['Mutual rise',f(s.mutual)+' °C'],['Applied load',f(result.currents[selected],0)+' A']]],
 ];
 return metrics.map(([name,value,rows])=>`<article class="thermal-kpi"><small>${name}</small><strong style="color:${tint(value)}">${f(value)}<span> °C</span></strong><dl>${rows.map(([title,detail])=>`<div><dt>${title}</dt><dd>${detail}</dd></div>`).join('')}</dl></article>`).join('');
}
function assessment(){
 const c=result.config,s=selectedValues(),delta=baseline?result.maxSteady-baseline.maxSteady:null;
 return `<div class="thermal-assessment"><div><span>Bank peak / hottest duct</span><b>${f(result.peak)} °C · ${label(result.hottest)}</b></div><div><span>Steady-state margin to ${f(c.limit,0)} °C</span><b class="${result.maxSteady>c.limit?'thermal-danger':''}">${f(c.limit-result.maxSteady)} °C</b></div><div><span>Uniform load at steady limit</span><b>${result.capacity===null?'Not available':f(result.capacity*100,1)+'% of applied load'}</b></div><div><span>${label(selected)} first reaches limit</span><b>${s.firstCrossing===null?'Not within study':f(s.firstCrossing,2)+' '+unit()}</b></div></div><div class="thermal-coupling"><span>${label(selected)} steady-state breakdown</span><div><i style="width:${Math.max(0,(s.self-c.ambient)/(s.steady-c.ambient)*100)}%"></i></div><small>${f(s.self-c.ambient)}° self rise + ${f(s.mutual)}° mutual rise + ${f(c.ambient)}° ambient</small></div>${baseline?`<div class="thermal-comparison"><b>Versus pinned baseline</b><span>Maximum steady temperature: ${delta>0?'+':''}${f(delta)} °C</span><span>${baseline.units===result.units&&baseline.config.duration===c.duration?'Peak transient temperature: '+(result.peak-baseline.peak>0?'+':'')+f(result.peak-baseline.peak)+' °C':'Transient peaks use different time axes and are not compared.'}</span><span>${baseline.config.rows} × ${baseline.config.cols} ducts · ${titleForModel(baseline.config)} · ${PROFILE_NAMES[baseline.config.profile]}</span><button type="button" data-thermal="clear-baseline">Clear baseline</button></div>`:''}<p class="thermal-footnote">Uniform-load estimate preserves the current split and ignores the time-varying profile. It is a model comparison, not a cable nameplate rating.</p>`;
}
export function renderDuctbank(){
 const c=result.config;
 return `<section class="thermal-workspace" aria-label="Ductbank thermal modeling"><form id="thermal-form">
 <div class="thermal-commandbar"><div><span class="thermal-eyebrow">UNDERGROUND CABLE STUDY</span><strong>${c.rows} × ${c.cols} ductbank <span>· illustrative configuration</span></strong></div><div class="thermal-command-actions"><button type="button" data-thermal="pin">Pin baseline</button><button type="button" data-thermal="export">Export CSV</button><button type="button" data-thermal="export-study">Save study</button><button type="submit" class="primary-button">Run thermal study</button></div></div>
 <div class="thermal-setup-row">${select('model','Transient model',{coupled:'Coupled approximation',source:'Source RC reference'})}${select('profile','Load profile',PROFILE_NAMES)}${field('scale','Loading · %',0,180)}${field('limit','Temperature limit · °C',40,150)}<details id="thermal-settings" ${setupOpen?'open':''}><summary>Study settings</summary><div class="thermal-fields">${field('ambient','Ambient soil · °C',-10,60)}${field('soil','Soil resistivity · source ρ',30,250)}${field('fill','Fill resistivity · source ρ',20,200)}${field('rows','Rows',1,4)}${field('cols','Columns',1,4)}${field('depth','Burial depth · in',18,96,.25)}${field('horizontal','Horizontal pitch · in',5,18,.25)}${field('vertical','Vertical pitch · in',5,18,.25)}${field('duration',draft.model==='coupled'?'Duration · hours':'Duration · model units',1,96,.5)}${field('response','Assumed response time · h',.25,24,.25)}${select('initial','Starting temperature',{ambient:'Ambient soil temperature',equilibrium:'Equilibrium at initial load'})}<p class="thermal-field-note">The coupled approximation uses your assumed response time. Source RC uses its original, uncalibrated R×C time basis.</p></div></details></div>
 <div class="thermal-study-note" role="status" aria-live="polite"><span id="thermal-status">${dirty?'Inputs changed. Run the study to update results.':c.model==='coupled'?`Coupled approximation · assumed response time ${f(c.response,1)} h · not calibrated`:'Source RC reference · independent cables · time units unverified'}</span><div><button type="button" data-thermal="normal">Normal demand</button><button type="button" data-thermal="surge">Overload & recovery</button><button type="button" data-thermal="dry">Dry-soil scenario</button></div></div>
 ${error?`<p class="thermal-error" role="alert">${esc(error)}</p>`:''}
 <div class="thermal-grid"><section class="panel thermal-cross-section"><div class="panel-head"><h2>Ductbank cross-section</h2><div class="segmented"><button type="button" data-map-mode="steady" class="${mapMode==='steady'?'active':''}">Steady state</button><button type="button" data-map-mode="transient" class="${mapMode==='transient'?'active':''}">At selected time</button></div></div><div id="thermal-map">${diagram()}</div><div class="thermal-map-legend"><span><i style="background:#168daf"></i>Within limit</span><span><i style="background:#c88718"></i>Within 10 °C</span><span><i style="background:#d74951"></i>Above limit</span><span>Select a duct to inspect</span></div></section>
 <section class="panel thermal-cable-panel"><div class="panel-head"><h2>Cable temperatures</h2><span class="thermal-muted" id="thermal-table-time">${result.currents.length} circuits · ${f(result.time[cursor],1)} ${unit()}</span></div><div class="thermal-table-wrap"><table><thead><tr><th>Duct</th><th>Base A / phase</th><th>Steady °C</th><th>At time °C</th><th>Steady status</th></tr></thead><tbody>${result.currents.map((a,i)=>`<tr class="${selected===i?'thermal-selected':''}" data-thermal-row="${i}"><td><button type="button" data-select-duct="${i}" aria-label="Select duct ${label(i)}"><i style="background:${palette[i]}"></i>${label(i)}</button></td><td><input type="number" name="current-${i}" min="0" max="600" step="5" value="${esc(draft.currents[i]??275)}" aria-label="Duct ${label(i)} current in amperes" required></td><td><strong style="color:${tint(result.steady[i])}">${f(result.steady[i])}</strong></td><td id="thermal-time-temp-${i}">${f(result.history[i][cursor])}</td><td><span class="thermal-status-pill ${result.steady[i]>=c.limit?'over':result.steady[i]>=c.limit-10?'near':''}">${status(result.steady[i])}</span></td></tr>`).join('')}</tbody></table></div><div class="thermal-cable-note">Applied circuit current = base current × ${f(c.scale,0)}% loading. The transient profile adds its time-varying multiplier.</div></section>
 <section class="panel thermal-history"><div class="panel-head"><h2>Temperature over time</h2><label class="thermal-show-all"><input type="checkbox" id="thermal-all" ${showAll?'checked':''}>All ducts</label></div><div id="thermal-trace">${trace()}</div><div id="thermal-load">${loadChart()}</div><div class="thermal-playback"><button type="button" data-thermal="play" aria-label="${timer?'Pause':'Play'} thermal timeline">${timer?'Pause':'Play'}</button><input id="thermal-cursor" type="range" min="0" max="240" step="1" value="${cursor}" aria-label="Thermal timeline"><output id="thermal-time-label">${f(result.time[cursor],1)} ${unit()}</output></div><p class="thermal-footnote">${c.model==='coupled'?'First-order response toward the source steady-state temperature at each load. The 4 h default is an illustrative assumption.':'Original independent-cable heat balance with stable RK4 substeps. It omits mutual, shield and dielectric heating and does not approach the bank steady-state result.'}</p></section>
 <section class="thermal-summary" aria-label="Selected duct temperature summary"><div id="thermal-statistics" class="thermal-statistics">${statistics()}</div><div class="panel thermal-assessment-panel"><div id="thermal-assessment">${assessment()}</div></div><div class="panel thermal-method"><h2>Model basis</h2><p>Calculated from <a href="/thermal/thermal_temps.py" download>thermal_temps.py</a>. These are modeled temperatures for an illustrative bank, not measured SMARTDS cable data.</p><details><summary>Assumptions & source limitations</summary><ul><li>15 kV demo cable: 0.8 in conductor, 0.22 in insulation, 16 neutral wires. Resistance, materials and losses retain the source constants.</li><li>Depth sets cable L and source image offset L − 36. The source still uses 7 in / 5.5 in distances in part of the mutual-heating calculation; varying pitch is a sensitivity study, not a validated redesign.</li><li>Soil and fill ρ retain source values and conventions. The cross-section is schematic; 4 in ducts and edge allowances illustrate the layout.</li><li>Source RC time units are not established. The coupled approximation adds bank heating but requires a user-assumed response time; neither model is field calibrated.</li><li>The ${f(c.limit,0)} °C screening limit is user-set. A qualified engineering model and cable specifications are needed for operating decisions.</li></ul><small>Source SHA-256: ${SOURCE_SHA256}</small></details></div></section></div></form></section>`;
}
function stop(){if(timer){clearInterval(timer);timer=null}}
export function unmountDuctbank(){stop()}
function redraw(){const host=document.querySelector('#content');if(!host||location.hash!=='#ductbank')return;host.innerHTML=renderDuctbank();mountDuctbank()}
function bindDiagram(){document.querySelectorAll('[data-duct]').forEach(el=>{const choose=()=>{selected=Number(el.dataset.duct);refreshOutputs()};el.onclick=choose;el.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();choose()}}})}
function refreshOutputs(){
 const map=document.querySelector('#thermal-map');if(!map){stop();return}
 map.innerHTML=diagram();bindDiagram();document.querySelector('#thermal-trace').innerHTML=trace();document.querySelector('#thermal-statistics').innerHTML=statistics();document.querySelector('#thermal-assessment').innerHTML=assessment();
 document.querySelectorAll('[data-thermal-row]').forEach(row=>row.classList.toggle('thermal-selected',Number(row.dataset.thermalRow)===selected));
 result.currents.forEach((_,i)=>document.querySelector('#thermal-time-temp-'+i).textContent=f(result.history[i][cursor]));
 document.querySelector('#thermal-cursor').value=cursor;document.querySelector('#thermal-time-label').value=f(result.time[cursor],1)+' '+unit();document.querySelector('#thermal-table-time').textContent=result.currents.length+' circuits · '+f(result.time[cursor],1)+' '+unit();
 document.querySelector('[data-thermal=clear-baseline]')?.addEventListener('click',()=>{baseline=null;redraw()});
}
function run(){
 stop();try{const config=validateStudy(draft),next=solveThermalStudy(config);result=next;draft=clone(config);selected=Math.min(selected,next.currents.length-1);cursor=240;error='';dirty=false;}catch(e){error=e.message;}redraw();
}
function saveFile(name,text,type){const url=URL.createObjectURL(new Blob([text],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function action(name){
 if(name==='pin'){baseline=clone(result);redraw()}
 if(name==='clear-baseline'){baseline=null;redraw()}
 if(name==='export')saveFile('ductbank-temperature-history.csv',studyCSV(result),'text/csv');
 if(name==='export-study')saveFile('ductbank-thermal-study.json',JSON.stringify({model:titleForModel(result.config),sourceSha256:SOURCE_SHA256,assumptions:'Illustrative bank; source RC time units unverified; coupled response time is user-assumed.',...result},null,2),'application/json');
 if(['normal','surge','dry'].includes(name)){draft=clone(DEFAULT_THERMAL_STUDY);if(name==='surge')draft.profile='surge';if(name==='dry'){draft.soil=160;draft.fill=100;}run()}
 if(name==='play'){if(timer){stop();redraw();return}if(cursor===240)cursor=0;mapMode='transient';timer=setInterval(()=>{cursor=Math.min(240,cursor+2);refreshOutputs();if(cursor===240){stop();redraw()}},100);redraw()}
}
export function mountDuctbank(){
 const form=document.querySelector('#thermal-form');if(!form)return;
 form.elements.response.disabled=draft.model==='source';
 form.onsubmit=e=>{e.preventDefault();run()};
 form.querySelectorAll('[name]').forEach(input=>input.oninput=()=>{stop();const play=form.querySelector('[data-thermal=play]');play.textContent='Play';play.setAttribute('aria-label','Play thermal timeline');const key=input.name;if(key.startsWith('current-'))draft.currents[Number(key.slice(8))]=input.value;else draft[key]=input.value;if(key==='model'){draft.duration=input.value==='source'?24:48;form.elements.duration.value=draft.duration;form.elements.duration.parentElement.firstChild.textContent=input.value==='source'?'Duration · model units':'Duration · hours';form.elements.response.disabled=input.value==='source';}dirty=true;document.querySelector('#thermal-status').textContent='Inputs changed. Run the study to update results.';});
 form.querySelectorAll('[data-thermal]').forEach(b=>b.onclick=()=>action(b.dataset.thermal));
 form.querySelectorAll('[data-select-duct]').forEach(b=>b.onclick=()=>{selected=Number(b.dataset.selectDuct);refreshOutputs()});
 form.querySelectorAll('[data-map-mode]').forEach(b=>b.onclick=()=>{mapMode=b.dataset.mapMode;form.querySelectorAll('[data-map-mode]').forEach(x=>x.classList.toggle('active',x===b));refreshOutputs()});
 form.querySelector('#thermal-cursor').oninput=e=>{stop();cursor=Number(e.target.value);mapMode='transient';form.querySelectorAll('[data-map-mode]').forEach(x=>x.classList.toggle('active',x.dataset.mapMode==='transient'));refreshOutputs();const b=form.querySelector('[data-thermal=play]');b.textContent='Play';b.setAttribute('aria-label','Play thermal timeline')};
 form.querySelector('#thermal-all').onchange=e=>{showAll=e.target.checked;refreshOutputs()};
 form.querySelector('#thermal-settings').ontoggle=e=>{setupOpen=e.target.open};bindDiagram();
}
