// Browser translation of scripts/thermal_temps.py, ductbank functions only.
// Reference formulas intentionally retain their constants and geometry behavior.
export const SOURCE_SHA256='5e4af765da798bd7d27f2591869fb64bd3272c385af1e28e3000380588f64861';
export const SOURCE_DEFAULTS={Rdc25:23.6,Tj:.11,d:.115,Lf:1.048,ks:1,er:2.8,cos0:.004,Nprime:1,Ts:78.5,a:17,S:7};
const log=Math.log10;
export function calculateSingleCable(current,c){
 const [Dc,Tcs,Tin,Tis,n,kp,Ta,Volts,pi,pj,pe,L]=[c[0],c[2],c[3],c[4],c[7],c[10],c[11],c[13],c[14],c[15],c[19],c[31]];
 const {Rdc25,Tj,d,Lf,ks,er,cos0,Nprime,Ts,a,S}=SOURCE_DEFAULTS;
 const Dcs=Dc+2*Tcs,Di=Dcs+2*Tin,Dis=Di+2*Tis,Dshld=Dis+2*d,Dsm=(Dshld+Dis)/2,Dj=Dshld+2*Tj,De=Dj;
 const E=Volts/Math.sqrt(3),LF=.3*.69+.7*.69*.69,Rdc=Rdc25*((75+228.1)/(25+228.1));
 const Rs=(10.575*Lf/(n*d*d))*((Ts+234.5)/(25+234.5)),xs=Rdc/ks,xp=Rdc/kp;
 const Fxs=11/(xs+4/xs-2.56/(xs*xs))**2,Fxp=11/(xp+4/xp-2.56/(xp*xp))**2;
 const Ycp=Fxp*(Dc/S)**2*(1.18/(Fxp+.27)+.312*(Dc/S)**2),Yc=Fxs+Ycp;
 const Xm=52.92*log(2*S/Dsm),P=Rs/(Xm+a),Q=Rs/(Xm-a/3);
 const qs1=1+((P*P+3*Q*Q+2*1.732*(P-Q)+4)/(4*(P*P+1)*(Q*Q+1)))*Rs/(Rdc*(1+Yc));
 const qs2=1+(1/(Q*Q+1))*Rs/(Rdc*(1+Yc));
 const qs3=1+((P*P+3*Q*Q-2*1.732*(P-Q)+4)/(4*(P*P+1)*(Q*Q+1)))*Rs/(Rdc*(1+Yc));
 const Dx=1.02*Math.sqrt(104/pe**.8*24),Ri=.012*pi*log(Dis/Dc),Rj=.012*pj*log(Dj/Dis);
 const F21=Math.sqrt(S*S+(2*L)**2)/S,F=F21*F21;
 const Re1=.012*pe*Nprime*log(Dx/De),Re2=.012*pe*Nprime*LF*log(4*L/Dx),R21=.012*pe*Nprime*LF*log(F21);
 const Red2=.012*pe*Nprime*(log(Dx/De)+log((4*L/Dx)*F));
 const Rda2=.5*Ri+Rj+Red2,Rca2=Ri+qs2*(Rj+Re1+Re2)+qs1*R21+qs3*R21;
 const Wd=.00276*E*E*er*cos0/log(Di/Dcs),Wc=(current/1000)**2*Rdc*(1+Yc);
 return [Wc*Rca2+Ta+Wd*Rda2,Wc,qs1];
}
const cableAt=(types,i)=>Array.isArray(types[0])?types[i]:types;
export function calculateSteadyState(currents,types,bank,cols){
 const singles=currents.map((current,i)=>calculateSingleCable(current,cableAt(types,i)));
 return singles.map((self,i)=>{
  let temp=self[0];
  for(let j=0;j<currents.length;j++){
   if(j===i||currents[j]<=0)continue;
   // Source orientation: sending cable j -> receiving cable i.
   const dr=Math.floor(i/cols)-Math.floor(j/cols),dc=i%cols-j%cols;
   const imageDistance=Math.hypot(72+2*bank[4]+(dr+1)*bank[5],dc*bank[6]);
   const distance=Math.hypot(dc*7,dr*5.5);
   const Re=.00522*bank[2]*log(imageDistance/distance)+.00522*(bank[8]-bank[2])*.76;
   temp+=3*singles[j][1]*singles[j][2]*Re*bank[7]+3*Re*.0221;
  }
  return temp;
 });
}
export function calculateThermalParameters(c){
 const Dc=c[0],Dcs=Dc+2*.03,Di=Dcs+2*c[3],Dis=Di+2*c[4],Dj=Dis+2*SOURCE_DEFAULTS.d+2*SOURCE_DEFAULTS.Tj;
 const Ri=.012*c[14]*log(Dis/Dc),Rj=.012*c[15]*log(Dj/Dis),Re=.012*c[19]*log(4*c[31]/Dj);
 const Cc=Math.PI*(Dc/2)**2*.324*.092*12;
 const Ci=Math.PI*((Di/2)**2-(Dcs/2)**2)*.032*.4*12;
 const Cj=Math.PI*((Dj/2)**2-(Dis/2)**2)*.040*.4*12;
 return {total_resistance:Ri+Rj+Re,total_capacitance:Cc+Ci+Cj,time_constant:(Ri+Rj+Re)*(Cc+Ci+Cj),insulation_r:Ri,jacket_r:Rj,earth_r:Re};
}
export function interpolateLoadProfile(profile,step,time){
 if(time<=0)return profile[0];const index=Math.floor(time/step);
 if(index>=profile.length-1)return profile.at(-1);
 return profile[index]+(time-index*step)/step*(profile[index+1]-profile[index]);
}
export function calculateDerivatives(temperatures,currents,types,params,factor){
 return temperatures.map((t,i)=>(calculateSingleCable(currents[i]*factor,cableAt(types,i))[1]-(t-cableAt(types,i)[11])/params[i].total_resistance)/params[i].total_capacitance);
}
export function rungeKuttaStep(temps,currents,types,params,factor,step){
 const k1=calculateDerivatives(temps,currents,types,params,factor);
 const k2=calculateDerivatives(temps.map((v,i)=>v+.5*step*k1[i]),currents,types,params,factor);
 const k3=calculateDerivatives(temps.map((v,i)=>v+.5*step*k2[i]),currents,types,params,factor);
 const k4=calculateDerivatives(temps.map((v,i)=>v+step*k3[i]),currents,types,params,factor);
 return temps.map((v,i)=>v+step/6*(k1[i]+2*k2[i]+2*k3[i]+k4[i]));
}
export function calculateTransientTemperatures(currents,types,bank,duct,cols,step,total,profile,initial){
 if(!(step>0&&total>0)||profile.length<2)throw Error('A positive time step, duration, and two profile points are required.');
 const n=Math.floor(total/step)+1,params=currents.map((_,i)=>calculateThermalParameters(cableAt(types,i)));
 const history=currents.map((_,i)=>[initial[i]]),time=[0];let temps=[...initial];
 for(let t=1;t<n;t++){
  const at=t*step;time.push(at);
  temps=rungeKuttaStep(temps,currents,types,params,interpolateLoadProfile(profile,total/(profile.length-1),at),step);
  temps.forEach((v,i)=>history[i].push(v));
 }
 return {temperature_history:history,time_array:time};
}

export const DEFAULT_THERMAL_STUDY={rows:3,cols:2,ambient:25,soil:90,fill:55,depth:36,horizontal:7.5,vertical:7.5,limit:90,scale:100,model:'coupled',response:4,duration:48,profile:'daily',initial:'ambient',currents:[275,260,330,305,250,285]};
export const PROFILE_NAMES={constant:'Constant load',daily:'Daily demand',surge:'Overload & recovery'};
export function validateStudy(input){
 const c={...input,currents:[...input.currents]};
 const ranges={rows:[1,4],cols:[1,4],ambient:[-10,60],soil:[30,250],fill:[20,200],depth:[18,96],horizontal:[5,18],vertical:[5,18],limit:[40,150],scale:[0,180],response:[.25,24],duration:[1,96]};
 for(const [key,[lo,hi]] of Object.entries(ranges)){c[key]=Number(c[key]);if(!Number.isFinite(c[key])||c[key]<lo||c[key]>hi)throw Error(`${key}: enter a value from ${lo} to ${hi}.`);}
 if(!Number.isInteger(c.rows)||!Number.isInteger(c.cols))throw Error('Rows and columns must be whole numbers.');
 if(!['coupled','source'].includes(c.model)||!PROFILE_NAMES[c.profile]||!['ambient','equilibrium'].includes(c.initial))throw Error('Choose a supported model, profile and starting condition.');
 c.currents=Array.from({length:c.rows*c.cols},(_,i)=>Number(c.currents[i]??275));
 if(c.currents.some(i=>!Number.isFinite(i)||i<0||i>600))throw Error('Cable currents must be from 0 to 600 A.');
 return c;
}
export function sourceInputs(config){
 const cable=Array(32).fill(0);Object.assign(cable,{0:.8,2:.03,3:.22,4:.03,7:16,10:1,11:config.ambient,13:15,14:350,15:450,19:config.soil,31:config.depth});
 return {currents:config.currents.map(i=>i*config.scale/100),cable,bank:[0,0,config.fill,0,config.depth-36,config.vertical,config.horizontal,1,config.soil],cols:config.cols};
}
export function loadProfile(config){
 const daily=[.62,.58,.55,.54,.55,.60,.70,.82,.85,.80,.76,.75,.78,.80,.83,.90,1.05,1.15,1.08,.97,.87,.78,.70,.66,.62];
 if(config.profile==='constant')return [1,1];
 return Array.from({length:97},(_,i)=>{
  const time=i*config.duration/96;
  if(config.profile==='surge'){const f=i/96;return f<.25?.75:f<.5?1.4:.65;}
  const hour=(config.model==='coupled'?time:time/config.duration*48)%24;
  return interpolateLoadProfile(daily,1,hour);
 });
}
export function solveThermalStudy(input){
 const config=validateStudy(input),{currents,cable,bank,cols}=sourceInputs(config),profile=loadProfile(config);
 for(let i=0;i<currents.length;i++)for(let j=0;j<currents.length;j++){
  if(i===j)continue;
  const dr=Math.floor(i/cols)-Math.floor(j/cols),dc=i%cols-j%cols;
  const imageDistance=Math.hypot(72+2*bank[4]+(dr+1)*bank[5],dc*bank[6]),distance=Math.hypot(dc*7,dr*5.5);
  const mutualResistance=.00522*bank[2]*log(imageDistance/distance)+.00522*(bank[8]-bank[2])*.76;
  if(imageDistance<=distance||!Number.isFinite(mutualResistance)||mutualResistance<0)throw Error('This geometry and fill/soil combination falls outside the source model’s supported range. Increase burial depth or reduce row spacing and fill resistivity.');
 }
 const params=calculateThermalParameters(cable),steady=calculateSteadyState(currents,cable,bank,cols),single=currents.map(i=>calculateSingleCable(i,cable)[0]);
 if(![...Object.values(params),...steady,...single].every(Number.isFinite)||params.total_resistance<=0||params.total_capacitance<=0)throw Error('The source model returned invalid thermal parameters. Review geometry and resistivity.');
 const target=factor=>config.model==='coupled'?calculateSteadyState(currents.map(i=>i*factor),cable,bank,cols):currents.map(i=>cable[11]+calculateSingleCable(i*factor,cable)[1]*params.total_resistance);
 let temps=config.initial==='equilibrium'?target(profile[0]):currents.map(()=>config.ambient);
 const history=currents.map((_,i)=>[temps[i]]),time=[0],loads=[profile[0]],steps=240;
 // Exact exponential RC step for the explicitly assumed coupled model;
 // stable substeps of the literal source RK4 integrator for source mode.
 for(let n=1;n<=steps;n++){
  const start=(n-1)*config.duration/steps,end=n*config.duration/steps,dt=end-start;
  const substeps=Math.max(1,Math.ceil(dt/(config.model==='source'?params.time_constant/10:.05)));
  const h=dt/substeps;
  for(let s=1;s<=substeps;s++){
   const factor=interpolateLoadProfile(profile,config.duration/(profile.length-1),start+s*h);
   if(config.model==='coupled'){const equilibrium=target(factor),decay=Math.exp(-h/config.response);temps=temps.map((t,i)=>equilibrium[i]+(t-equilibrium[i])*decay);}
   else temps=rungeKuttaStep(temps,currents,cable,currents.map(()=>params),factor,h);
  }
  time.push(end);loads.push(interpolateLoadProfile(profile,config.duration/(profile.length-1),end));
  temps.forEach((t,i)=>{if(!Number.isFinite(t))throw Error('The thermal solution is not finite. Review study inputs.');history[i].push(t)});
 }
 const stats=history.map((values,i)=>{
  const min=Math.min(...values),max=Math.max(...values);let integral=0,overTime=0,firstCrossing=values[0]>=config.limit?0:null;
  for(let k=1;k<values.length;k++){
   const a=values[k-1],b=values[k],dt=time[k]-time[k-1];integral+=(a+b)*.5*dt;
   if(a>=config.limit&&b>=config.limit)overTime+=dt;
   else if((a<config.limit)!==(b<config.limit)){const f=(config.limit-a)/(b-a);overTime+=a>=config.limit?dt*f:dt*(1-f);if(firstCrossing===null&&b>=config.limit)firstCrossing=time[k-1]+f*dt;}
  }
  return {min,max,average:integral/config.duration,final:values.at(-1),firstCrossing,overTime,steady:steady[i],self:single[i],mutual:steady[i]-single[i]};
 });
 const maxAt=factor=>Math.max(...calculateSteadyState(currents.map(i=>i*factor),cable,bank,cols));
 let capacity=null;
 if(currents.some(i=>i>0)&&maxAt(0)<config.limit){let lo=0,hi=8;if(maxAt(hi)>config.limit){for(let k=0;k<42;k++){const mid=(lo+hi)/2;if(maxAt(mid)>config.limit)hi=mid;else lo=mid;}capacity=lo;}}
 const peak=Math.max(...stats.map(s=>s.max)),hottest=stats.findIndex(s=>s.max===peak);
 return {config,currents,profile,params,steady,history,time,loads,stats,capacity,hottest,peak,maxSteady:Math.max(...steady),units:config.model==='coupled'?'h':'model units',sourceSha256:SOURCE_SHA256};
}
export function studyCSV(result){
 const rows=[['time',`time_unit`, 'load_multiplier',...result.currents.map((_,i)=>`D${i+1}_temperature_C`)],...result.time.map((t,k)=>[t,result.units,result.loads[k],...result.history.map(h=>h[k])])];
 return rows.map(row=>row.map(v=>typeof v==='number'?v.toFixed(6):v).join(',')).join('\n');
}
