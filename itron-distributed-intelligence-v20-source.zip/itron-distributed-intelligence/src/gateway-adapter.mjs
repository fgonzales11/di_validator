// Measured-device controller. Shares allocation/phasor primitives with the demo,
// but never integrates a proposed setpoint into observed device state.
import {allocatePower,createPMUMonitor,gatewayConfig} from './gateway-engine.mjs';
export const GATEWAY_ADAPTER_VERSION='1.1.0';
export const ADAPTER_LIMITS=Object.freeze({vehicles:128,batteries:8,solar:32,flex:32,commands:32,events:80,summaries:24,frameBytes:65536,stateAgeMs:1000,commandLeaseMs:2000});
const finite=x=>typeof x==='number'&&Number.isFinite(x);
const number=(x,min,max,name)=>{if(!finite(x)||x<min||x>max)throw Error(`Invalid ${name}.`);return x};
const integer=(x,min,max,name)=>{number(x,min,max,name);if(!Number.isSafeInteger(x))throw Error(`Invalid ${name}.`);return x};
const label=(x,name)=>{if(typeof x!=='string'||!x.trim()||x.length>128||/[\u0000-\u001f]/.test(x))throw Error(`Invalid ${name}; use 1–128 characters.`);return x};
const bool=(x,name)=>{if(typeof x!=='boolean')throw Error(`Invalid ${name}.`);return x};
const clone=x=>structuredClone(x),bytes=x=>new TextEncoder().encode(JSON.stringify(x)).byteLength;
const bounded=(a,v,max)=>{a.push(v);if(a.length>max)a.shift()};
const sum=(a,key)=>a.reduce((s,x)=>s+x[key],0);
const wrap=x=>((x+180)%360+360)%360-180;

export function validateGatewayInventory(input){
  if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Supply an equipment inventory.');
  const output={pcc:{id:label(input.pcc?.id,'PCC ID')}},ids=new Set([output.pcc.id]);
  for(const kind of ['vehicles','batteries','solar','flex']){
    if(!Array.isArray(input[kind])||input[kind].length>ADAPTER_LIMITS[kind])throw Error(`Supply 0–${ADAPTER_LIMITS[kind]} ${kind}.`);
    output[kind]=input[kind].map(raw=>{
      const asset={id:label(raw?.id,'asset ID')};if(ids.has(asset.id))throw Error('Equipment IDs must be globally unique.');ids.add(asset.id);
      if(kind==='batteries'){
        asset.capacityKwh=number(raw.capacityKwh,.001,100000,'battery capacity');
        asset.maxChargeKw=number(raw.maxChargeKw,0,2000,'battery charge rating');
        asset.maxDischargeKw=number(raw.maxDischargeKw,0,2000,'battery discharge rating');
        asset.chargeEfficiency=number(raw.chargeEfficiency,.1,1,'battery charge efficiency');
        asset.dischargeEfficiency=number(raw.dischargeEfficiency,.1,1,'battery discharge efficiency');
        asset.gridForming=bool(raw.gridForming,'grid-forming capability');
      }else asset.maxKw=number(raw.maxKw,.001,2000,'power rating');
      if(kind==='vehicles')asset.chargeEfficiency=number(raw.chargeEfficiency,.1,1,'EV charge efficiency');
      return asset;
    });
  }
  return output;
}

export function createAdapterGateway({sessionId,inventory:rawInventory,policy={},networkId,clock=()=>Date.now()}={}){
  sessionId=label(sessionId,'session ID');
  const inventory=validateGatewayInventory(rawInventory),config=gatewayConfig(policy);
  const scope={id:label(networkId??inventory.pcc.id,'network ID'),sessionId};
  const catalog=new Map(['vehicles','batteries','solar','flex'].flatMap(kind=>inventory[kind].map(asset=>[asset.id,{...asset,kind}])));
  let pmu=createPMUMonitor();const commands=[],events=[],summaries=[],deadlineStates=new Map();
  let sequence=0,cycles=0,lastObservedAt=null,mode='awaiting-feedback',dwell=0,plan=null,observed=null,eventId=0;
  const stats={commandsIssued:0,reportedAppliedCommands:0,rejectedCommands:0,localCyclesOffline:0,summariesEmitted:0,summariesDropped:0};
  const log=(kind,message,at)=>bounded(events,{id:`GW-${++eventId}`,kind,message,timestampMs:at},ADAPTER_LIMITS.events);
  function validateTelemetry(input,now){
    if(!input||typeof input!=='object'||Array.isArray(input)||bytes(input)>ADAPTER_LIMITS.frameBytes)throw Error('Supply bounded telemetry (64 KiB maximum).');
    if(input.sessionId!==sessionId)throw Error('Telemetry belongs to another gateway session.');
    const next={sequence:integer(input.sequence,sequence+1,Number.MAX_SAFE_INTEGER,'sequence'),observedAtMs:integer(input.observedAtMs,0,Number.MAX_SAFE_INTEGER,'observation time')};
    if(next.observedAtMs<=lastObservedAt||now-next.observedAtMs<0||now-next.observedAtMs>ADAPTER_LIMITS.stateAgeMs)throw Error('Telemetry observation time is out of order, future or stale.');
    next.baseLoadKw=number(input.baseLoadKw,0,100000,'baseline non-EV demand');
    next.criticalLoadKw=number(input.criticalLoadKw,0,next.baseLoadKw,'critical demand');
    next.gridAvailable=bool(input.gridAvailable,'grid availability');next.wanOnline=bool(input.wanOnline,'WAN status');next.syncAngleDeg=number(input.syncAngleDeg,-360,360,'synchronization angle');
    const p=input.pcc;if(!p||!['open','closed','unknown'].includes(p.position))throw Error('Supply observed PCC position.');
    next.pcc={position:p.position,observedAtMs:integer(p.observedAtMs,0,next.observedAtMs,'PCC time'),powerKw:number(p.powerKw,-100000,100000,'measured PCC power'),busEnergized:bool(p.busEnergized,'bus energized state')};
    const i=input.interlocks;next.interlocks={};for(const key of ['canOpen','canClose','canIsland','trip'])next.interlocks[key]=bool(i?.[key],key);
    if(!Array.isArray(input.devices)||input.devices.length>catalog.size)throw Error('Supply bounded device feedback.');
    const seen=new Set();next.devices=input.devices.map(raw=>{
      const asset=catalog.get(raw?.assetId);if(!asset||seen.has(raw.assetId))throw Error('Unknown or duplicate feedback asset.');seen.add(raw.assetId);
      const d={assetId:asset.id,kind:asset.kind,observedAtMs:integer(raw.observedAtMs,0,next.observedAtMs,'device time'),connected:bool(raw.connected,'device connection'),consent:bool(raw.consent,'device consent')};
      if(asset.kind==='vehicles'){
        d.availableKw=number(raw.availableKw,0,asset.maxKw,'charger availability');d.actualKw=number(raw.actualKw,0,asset.maxKw,'measured charger power');
        d.remainingKwh=number(raw.remainingKwh,0,10000,'remaining EV energy');d.deliveredKwh=number(raw.deliveredKwh,0,100000,'measured EV energy counter');
        d.departureAtMs=integer(raw.departureAtMs,0,Number.MAX_SAFE_INTEGER,'departure time');d.chargeSessionId=label(raw.chargeSessionId,'charge session ID');
      }else if(asset.kind==='batteries'){
        d.energyKwh=number(raw.energyKwh,0,asset.capacityKwh,'measured storage energy');d.availableChargeKw=number(raw.availableChargeKw,0,asset.maxChargeKw,'available charge power');d.availableDischargeKw=number(raw.availableDischargeKw,0,asset.maxDischargeKw,'available discharge power');
        d.actualKw=number(raw.actualKw,-asset.maxChargeKw,asset.maxDischargeKw,'measured battery power');d.gridFormingActive=bool(raw.gridFormingActive,'observed grid-forming state');
        if(d.gridFormingActive&&!asset.gridForming)throw Error('Grid-forming feedback contradicts the equipment capability.');
      }else{
        d.availableKw=number(raw.availableKw,0,asset.maxKw,'available resource power');d.actualKw=number(raw.actualKw,0,asset.maxKw,'measured resource power');
      }
      return d;
    });
    if(!Array.isArray(input.pmuFrames)||input.pmuFrames.length>240)throw Error('Supply at most 240 measured PMU frames.');
    const start=lastObservedAt??next.observedAtMs-1000;
    if(input.pmuFrames.some(f=>!finite(f?.timestamp)||f.timestamp<=start||f.timestamp>next.observedAtMs))throw Error('PMU timestamps must follow the previous observation and not exceed this observation.');
    next.pmuFrames=input.pmuFrames.map(f=>({timestamp:f.timestamp,frequencyHz:f.frequencyHz,voltagePu:f.voltagePu,angleDeg:f.angleDeg}));
    return next;
  }
  function step(input){
    const now=integer(clock(),0,Number.MAX_SAFE_INTEGER,'gateway clock'),t=validateTelemetry(input,now);
    const dt=lastObservedAt===null?0:(t.observedAtMs-lastObservedAt)/1000;
    const feedback=new Map(t.devices.map(d=>[d.assetId,d]));
    const missing=[...catalog.keys()].filter(id=>!feedback.has(id));
    const stale=t.devices.filter(d=>now-d.observedAtMs>ADAPTER_LIMITS.stateAgeMs).map(d=>d.assetId);
    const holdReasons=[];if(missing.length)holdReasons.push(`Missing device feedback: ${missing.join(', ')}`);if(stale.length)holdReasons.push(`Stale device feedback: ${stale.join(', ')}`);
    const uncontrolled=t.devices.filter(d=>(!d.connected||!d.consent)&&(Math.abs(d.actualKw)>.001||d.gridFormingActive));
    if(uncontrolled.length)holdReasons.push(`Uncontrolled resources have nonzero measured output: ${uncontrolled.map(d=>d.assetId).join(', ')}. Reconcile the baseline before new dispatch.`);
    if(sum(t.devices.filter(d=>d.kind==='flex'),'actualKw')>t.baseLoadKw-t.criticalLoadKw+.001)holdReasons.push('Measured flexible-load reduction exceeds declared noncritical demand.');
    const pccFresh=now-t.pcc.observedAtMs<=ADAPTER_LIMITS.stateAgeMs;
    if(!pccFresh||t.pcc.position==='unknown')holdReasons.push('PCC feedback is stale or unknown.');
    if(t.pcc.position==='open'&&Math.abs(t.pcc.powerKw)>.1)holdReasons.push('Observed open PCC conflicts with measured interchange.');
    if(t.pcc.position==='closed'&&t.gridAvailable&&!t.pcc.busEnergized)holdReasons.push('Closed PCC and available grid conflict with a deenergized bus.');
    const controlReady=holdReasons.length===0;
    // Validation above is atomic; no state changes occur for malformed frames.
    sequence=t.sequence;cycles++;lastObservedAt=t.observedAtMs;
    if(cycles===1)pmu=createPMUMonitor({startTimestamp:t.observedAtMs-1000});
    const pmuEvents=pmu.ingest(t.pmuFrames,t.observedAtMs),measurement=pmu.summary();
    for(const e of pmuEvents)log(e.kind,e.message,t.observedAtMs);
    const freshSignal=measurement.frames===60&&measurement.contiguousHealthyFrames>=60&&!measurement.disturbance&&measurement.to>=t.observedAtMs-20&&measurement.to<=t.observedAtMs&&Math.abs(measurement.meanFrequencyHz-60)<.1&&measurement.minVoltagePu>=.97&&measurement.maxVoltagePu<=1.03&&Math.abs(wrap(t.syncAngleDeg))<=5;
    const continuous=dt>0&&measurement.contiguousHealthyFrames>=Math.ceil(dt*60)-1;
    const eligibleFormers=controlReady?inventory.batteries.filter(b=>{const d=feedback.get(b.id),energyLowerBound=d.energyKwh-b.maxDischargeKw*(now-d.observedAtMs)/1000/b.dischargeEfficiency/3600;return b.gridForming&&d.connected&&d.consent&&d.availableDischargeKw>0&&energyLowerBound>b.capacityKwh*config.reservePct/100}):[];
    const chosenFormer=eligibleFormers.find(b=>feedback.get(b.id).gridFormingActive)??eligibleFormers[0];
    const formed=Boolean(chosenFormer&&feedback.get(chosenFormer.id).gridFormingActive);
    const gridConnected=controlReady&&t.pcc.position==='closed'&&t.gridAvailable&&!t.interlocks.trip;
    const islandOperating=controlReady&&t.pcc.position==='open'&&t.pcc.busEnergized&&formed&&t.interlocks.canIsland&&!t.interlocks.trip;
    const wantsOpen=!t.gridAvailable||t.interlocks.trip;
    let requestedPcc=null;
    if(wantsOpen&&pccFresh&&t.interlocks.canOpen)requestedPcc='open';
    if(controlReady&&t.pcc.position==='open'&&t.gridAvailable&&t.interlocks.canClose&&!t.interlocks.trip&&freshSignal&&continuous)dwell+=dt;else dwell=0;
    if(dwell>=config.reconnectSeconds)requestedPcc='closed';
    const priorMode=mode;
    mode=!controlReady?'feedback-hold':wantsOpen&&t.pcc.position!=='open'?'open-pending':gridConnected?'grid-connected':requestedPcc==='closed'?'close-pending':t.gridAvailable&&dwell>0?'resynchronizing':islandOperating?'islanded':t.pcc.position==='open'&&!t.interlocks.trip&&t.interlocks.canIsland&&chosenFormer?'island-starting':'deenergized';
    if(priorMode!==mode)log('microgrid',`${priorMode} → ${mode}; observed PCC ${t.pcc.position}.`,t.observedAtMs);
    observed={sequence,observedAtMs:t.observedAtMs,baseLoadKw:t.baseLoadKw,criticalLoadKw:t.criticalLoadKw,gridAvailable:t.gridAvailable,wanOnline:t.wanOnline,pcc:t.pcc,interlocks:t.interlocks,devices:t.devices};
    let expiresAtMs=now+ADAPTER_LIMITS.commandLeaseMs;const leaseSeconds=ADAPTER_LIMITS.commandLeaseMs/1000;
    const setpoints=[];let predicted=null;
    if(controlReady){
      const active=gridConnected||islandOperating;
      const pv=inventory.solar.map(a=>{const d=feedback.get(a.id);return {asset:a,cap:active&&d.connected&&d.consent?d.availableKw:0}}),pvAvailable=sum(pv,'cap');
      const bcap=inventory.batteries.map(a=>{
        const d=feedback.get(a.id),eligible=active&&d.connected&&d.consent,ageSeconds=(now-d.observedAtMs)/1000;
        // Reserve enough headroom for worst-case nameplate operation since the
        // measurement. These are planning bounds, never rewritten observations.
        const chargeRoom=a.capacityKwh-d.energyKwh-a.maxChargeKw*ageSeconds*a.chargeEfficiency/3600;
        const dischargeRoom=d.energyKwh-a.capacityKwh*config.reservePct/100-a.maxDischargeKw*ageSeconds/a.dischargeEfficiency/3600;
        return {asset:a,charge:eligible?Math.max(0,Math.min(d.availableChargeKw,chargeRoom*3600/a.chargeEfficiency/leaseSeconds)):0,discharge:eligible?Math.max(0,Math.min(d.availableDischargeKw,dischargeRoom*3600*a.dischargeEfficiency/leaseSeconds)):0};
      });
      const maxDischarge=sum(bcap,'discharge'),flexItems=inventory.flex.map(a=>{const d=feedback.get(a.id);return {asset:a,cap:active&&d.connected&&d.consent?d.availableKw:0}});
      const maxFlex=Math.min(sum(flexItems,'cap'),t.baseLoadKw-t.criticalLoadKw);
      let shed=active?Math.min(maxFlex,gridConnected?config.responseKw:Math.max(0,t.baseLoadKw-pvAvailable-maxDischarge)):0;
      const evItems=inventory.vehicles.map(a=>{const d=feedback.get(a.id),left=(d.departureAtMs-now)/1000,horizon=Math.min(leaseSeconds,Math.max(0,left)),remaining=Math.max(0,d.remainingKwh-a.maxKw*(now-d.observedAtMs)/1000*a.chargeEfficiency/3600);return {asset:a,expiresAtMs:Math.min(expiresAtMs,d.departureAtMs),cap:gridConnected&&d.connected&&d.consent&&horizon>0?Math.min(d.availableKw,remaining*3600/a.chargeEfficiency/horizon):0,weight:1+Math.min(20,left>0?d.remainingKwh*3600/(left*Math.max(.001,d.availableKw)*a.chargeEfficiency):0)}});
      const evAllocation=allocatePower(evItems,gridConnected?Math.max(0,config.importLimitKw+pvAvailable+maxDischarge-t.baseLoadKw+shed):0),evKw=evAllocation.reduce((s,x)=>s+x,0);
      const net=t.baseLoadKw-shed+evKw-pvAvailable;
      let batteryTarget=active?(gridConnected?Math.max(net-config.importLimitKw,config.responseKw-shed):net):0;
      batteryTarget=batteryTarget>=0?Math.max(0,Math.min(maxDischarge,batteryTarget,t.baseLoadKw-shed+evKw+(gridConnected?config.exportLimitKw:0))):-Math.min(-batteryTarget,sum(bcap,'charge'));
      const batteryAllocation=allocatePower(bcap.map(b=>({cap:batteryTarget>=0?b.discharge:b.charge})),Math.abs(batteryTarget)).map(x=>x*(batteryTarget>=0?1:-1)),batteryKw=batteryAllocation.reduce((s,x)=>s+x,0);
      const deficit=active?Math.max(0,t.baseLoadKw-shed+evKw-pvAvailable-batteryKw-(gridConnected?config.importLimitKw:0)):t.baseLoadKw;
      if(active)shed+=Math.min(maxFlex-shed,deficit);
      const requestedBase=t.baseLoadKw-shed;
      let pvUsed=pvAvailable,interchange=requestedBase+evKw-pvUsed-batteryKw;
      if(interchange<-(gridConnected?config.exportLimitKw:0)){const curtail=Math.min(pvUsed,-(gridConnected?config.exportLimitKw:0)-interchange);pvUsed-=curtail;interchange+=curtail}
      const gridKw=gridConnected?interchange:0,residual=gridKw+pvUsed+batteryKw-requestedBase-evKw;
      const unserved=gridConnected?0:Math.max(0,-residual),importViolation=Math.max(0,gridKw-config.importLimitKw),exportViolation=Math.max(0,-gridKw-config.exportLimitKw);
      const flexAllocation=allocatePower(flexItems,shed);
      for(const [i,item] of evItems.entries())setpoints.push({assetId:item.asset.id,type:'ev_charge',kw:evAllocation[i],validUntilMs:evAllocation[i]>0?item.expiresAtMs:expiresAtMs});
      for(const [i,item] of bcap.entries())setpoints.push({assetId:item.asset.id,type:'battery',kw:batteryAllocation[i],validUntilMs:expiresAtMs});
      for(const item of pv)setpoints.push({assetId:item.asset.id,type:'pv',kw:pvAvailable?item.cap*pvUsed/pvAvailable:0,validUntilMs:expiresAtMs});
      for(const [i,item] of flexItems.entries())setpoints.push({assetId:item.asset.id,type:'flex_shed',kw:flexAllocation[i],validUntilMs:expiresAtMs});
      for(const a of inventory.batteries.filter(b=>b.gridForming)){
        const d=feedback.get(a.id),enabled=a.id===chosenFormer?.id&&t.pcc.position==='open'&&t.interlocks.canIsland&&!t.interlocks.trip&&d.connected&&d.consent;
        setpoints.push({assetId:a.id,type:'grid_forming',enabled,validUntilMs:expiresAtMs});
      }
      const achieved=shed+batteryKw-(pvAvailable-pvUsed);
      predicted={conditionalOn:'Proposed setpoints applied and declared supply conditions valid; not measured performance',feasible:active&&importViolation<.001&&exportViolation<.001&&Math.abs(residual)<.001,baseLoadKw:t.baseLoadKw,requestedBaseKw:requestedBase,evKw,batteryKw,pvAvailableKw:pvAvailable,pvUsedKw:pvUsed,flexShedKw:shed,unservedKw:unserved,criticalUnservedKw:Math.min(t.criticalLoadKw,Math.max(0,unserved-(t.baseLoadKw-t.criticalLoadKw-shed))),gridKw,importViolationKw:importViolation,exportViolationKw:exportViolation,balanceResidualKw:residual,requestedResponseKw:gridConnected?config.responseKw:null,achievedResponseKw:achieved,responseShortfallKw:gridConnected?Math.max(0,config.responseKw-achieved):null};
    }
    if(requestedPcc!==null)setpoints.push({assetId:inventory.pcc.id,type:'pcc',position:requestedPcc,validUntilMs:expiresAtMs});
    // Outcomes are based only on fresh feedback. A skipped departure interval is
    // explicitly unknown; a new charging session clears the prior session outcome.
    for(const a of inventory.vehicles){
      const d=feedback.get(a.id),prior=deadlineStates.get(a.id);
      if(!d||stale.includes(a.id)){if(prior&&prior.departureAtMs<=t.observedAtMs&&prior.outcome==='pending')prior.outcome='unknown';continue}
      let outcome=prior?.chargeSessionId===d.chargeSessionId?prior.outcome:'pending';
      if(prior?.chargeSessionId===d.chargeSessionId&&d.deliveredKwh<prior.deliveredKwh)log('energy_counter',`${a.id}: measured energy counter reset; no inferred delivery credited.`,t.observedAtMs);
      if(outcome==='pending'&&d.departureAtMs<=t.observedAtMs)outcome=prior?.chargeSessionId===d.chargeSessionId&&prior.observedAtMs<=d.departureAtMs&&d.observedAtMs>=d.departureAtMs&&d.observedAtMs-prior.observedAtMs<=ADAPTER_LIMITS.stateAgeMs?(d.remainingKwh>.001?'missed':'met'):'unknown';
      deadlineStates.set(a.id,{assetId:a.id,chargeSessionId:d.chargeSessionId,observedAtMs:d.observedAtMs,departureAtMs:d.departureAtMs,remainingKwh:d.remainingKwh,deliveredKwh:d.deliveredKwh,outcome});
    }
    plan={timestampMs:t.observedAtMs,mode,controlReady,holdReasons,syncDwellSeconds:dwell,observedPcc:t.pcc,requestedPccPosition:requestedPcc,predicted};
    const authorizedSetpoints=setpoints.filter(p=>p.type==='pcc'||feedback.get(p.assetId).connected&&feedback.get(p.assetId).consent);
    // Coupled dispatch must expire as one lease; otherwise an early EV departure
    // could leave its balancing battery discharge active and violate export limits.
    expiresAtMs=Math.min(expiresAtMs,...authorizedSetpoints.filter(p=>p.type==='ev_charge'&&p.kw>0).map(p=>p.validUntilMs));
    for(const point of authorizedSetpoints)point.validUntilMs=expiresAtMs;
    const dispatch={id:`${sessionId}/DISPATCH-${sequence}`,sessionId,sequence,issuedAtMs:now,validUntilMs:expiresAtMs,application:'Proposed only; device adapter must enforce permissives and expiry',setpoints:authorizedSetpoints,acknowledgements:[]};
    stats.commandsIssued+=authorizedSetpoints.length;if(!t.wanOnline)stats.localCyclesOffline++;
    bounded(commands,dispatch,ADAPTER_LIMITS.commands);
    const summary={id:`${sessionId}/SUMMARY-${sequence}`,sequence,timestampMs:t.observedAtMs,mode,controlReady,holdReasons,observedPcc:t.pcc,predicted,pmu:measurement,pmuEvents,eventSnippets:pmu.completedSnippets(),delivery:'Queued for headend adapter; receipt unconfirmed'};
    pmu.recordOutput({summary:measurement,events:summary.pmuEvents,snippets:summary.eventSnippets});
    if(summaries.length===ADAPTER_LIMITS.summaries)stats.summariesDropped++;bounded(summaries,summary,ADAPTER_LIMITS.summaries);
    return snapshot();
  }
  function acknowledge(input){
    if(!input||input.sessionId!==sessionId)throw Error('Acknowledgment belongs to another gateway session.');
    const command=commands.find(c=>c.id===input.dispatchId),point=command?.setpoints.find(p=>p.assetId===input.assetId&&p.type===input.commandType);
    if(!point||!['applied','rejected'].includes(input.status))throw Error('Unknown command or acknowledgment status.');
    const value='kw'in point?point.kw:'position'in point?point.position:point.enabled;
    if(input.status==='applied'&&(typeof value==='number'?(!finite(input.appliedValue)||Math.abs(input.appliedValue-value)>1e-6):input.appliedValue!==value))throw Error('Applied value does not match the issued command. Report new measurements to replan.');
    const receipt={assetId:point.assetId,commandType:point.type,status:input.status,atMs:integer(input.atMs,command.issuedAtMs,Number.MAX_SAFE_INTEGER,'acknowledgment time'),...(input.status==='applied'?{appliedValue:input.appliedValue}:{})};
    const previous=command.acknowledgements.find(a=>a.assetId===point.assetId&&a.commandType===point.type);
    if(previous){if(JSON.stringify(previous)!==JSON.stringify(receipt))throw Error('Conflicting acknowledgment.');return snapshot()}
    const now=clock();if(command!==commands.at(-1)||now>point.validUntilMs||receipt.atMs>now||receipt.atMs>point.validUntilMs)throw Error('Command is superseded, expired, or acknowledgment time is future.');
    command.acknowledgements.push(receipt);stats[input.status==='applied'?'reportedAppliedCommands':'rejectedCommands']++;
    return snapshot();
  }
  function snapshot(){const last=commands.at(-1);return clone({version:GATEWAY_ADAPTER_VERSION,runtimeMode:'adapter',scope,policy:config,sequence,cycles,mode,observed,plan,inventory,pmu:pmu.snapshot(),deadlineOutcomes:[...deadlineStates.values()],stats,events,lastCommand:last?{...last,expired:clock()>last.validUntilMs}:null,uplink:{pending:summaries.length,limit:ADAPTER_LIMITS.summaries},limits:ADAPTER_LIMITS})}
  return {step,acknowledge,snapshot,action(){throw Error('Scenario actions are unavailable in measured-device mode.')},drainSummaries(){if(!observed?.wanOnline)return [];const out=clone(summaries);stats.summariesEmitted+=out.length;summaries.length=0;return out},export(){return {...snapshot(),commands:clone(commands),queuedSummaries:clone(summaries),provenance:{telemetry:'Supplied equipment inventory and device feedback; no synthetic fallback',control:'Supervisory proposals; acknowledgments are adapter reports, not independently verified actuation',delivery:'Local output only; headend receipt unconfirmed',runtime:'Portable JavaScript; target AMI installation and resource measurements remain required'}}}};
}
