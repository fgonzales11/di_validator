import test from 'node:test';
import assert from 'node:assert/strict';
import {ANALYSES, analysisDefinition, defaultAnalysisParameters, validateAnalysisParameters} from './analysis-types.js';
import {createAnalysis} from './analysis-controller.js';

const expectedTypes = [
  ['power_flow', 'Power Flow'],
  ['short_circuit', 'Short Circuit Duty'],
  ['protection', 'Protection Study'],
  ['contingency', 'Contingency'],
  ['optimal_power_flow', 'Optimal Power Flow'],
  ['grid_equivalent', 'Grid Equivalent'],
  ['load_allocation', 'Load Allocation'],
  ['hosting_capacity', 'Hosting Capacity'],
];

test('the analysis selector exposes exactly the eight requested studies with valid independent defaults', () => {
  assert.deepEqual(ANALYSES.map(({id,label}) => [id,label]), expectedTypes);
  assert.equal(new Set(ANALYSES.map(({id}) => id)).size, 8);
  for (const definition of ANALYSES) {
    assert.equal(analysisDefinition(definition.id), definition);
    const defaults = defaultAnalysisParameters(definition.id);
    assert.deepEqual(validateAnalysisParameters(definition.id, defaults), defaults);
    const separate = defaultAnalysisParameters(definition.id);
    assert.notEqual(defaults, separate);
    defaults[definition.fields[0].key] = 'mutated';
    assert.notDeepEqual(defaults, separate);
  }
  assert.throws(() => validateAnalysisParameters('state_estimation', {}), /supported analysis/);
});

test('all numeric settings reject coercion, nonfinite values, out-of-range values and fractional counts', () => {
  for (const definition of ANALYSES) {
    const defaults = defaultAnalysisParameters(definition.id);
    for (const field of definition.fields.filter(field => field.type === 'number')) {
      const badValues = [NaN, Infinity, -Infinity, String(field.value), true, null, field.min - 1, field.max + 1];
      if (field.step === 1) badValues.push(field.min + .5);
      for (const value of badValues) {
        assert.throws(() => validateAnalysisParameters(definition.id, {...defaults, [field.key]: value}), undefined, `${definition.id}.${field.key} accepted ${String(value)}`);
      }
      const missing = {...defaults}; delete missing[field.key];
      assert.throws(() => validateAnalysisParameters(definition.id, missing));
    }
  }
});

test('choices and flags require supported values and booleans', () => {
  for (const definition of ANALYSES) {
    const defaults = defaultAnalysisParameters(definition.id);
    for (const field of definition.fields) {
      const badValues = field.type === 'select' ? ['', 'unsupported', null] : field.type === 'checkbox' ? ['false', 0, 1, null] : [];
      for (const value of badValues) assert.throws(() => validateAnalysisParameters(definition.id, {...defaults, [field.key]: value}));
      if (field.type === 'checkbox') {
        assert.equal(validateAnalysisParameters(definition.id, {...defaults, [field.key]: false})[field.key], false);
        assert.equal(validateAnalysisParameters(definition.id, {...defaults, [field.key]: true})[field.key], true);
      }
    }
  }
});

test('bus and line settings accept auto or canonical nonnegative integers without coercing blank or boolean values', () => {
  for (const definition of ANALYSES) {
    const defaults = defaultAnalysisParameters(definition.id);
    for (const field of definition.fields.filter(field => ['bus', 'line'].includes(field.type))) {
      for (const value of ['auto', 0, 460, '0', '460']) {
        assert.equal(validateAnalysisParameters(definition.id, {...defaults, [field.key]: value})[field.key], value);
      }
      for (const value of [null, true, false, [], [0], {}, '', ' ', '1.0', '1e2', '0x10', -1, 1.5, NaN, Infinity]) {
        assert.throws(() => validateAnalysisParameters(definition.id, {...defaults, [field.key]: value}), undefined, `${definition.id}.${field.key} accepted ${JSON.stringify(value)}`);
      }
    }
  }
});

test('coupled voltage and relay limits reject contradictory settings, and zero allocation targets cannot pass', () => {
  for (const id of ['hosting_capacity', 'optimal_power_flow']) {
    assert.throws(() => validateAnalysisParameters(id, {...defaultAnalysisParameters(id), min_vm_pu: 1, max_vm_pu: 1}), /Maximum voltage/);
  }
  assert.throws(() => validateAnalysisParameters('protection', {...defaultAnalysisParameters('protection'), pickup_ratio: 1, instantaneous_ratio: .9}), /Instantaneous pickup/);
  for (const key of ['target_scale', 'target_mw']) {
    assert.throws(() => validateAnalysisParameters('load_allocation', {...defaultAnalysisParameters('load_allocation'), [key]: 0}));
  }
});

function harness(factory) {
  const workers = [], changes = [];
  const controller = createAnalysis({
    onChange: state => changes.push(state),
    workerFactory: () => {
      const worker = factory ? factory(workers.length) : {};
      worker.messages ??= [];
      worker.postMessage ??= data => { worker.messages.push(data); };
      worker.terminate ??= () => { worker.terminated = true; };
      workers.push(worker);
      return worker;
    },
  });
  return {controller, workers, changes};
}
const circuit = {id:'p3rhs1_1247--p3rdt1322', name:'SMARTDS DT1322'};
const payload = (analysis = 'power_flow', overrides = {}) => ({analysis, completed:true, converged:true, message:'Study completed.', metrics:[{label:'Example result', value:1}], tables:{example:[{index:0, phase:1, value:1}]}, ...overrides});
function start(h, analysis = 'power_flow', selected = circuit) {
  h.controller.run(selected, defaultAnalysisParameters(analysis), analysis);
  return h.workers.at(-1);
}
function respond(worker, result = payload(), overrides = {}) {
  const sent = worker.messages.at(-1);
  worker.onmessage({data:{id:sent.id, circuit:sent.circuit, type:'result', result, modelSha256:'model-hash', solverSha256:'solver-hash', ...overrides}});
}

test('invalid settings never start a worker and do not expose an export', () => {
  const h = harness();
  h.controller.run(circuit, {...defaultAnalysisParameters('power_flow'), MaxIter:0}, 'power_flow');
  assert.equal(h.workers.length, 0);
  assert.equal(h.controller.getState().status, 'error');
  assert.equal(h.controller.exportResult(), null);
  assert.match(h.controller.getState().error, /Maximum iterations/);
});

test('each study sends its own validated settings and preserves result provenance', () => {
  for (const [analysis] of expectedTypes) {
    const h = harness(), selected = {...circuit}, parameters = defaultAnalysisParameters(analysis);
    h.controller.run(selected, parameters, analysis);
    const worker = h.workers[0], sent = worker.messages[0];
    assert.equal(sent.analysis, analysis);
    assert.equal(sent.circuit, circuit.id);
    assert.deepEqual(sent.parameters, parameters);
    selected.id = 'changed-after-run';
    parameters[ANALYSES.find(item => item.id === analysis).fields[0].key] = 'changed-after-run';
    assert.equal(h.controller.exportResult(), null);
    respond(worker, payload(analysis));
    assert.equal(h.controller.getState().status, 'success');
    const exported = h.controller.exportResult();
    assert.equal(exported.analysis, analysis);
    assert.equal(exported.circuit, circuit.id);
    assert.deepEqual(exported.parameters, defaultAnalysisParameters(analysis));
    assert.equal(exported.modelSha256, 'model-hash');
    assert.equal(exported.solverSha256, 'solver-hash');
    assert.ok(Number.isFinite(Date.parse(exported.completedAt)));
  }
});

test('a second run is ignored while pending and stale request progress or results are ignored', () => {
  const h = harness(), worker = start(h);
  h.controller.run({id:'another-feeder'}, defaultAnalysisParameters('load_allocation'), 'load_allocation');
  assert.equal(h.workers.length, 1);
  assert.equal(worker.messages.length, 1);
  const before = h.controller.getState();
  worker.onmessage({data:{id:worker.messages[0].id - 1, type:'status', message:'Stale progress'}});
  assert.equal(h.controller.getState(), before);
  respond(worker, payload(), {id:worker.messages[0].id - 1});
  assert.equal(h.controller.getState(), before);
  worker.onmessage({data:{id:worker.messages[0].id, type:'status', message:'Solving in WASM'}});
  assert.equal(h.controller.getState().message, 'Solving in WASM');
  assert.equal(h.controller.getState().status, 'running');
});

test('wrong analysis, wrong circuit, and incomplete results never become successful or exportable', () => {
  const invalid = [
    {result:payload('load_allocation')},
    {result:payload(), circuit:'another-feeder'},
    {result:payload('power_flow', {completed:false})},
    {result:{analysis:'power_flow', completed:true}},
    {result:payload('power_flow', {converged:'true'})},
    {result:null},
  ];
  for (const response of invalid) {
    const h = harness(), worker = start(h);
    respond(worker, response.result, response.circuit ? {circuit:response.circuit} : {});
    assert.equal(h.controller.getState().status, 'error', JSON.stringify(response));
    assert.equal(h.controller.getState().result, null);
    assert.equal(h.controller.exportResult(), null);
  }
});

test('cancellation terminates its worker and late cancelled callbacks cannot change a new run', () => {
  const h = harness(), first = start(h), sent = first.messages[0];
  const late = first.onmessage, lateError = first.onerror;
  h.controller.cancel();
  assert.equal(first.terminated, true);
  assert.equal(h.controller.getState().status, 'cancelled');
  assert.equal(h.controller.exportResult(), null);
  const second = start(h, 'grid_equivalent');
  assert.notEqual(second, first);
  assert.ok(second.messages[0].id > sent.id);
  for (const message of [
    {type:'status', message:'Old progress'},
    {type:'error', message:'Old failure'},
    {type:'result', circuit:circuit.id, result:payload()},
  ]) late({data:{id:sent.id, ...message}});
  lateError({message:'Old worker error'});
  assert.equal(h.controller.getState().status, 'running');
  assert.equal(h.controller.getState().analysis, 'grid_equivalent');
  assert.equal(second.terminated, undefined);
  respond(second, payload('grid_equivalent'));
  assert.equal(h.controller.getState().status, 'success');
});

test('nonconverged studies retain usable diagnostics and remain explicitly nonconverged in exports', () => {
  const h = harness(), worker = start(h, 'load_allocation');
  const result = payload('load_allocation', {converged:false, message:'Target tolerance not met.', metrics:[{label:'Target error', value:8.5, unit:'%'}], tables:{head_target:[{target_mw:10, actual_mw:9.15, error_percent:-8.5}]}, notes:['Iteration limit reached.']});
  respond(worker, result);
  assert.equal(h.controller.getState().status, 'not_converged');
  assert.deepEqual(h.controller.getState().result, result);
  const exported = h.controller.exportResult();
  assert.equal(exported.completed, true);
  assert.equal(exported.converged, false);
  assert.deepEqual(exported.tables, result.tables);
  assert.deepEqual(exported.notes, result.notes);
  assert.equal(exported.circuit, circuit.id);
  assert.equal(exported.modelSha256, 'model-hash');
});

test('reported numerical failures are not exportable and a following run can succeed', () => {
  const h = harness(), worker = start(h);
  worker.onmessage({data:{id:worker.messages[0].id, type:'error', message:'Power flow did not converge.'}});
  assert.equal(h.controller.getState().status, 'error');
  assert.match(h.controller.getState().error, /did not converge/);
  assert.equal(h.controller.exportResult(), null);
  const retry = start(h, 'contingency');
  respond(retry, payload('contingency'));
  assert.equal(h.controller.getState().status, 'success');
  assert.equal(h.controller.getState().error, null);
});

test('a crashed worker is discarded and its late callbacks cannot break a recovered run', () => {
  const h = harness(), first = start(h), oldMessage = first.onmessage, oldError = first.onerror, oldRequest = first.messages[0];
  first.onerror({message:'WASM memory allocation failed'});
  assert.equal(first.terminated, true);
  assert.equal(h.controller.getState().status, 'error');
  assert.equal(h.controller.exportResult(), null);
  const second = start(h);
  assert.notEqual(second, first);
  oldMessage({data:{id:oldRequest.id, circuit:circuit.id, type:'result', result:payload()}});
  oldError({message:'Late worker failure'});
  assert.equal(h.controller.getState().status, 'running');
  respond(second);
  assert.equal(h.controller.getState().status, 'success');
});

test('a synchronous worker dispatch failure is discarded so a new worker can recover', () => {
  const h = harness(index => index === 0 ? {postMessage:() => {throw Error('Worker dispatch failed');}} : {});
  start(h);
  assert.equal(h.controller.getState().status, 'error');
  assert.equal(h.controller.exportResult(), null);
  assert.equal(h.workers[0].terminated, true);
  const second = start(h);
  assert.equal(h.workers.length, 2);
  respond(second);
  assert.equal(h.controller.getState().status, 'success');
});

test('reset clears results and invalidates completed callbacks, while resetting a running study cancels it', () => {
  const h = harness(), first = start(h), oldMessage = first.onmessage, oldRequest = first.messages[0];
  respond(first);
  h.controller.reset();
  assert.equal(h.controller.getState().status, 'idle');
  assert.equal(h.controller.exportResult(), null);
  oldMessage({data:{id:oldRequest.id, circuit:circuit.id, type:'result', result:payload()}});
  assert.equal(h.controller.getState().status, 'idle');
  const next = start(h);
  h.controller.reset();
  assert.equal(next.terminated, true);
  assert.equal(h.controller.getState().status, 'idle');
  assert.equal(h.controller.exportResult(), null);
});
