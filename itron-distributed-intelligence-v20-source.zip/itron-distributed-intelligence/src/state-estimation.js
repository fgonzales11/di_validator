export const DEFAULT_ESTIMATION_PARAMETERS = Object.freeze({
  source: 'synthetic', tol: 1e-6, objective_tol: 1e-10, max_iter: 50,
  bad_data_threshold: 4, max_bad_data: 0, sigma: .0005, sigma_power: .001, noise: true, seed: 42,
});

// Import only plain measurement records. Electrical model pickles are never
// accepted from visitors; the worker verifies models against the site catalog.
export function parseMeasurements(text, circuit) {
  if (text.length > 10_000_000) throw new Error('Use measurement JSON smaller than 10 MB.');
  const input = JSON.parse(text);
  if (!input || typeof input !== 'object') throw new Error('Supply measurement rows or a circuit/measurements object.');
  if (!Array.isArray(input) && String(input.circuit) !== String(circuit)) throw new Error(`The measurement file must identify feeder ${circuit}.`);
  const rows = Array.isArray(input) ? input : input.measurements;
  if (!Array.isArray(rows) || !rows.length || rows.length > 100000) throw new Error('Supply between 1 and 100,000 measurement rows.');
  const types = new Set(['p','q','i','im','ia','v','vm','va','vr','vi']);
  const elements = new Set(['bus','node','zero_injection','line','transformer','trafo','trafo1ph','source','ext_grid','ext_grid_sequence','switch']);
  return rows.map((row, index) => {
    const fail = message => { throw new Error(`Row ${index + 1}: ${message}`); };
    if (!row || typeof row !== 'object' || Array.isArray(row)) fail('expected a measurement object.');
    const measurement_type = String(row.measurement_type || '').toLowerCase();
    const element_type = String(row.element_type || '').toLowerCase();
    if (!types.has(measurement_type) || !elements.has(element_type)) fail('unsupported measurement or element type.');
    if (!Number.isInteger(row.element) || row.element < 0) fail('element must be a nonnegative model index.');
    if (!Number.isFinite(row.value) || !Number.isFinite(row.std_dev) || row.std_dev <= 0) fail('value must be finite and std_dev must be positive.');
    for (const key of ['phase','circuit']) if (row[key] != null && (!Number.isInteger(row[key]) || row[key] < 0)) fail(`${key} must be a nonnegative integer.`);
    if (['bus','node','zero_injection'].includes(element_type) && row.phase == null) fail('bus measurements require a phase (0 neutral; 1/2/3 A/B/C).');
    if (!['bus','node','zero_injection'].includes(element_type) && row.circuit == null) fail('branch measurements require a conductor/winding circuit index.');
    const unit = {p:'mw',q:'mvar',i:'ka',im:'ka',ia:'degree',va:'degree',v:'pu',vm:'pu',vr:'pu',vi:'pu'}[measurement_type];
    if (row.units != null && String(row.units).toLowerCase() !== unit) fail(`units must be ${unit}. Convert values and std_dev before import.`);
    if (row.name != null && typeof row.name !== 'string') fail('name must be text.');
    if (row.side != null && !['from','to','hv','lv','bus','source','element'].includes(row.side)) fail('unsupported branch side.');
    if (row.status != null && !['active','enabled','disabled','inactive','out_of_service','rejected'].includes(row.status)) fail('unsupported status.');
    return {measurement_type,element_type,element:row.element,value:row.value,std_dev:row.std_dev,
      ...(row.phase != null ? {phase:row.phase} : {}), ...(row.circuit != null ? {circuit:row.circuit} : {}),
      ...(row.side != null ? {side:row.side} : {}), ...(row.name != null ? {name:row.name} : {}),
      ...(row.status != null ? {status:row.status} : {})};
  });
}

export function createStateEstimation({onChange, workerFactory = () => new Worker(`${import.meta.env.BASE_URL}state-estimation/worker.mjs`, {type:'module'})}) {
  let worker, request = 0;
  let state = {status:'idle', circuit:null, result:null, message:''};
  const update = next => {state={...state,...next}; onChange(state);};
  function run(circuit, parameters, measurements = null) {
    if (state.status === 'running') return;
    const id = ++request;
    update({status:'running',circuit:{...circuit},parameters:{...parameters},result:null,error:null,message:'Starting state estimation…'});
    try {
      if (parameters.source === 'import' && !measurements?.length) throw new Error('Add measurements for this feeder in Measurement settings.');
      worker ??= workerFactory();
      const activeWorker = worker;
      worker.onmessage = ({data}) => {
        if (worker !== activeWorker || data.id !== request) return;
        if (data.type === 'status') {update({message:data.message}); return;}
        if (data.type === 'error') {update({status:'error',message:'State estimation could not complete.',error:data.message,result:null}); return;}
        if (data.type !== 'result' || data.circuit !== state.circuit.id || data.result?.analysis !== 'state_estimation') {
          update({status:'error',message:'The estimator returned an unexpected response.',result:null}); return;
        }
        const success = data.result.converged === true && data.result.solved === true && data.result.observable === true;
        update({status:success?'success':'not_converged',message:success?'State estimation converged.':'State estimation did not converge. Review measurements and settings.',
          result:data.result,modelSha256:data.modelSha256,completedAt:new Date().toISOString()});
      };
      worker.onerror = event => {
        if (worker !== activeWorker) return;
        worker.terminate(); worker=undefined;
        update({status:'error',message:'The WASM state estimator could not start.',error:event.message,result:null});
      };
      worker.postMessage({id,circuit:String(circuit.id),parameters:{...parameters},measurements});
    } catch (error) {update({status:'error',message:'State estimation could not start.',error:error.message,result:null});}
  }
  function cancel() {worker?.terminate();worker=undefined;request++;update({status:'cancelled',message:'State estimation cancelled.',result:null});}
  function reset() {if(state.status==='running')cancel(); update({status:'idle',result:null,error:null,message:'Settings changed. Run state estimation again.'});}
  function exportResult() {
    if (!state.result || !['success','not_converged'].includes(state.status)) return null;
    return {...state.result,circuit:state.circuit.id,parameters:state.parameters,completedAt:state.completedAt,modelSha256:state.modelSha256};
  }
  return {run,cancel,reset,exportResult,getState:()=>state};
}
