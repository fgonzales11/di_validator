import test from 'node:test';
import assert from 'node:assert/strict';
import {parseMeasurements,createStateEstimation,DEFAULT_ESTIMATION_PARAMETERS} from './state-estimation.js';
const measurement={measurement_type:'vm',element_type:'bus',element:2,phase:1,value:1.02,std_dev:.005};

test('imports preserve phase-aware values and reject wrong feeders or uncertainty',()=>{
  assert.deepEqual(parseMeasurements(JSON.stringify({circuit:'13081',measurements:[measurement]}),'13081'),[measurement]);
  assert.throws(()=>parseMeasurements(JSON.stringify({circuit:'13082',measurements:[measurement]}),'13081'),/identify feeder/);
  for(const row of [{...measurement,std_dev:0},{...measurement,std_dev:-1},{...measurement,value:'1.0'},{...measurement,phase:null},{...measurement,units:'kv'}])
    assert.throws(()=>parseMeasurements(JSON.stringify([row]),'13081'));
  assert.throws(()=>parseMeasurements('{"measurements":[]}','13081'));
});
function harness(){const workers=[],changes=[];const estimator=createStateEstimation({onChange:s=>changes.push(s),workerFactory:()=>{const w={postMessage:d=>w.sent=d,terminate:()=>w.terminated=true};workers.push(w);return w}});return {estimator,workers,changes};}
const result={analysis:'state_estimation',converged:true,solved:true,observable:true,tables:{res_bus:[{index:0,phase:1,vm_pu:1.01}]}};

test('independent estimator workers preserve circuit provenance and reject late cancelled runs',()=>{
  const a=harness(),b=harness(),circuit={id:'13081'};
  a.estimator.run(circuit,DEFAULT_ESTIMATION_PARAMETERS);b.estimator.run({id:'13380'},DEFAULT_ESTIMATION_PARAMETERS);
  const first=a.workers[0],late=first.onmessage;a.estimator.cancel();assert.equal(first.terminated,true);
  a.estimator.run(circuit,DEFAULT_ESTIMATION_PARAMETERS);
  late({data:{id:1,circuit:'13081',type:'result',result}});
  assert.equal(a.estimator.getState().status,'running');
  a.workers[1].onmessage({data:{id:a.workers[1].sent.id,circuit:'13081',type:'result',result,modelSha256:'verified'}});
  assert.equal(a.estimator.getState().status,'success');assert.equal(b.estimator.getState().status,'running');
  assert.equal(a.estimator.exportResult().circuit,'13081');assert.equal(a.estimator.exportResult().analysis,'state_estimation');
});

test('failed convergence and power-flow responses cannot be presented as successful estimates',()=>{
  const h=harness();h.estimator.run({id:'13081'},DEFAULT_ESTIMATION_PARAMETERS);
  h.workers[0].onmessage({data:{id:1,circuit:'13081',type:'result',result:{...result,converged:false,solved:false}}});
  assert.equal(h.estimator.getState().status,'not_converged');
  h.estimator.run({id:'13081'},DEFAULT_ESTIMATION_PARAMETERS);
  h.workers[0].onmessage({data:{id:2,circuit:'13081',type:'result',result:{solved:true}}});
  assert.equal(h.estimator.getState().status,'error');assert.equal(h.estimator.exportResult(),null);
});

test('import without measurements never starts a numerical worker',()=>{
  const h=harness();h.estimator.run({id:'13081'},{...DEFAULT_ESTIMATION_PARAMETERS,source:'import'});
  assert.equal(h.workers.length,0);assert.equal(h.estimator.getState().status,'error');
});
