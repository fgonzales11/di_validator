import {createQualityAgent} from './edge-quality.mjs';
import {virtualMeterSample,hash,SCENARIO_START,INTERVAL_MS,SAMPLE_COUNT} from './virtual-di-agent.js';
let agent,meters=[],runId,index=0,scenario='clean',times=[],lastPacket,qualifiedBatch=[];
const percentile=(xs,p)=>[...xs].sort((a,b)=>a-b)[Math.max(0,Math.ceil(xs.length*p)-1)]||0;
function packet(m,i){return {meterId:m.id,circuit:m.circuit,...virtualMeterSample(m,i),units:{load:'kW',voltage:'pu',timestamp:'ms'}}}
function step(){
  if(index>=SAMPLE_COUNT)return;
  const records=meters.map(m=>packet(m,index)),cycle=index%32;
  if(scenario==='stress'){
    if(cycle===2)records[0].units.voltage='V';
    if(cycle===4)records[0].voltage_pu=null;
    if(cycle===6)records.splice(Math.min(1,records.length-1),1);
    if(cycle===8)records.push({...records[0]});
    if(cycle===10)records[0].timestamp=SCENARIO_START-3*INTERVAL_MS;
    if(cycle>=13&&cycle<=20){const fixed=packet(meters[0],index-cycle+12);records[0].load_kw=fixed.load_kw||.5;records[0].voltage_pu=fixed.voltage_pu;records[0].power='on'}
    if(cycle===24)records[0].load_kw+=Math.max(30,Math.abs(meters[0].inputLoadKw||0)*8);
  }
  if(scenario==='outage'&&cycle>=4&&cycle<=7)for(const record of records.slice(0,4)){record.load_kw=0;record.voltage_pu=0;record.power='off'}
  lastPacket=records[0];qualifiedBatch=agent.process(records,SCENARIO_START+index*INTERVAL_MS).qualifiedBatch;index++;
}
function result(){const s=agent.snapshot();return {...s,runId,index,qualifiedBatch,totalIntervals:SAMPLE_COUNT,scenario,complete:index>=SAMPLE_COUNT,runtime:{batchP50Ms:percentile(times,.5),batchP95Ms:percentile(times,.95),lastBatchMs:times.at(-1)||0,batchesMeasured:times.length,modelBufferBytes:s.modelBufferBytes,engine:'Expert skills + rolling median/MAD',worker:true},lastPacket,source:'Synthetic SMARTDS virtual profiles'+(scenario==='stress'?' + injected data-quality defects':scenario==='outage'?' + coherent outage test':'')}}
self.onmessage=({data})=>{
  const {id,type}=data;
  try{
    if(type==='configure'){
      meters=data.meters;runId=data.runId;index=0;scenario=data.scenario;times=[];lastPacket=null;qualifiedBatch=[];
      if(!['clean','stress','outage'].includes(scenario))throw Error('Unknown replay scenario.');
      agent=createQualityAgent({meters,config:data.config,start:SCENARIO_START});
    }else if(data.runId!==runId)return;
    if(type==='step'){
      const t=performance.now();step();times.push(performance.now()-t);if(times.length>64)times.shift();
    }
    if(type==='report')agent.report();
    if(type==='ack')agent.acknowledge(data.alertId);
    self.postMessage({id,runId,type:'result',state:result(),...(type==='export'?{exportData:{...agent.export(),runId,runtime:result().runtime,scenario,provenance:{generator:'SMARTDS virtual DI v1',start:SCENARIO_START,intervalMs:INTERVAL_MS,totalIntervals:SAMPLE_COUNT,processedIntervals:index,meters:meters.map(m=>({...m,seed:hash(m.id)}))}}}:{})});
  }catch(error){self.postMessage({id,runId:data.runId,type:'error',message:error.message})}
};
