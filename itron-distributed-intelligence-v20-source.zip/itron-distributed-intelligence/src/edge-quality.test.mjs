import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {execFileSync,spawn} from 'node:child_process';
import {createQualityAgent,validateEdgeConfig,EDGE_LIMITS} from './edge-quality.mjs';
import {virtualMeterSample,meterProfile,meterOutages,SCENARIO_START,INTERVAL_MS} from './virtual-di-agent.js';
import {createEdgeController} from './edge-agent-controller.js';
const meter={id:'meter-A',circuit:'feeder',inputLoadKw:10,baselineVoltagePu:1};
const at=i=>SCENARIO_START+i*INTERVAL_MS;
const packet=(i,extra={})=>({meterId:meter.id,circuit:meter.circuit,timestamp:at(i),load_kw:5,voltage_pu:1,power:'on',units:{load:'kW',voltage:'pu',timestamp:'ms'},...extra});
const create=(config={})=>createQualityAgent({meters:[meter],config,start:SCENARIO_START});

test('zero load and coherent outages stay valid; only supplied channels are used for electrical context',()=>{
  const agent=create();
  for(let i=0;i<20;i++)agent.process([packet(i,{load_kw:0})],at(i));
  assert.equal(agent.snapshot().totals.flagged,0);
  let s=agent.process([packet(20,{load_kw:0,voltage_pu:0,power:'off'})],at(20));
  assert.equal(s.recent.at(-1).qualityDecision,'accept');assert.equal(s.recent.at(-1).eventClass,'outage');
  s=agent.process([packet(21)],at(21));assert.equal(s.recent.at(-1).eventClass,'restoration');
  s=agent.process([packet(22,{voltage_pu:1.2})],at(22));assert.equal(s.recent.at(-1).qualityDecision,'accept');assert.equal(s.recent.at(-1).eventClass,'voltage_excursion');
  s=agent.process([packet(23,{load_kw:-2})],at(23));assert.equal(s.recent.at(-1).qualityDecision,'flag');assert.match(s.evidence.at(-1).message,/legitimate export/);
  assert.equal(s.totals.quarantined,0);
});

test('contract checks never coerce missing or nonfinite values and keep received coverage distinct from validity',()=>{
  const agent=create();
  const bad=[null,NaN,Infinity,'3'];
  bad.forEach((value,i)=>agent.process([packet(i,{load_kw:value})],at(i)));
  agent.process([packet(4,{units:{load:'W',voltage:'pu',timestamp:'ms'}})],at(4));
  const s=agent.snapshot();assert.equal(s.totals.quarantined,5);assert.equal(s.totals.accepted,0);assert.equal(s.totals.missing,0);assert.equal(s.totals.received,5);
  assert.equal(s.learnedMeters,0);assert.equal(s.modelBufferBytes,32*2*8);
  const valid=packet(5),before=structuredClone(valid);agent.process([valid],at(5));assert.deepEqual(valid,before);
});

test('duplicates are idempotently suppressed, conflicts held, and gaps use the replay clock',()=>{
  const a=create();let s=a.process([packet(0),packet(0),packet(0,{load_kw:9})],at(0));
  assert.deepEqual([s.totals.accepted,s.totals.duplicates,s.totals.quarantined,s.totals.received],[1,1,1,1]);
  s=a.process([],at(1));assert.equal(s.totals.missing,1);assert.equal(s.recent.length,3);
  s=a.process([packet(1)],at(2));assert.equal(s.recent.at(-1).qualityDecision,'flag');assert.ok(s.evidence.some(e=>e.code==='late'));
  s=a.process([packet(0,{timestamp:at(0)+1})],at(3));assert.equal(s.recent.at(-1).qualityDecision,'quarantine');
  assert.throws(()=>a.process([packet(2)],at(2)),/monotonically/);
  const clean=create();assert.equal(clean.process([packet(0)],at(0)).totals.quarantined,0);
});

test('adaptive detection uses prior-only data, flags rather than repairs, and recovers after an isolated spike',()=>{
  const a=create({skills:['anomaly']});for(let i=0;i<8;i++)a.process([packet(i,{load_kw:5+i*.01})],at(i));
  let s=a.process([packet(8,{load_kw:100})],at(8));
  assert.equal(s.recent.at(-1).qualityDecision,'flag');assert.equal(s.recent.at(-1).load_kw,100);assert.ok(s.evidence.some(e=>e.code==='unusual_load_kw'));
  s=a.process([packet(9,{load_kw:5.1})],at(9));assert.equal(s.recent.at(-1).qualityDecision,'accept');
  const off=create({skills:[]});for(let i=0;i<9;i++)off.process([packet(i,{load_kw:i===8?100:5})],at(i));assert.equal(off.snapshot().totals.flagged,0);
  assert.ok(validateEdgeConfig({skills:[]}).skills.includes('contract'));assert.throws(()=>validateEdgeConfig({window:100000}),/memory/);
});

test('scheduled/manual report windows, cooldown, acknowledgment and bounded retention are consistent',()=>{
  const a=create({reportMinutes:15,alertSeverity:'critical',cooldownMinutes:60});
  for(let i=0;i<100;i++)a.process([packet(i,{load_kw:null})],at(i));
  const s=a.snapshot();assert.equal(s.reports.length,EDGE_LIMITS.reports);assert.equal(s.evidence.length,80);assert.equal(s.history.length,48);assert.equal(s.recent.length,24);
  assert.equal(s.alerts.length,25);assert.equal(s.totals.suppressed,75);assert.equal(s.reports.at(-1).counts.quarantined,1);
  a.acknowledge(s.alerts[0].id);assert.equal(a.snapshot().alerts[0].acknowledged,true);assert.equal(a.report(),null);
  assert.ok(a.export().limitations.length);assert.equal(a.snapshot().nextReport,at(100)+INTERVAL_MS);
});

test('single-sample generation matches complete profiles and preserves real model zero/outage semantics',()=>{
  const meters=JSON.parse(readFileSync(new URL('../public/data/smartds.json',import.meta.url))).topology.servicePoints;
  const zero=meters.find(m=>m.inputLoadKw===0),outage=meters.find(m=>meterOutages(m).length);
  for(const m of [zero,outage]){
    const profile=meterProfile(m),a=createQualityAgent({meters:[m],config:{skills:['anomaly']},start:SCENARIO_START});
    for(let i=0;i<profile.samples.length;i++){
      const sample=virtualMeterSample(m,i);assert.deepEqual(sample,profile.samples[i]);
      const s=a.process([{...packet(i),...sample,meterId:m.id,circuit:m.circuit}],at(i));
      assert.equal(s.recent.at(-1).qualityDecision,'accept');
    }
  }
});

test('controller isolates generations, rejects stale responses and prevents overlapping worker steps',()=>{
  const workers=[],broadcasts=[];
  const controller=createEdgeController({workerFactory:()=>{const w={messages:[],postMessage(m){this.messages.push(m)},terminate(){this.terminated=true}};workers.push(w);return w},broadcast:m=>broadcasts.push(m),clock:()=>1});
  const reply=(w,overrides={})=>{const q=w.messages.at(-1);w.onmessage({data:{id:q.id,runId:q.runId,type:'result',state:{alerts:[],reports:[],complete:false,...overrides}}})};
  controller.configure([meter]);const first=workers[0];reply(first);controller.step();controller.step();assert.equal(first.messages.length,2);
  const state={index:1,qualifiedBatch:[packet(0)],alerts:[{id:'AL-1'}],reports:[{id:'DQ-1'}]};reply(first,state);assert.equal(broadcasts.length,3);assert.equal(broadcasts.find(m=>m.kind==='records').payload.records.length,1);
  controller.report();reply(first,state);assert.equal(broadcasts.length,3);
  controller.configure([meter]);const second=workers[1];reply(second);reply(first,{alerts:[{id:'stale'}]});assert.deepEqual(controller.getState().state.alerts,[]);
  controller.play();assert.equal(controller.getState().status,'running');controller.pause();assert.equal(controller.getState().status,'paused');reply(second);assert.equal(controller.getState().status,'paused');controller.dispose();
});


test('context conflicts do not train baselines or masquerade as coherent grid events',()=>{
  const a=create({skills:['anomaly']});
  for(let i=0;i<9;i++)a.process([packet(i,{power:'off',load_kw:500,voltage_pu:i===8?0:1})],at(i));
  let s=a.snapshot();assert.equal(s.learnedMeters,0);assert.equal(s.totals.gridEvents,0);assert.equal(s.totals.flagged,9);
  s=a.process([packet(9)],at(9));assert.equal(s.recent.at(-1).eventClass,'normal');assert.equal(s.recent.at(-1).qualityDecision,'accept');
  assert.throws(()=>a.process([],at(11)),/exactly one interval/);
});

test('qualified batches preserve values and exclude held records and duplicates; exports identify the full scope',()=>{
  const a=create({reportMinutes:15});
  const s=a.process([packet(0),packet(0),packet(0,{load_kw:null}),packet(0,{timestamp:at(-3)})],at(0));
  assert.equal(s.qualifiedBatch.length,1);assert.equal(s.qualifiedBatch[0].load_kw,5);assert.equal(s.qualifiedBatch[0].forwarded,true);
  assert.equal(s.recent[1].disposition,'suppressed duplicate');assert.ok(s.evidence.some(e=>e.code==='invalid_time'));
  const output=a.export(),report=output.reports[0];
  assert.deepEqual(output.inventory,[meter]);assert.deepEqual(output.scope.meterIds,[meter.id]);assert.ok(output.engineVersion);
  assert.deepEqual(report.scope.circuits,['feeder']);assert.equal(report.onTimeCoveragePct,100);
  assert.equal(report.payloadBytes,new TextEncoder().encode(JSON.stringify(report)).byteLength);
  assert.equal(s.totals.broadcasts,2);
});

test('external inventories require bounded identities and own their metadata and returned state',()=>{
  for(const meters of [[{}],[{id:'',circuit:'F'}],[{id:'M',circuit:null}],[{...meter,id:'x'.repeat(129)}],[{...meter,inputLoadKw:NaN}],[{...meter,allowsExport:'yes'}]])assert.throws(()=>createQualityAgent({meters,start:at(0)}));
  const mutable={...meter},a=createQualityAgent({meters:[mutable],start:at(0)});
  mutable.circuit='changed';
  const reading=packet(0),s=a.process([reading],at(0));
  reading.units.load='W';s.qualifiedBatch[0].units.load='W';s.policy.skills.length=0;s.recent[0].load_kw=500;
  assert.equal(a.snapshot().recent[0].units.load,'kW');assert.equal(a.snapshot().recent[0].load_kw,5);assert.ok(a.snapshot().policy.skills.length);
  const bad=a.process([packet(1,{load_kw:null})],at(1));bad.alerts[0].message='changed';
  assert.notEqual(a.snapshot().alerts[0].message,'changed');
  assert.equal(a.export().inventory[0].circuit,meter.circuit);
});

test('oversized input is rejected before advancing state and policy drops unknown fields',()=>{
  const a=create(),before=a.snapshot();
  assert.throws(()=>a.process([packet(0,{extra:'x'.repeat(4096)})],at(0)),/budget/);
  assert.deepEqual(a.snapshot(),before);
  const many=Array.from({length:192},()=>packet(0,{extra:'x'.repeat(400)}));
  assert.throws(()=>a.process(many,at(0)),/budget/);assert.deepEqual(a.snapshot(),before);
  assert.equal(validateEdgeConfig({largePayload:'ignored'}).largePayload,undefined);
  assert.throws(()=>validateEdgeConfig({intervalMs:910000}),/divide/);
  assert.equal(a.process([packet(0)],at(0)).totals.accepted,1);
});

test('missing intervals interrupt stuck-pair continuity and declared DER export is valid',()=>{
  const a=create();for(let i=0;i<5;i++)a.process([packet(i)],at(i));
  a.process([],at(5));const s=a.process([packet(6)],at(6));
  assert.equal(s.skillCounts.stuck,0);
  const der=createQualityAgent({meters:[{...meter,allowsExport:true}],start:at(0),provenance:{mode:'adapter',source:'Fixture collector',delivery:'Pending adapter'}});
  const output=der.process([packet(0,{load_kw:-2})],at(0));assert.equal(output.totals.accepted,1);
  const report=der.report();assert.equal(report.source,'Fixture collector');assert.equal(report.delivery,'Pending adapter');
  assert.equal(der.export().provenance.mode,'adapter');assert.ok(der.export().limitations.every(l=>!l.includes('Synthetic')));
});

function unpackRuntime(){
  const dir=mkdtempSync(join(tmpdir(),'edge-runtime-test-'));
  execFileSync('tar',['-xzf',new URL('../public/edge/edge-runtime.tar.gz',import.meta.url).pathname,'-C',dir]);
  return dir;
}
test('downloaded runtime screens supplied packets offline, reports silence, and rejects malformed frames',()=>{
  const dir=unpackRuntime();
  try{
    for(const [src,dest] of [['edge-quality.mjs','edge-quality.mjs'],['../edge/edge-runner.mjs','edge-runner.mjs'],['../edge/README.md','README.md']])assert.equal(readFileSync(join(dir,dest),'utf8'),readFileSync(new URL(src,import.meta.url),'utf8'));
    const input=readFileSync(join(dir,'example.ndjson'),'utf8')+'{"type":"acknowledge","alertId":"AL-1"}\n'+JSON.stringify({type:'batch',at:1790815500000,records:[packet(0,{extra:'x'.repeat(70000)})]})+'\n'+JSON.stringify({type:'batch',at:1790815500000,records:[]})+'\n'+JSON.stringify({type:'snapshot'})+'\n';
    const output=execFileSync(process.execPath,[join(dir,'edge-runner.mjs')],{input,encoding:'utf8',timeout:5000}).trim().split('\n').map(JSON.parse);
    assert.equal(output[0].type,'configured');
    const qualified=output.filter(x=>x.type==='qualified_records');assert.equal(qualified.length,4);assert.equal(qualified[0].records[0].load_kw,-2);assert.equal(qualified[1].records.length,0);
    assert.equal(output.filter(x=>x.type==='report').length,4);
    assert.ok(output.some(x=>x.type==='alert'&&x.payload.code==='invalid_contract'));
    assert.ok(output.some(x=>x.type==='alert'&&x.payload.code==='missing_interval'));
    assert.ok(output.some(x=>x.type==='error'&&/64 KiB/.test(x.message)));
    assert.equal(output.at(-1).state.totals.expected,4);assert.equal(output.at(-1).state.totals.missing,2);
    assert.ok(output.at(-1).state.alerts.find(a=>a.id==='AL-1').acknowledged);
    assert.equal(new Set(output.map(x=>x.runId)).size,1);
  }finally{rmSync(dir,{recursive:true,force:true})}
});

test('live downloaded runtime advances empty intervals without incoming readings', {timeout:10000},async()=>{
  const dir=unpackRuntime(),child=spawn(process.execPath,[join(dir,'edge-runner.mjs'),'--live'],{stdio:['pipe','pipe','pipe']});
  try{
    const result=await new Promise((resolve,reject)=>{
      let text='',errors='';const outputs=[];
      const timeout=setTimeout(()=>reject(Error('Live interval did not complete: '+errors)),6000);
      child.stderr.on('data',c=>{errors+=c});child.on('error',reject);
      child.stdout.on('data',chunk=>{
        text+=chunk;let at;
        while((at=text.indexOf('\n'))>=0){
          const row=JSON.parse(text.slice(0,at));text=text.slice(at+1);outputs.push(row);
          if(row.type==='qualified_records'){child.stdin.write('{"type":"report"}\n');}
          if(row.type==='report'){clearTimeout(timeout);child.stdin.end();resolve(outputs)}
          if(row.type==='error'){clearTimeout(timeout);reject(Error(row.message))}
        }
      });
      child.stdin.write(JSON.stringify({type:'configure',source:'Silent fixture collector',meters:[meter],config:{intervalMs:1000,alertSeverity:'warning'}})+'\n');
    });
    const batch=result.find(x=>x.type==='qualified_records');assert.equal(batch.totals.missing,1);assert.equal(batch.records.length,0);
    assert.ok(result.some(x=>x.type==='alert'&&x.payload.code==='missing_interval'));
    assert.equal(result.find(x=>x.type==='report').payload.counts.missing,1);
  }finally{child.kill();rmSync(dir,{recursive:true,force:true})}
});
