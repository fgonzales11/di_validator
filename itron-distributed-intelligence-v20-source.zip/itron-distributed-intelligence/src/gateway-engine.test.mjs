import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {execFileSync,spawnSync} from 'node:child_process';
import {createGateway,createPMUMonitor,allocatePower,GATEWAY_LIMITS} from './gateway-engine.mjs';
import {createGatewayController} from './gateway-controller.js';
const near=(a,b,t=1e-7)=>assert.ok(Math.abs(a-b)<t,`${a} ≠ ${b}`);
const frames=(second,f=60)=>Array.from({length:60},(_,i)=>({timestamp:(second-1)*1000+(i+1)*1000/60,frequencyHz:f,voltagePu:1,angleDeg:0}));
const telemetry=(second,extra={})=>({timestamp:second,baseLoadKw:180,solarFactor:1,gridAvailable:true,wanOnline:true,syncAngleDeg:2,pmuFrames:frames(second),...extra});

test('shared dispatch conserves power and respects import/export, charger, energy and reserve limits',()=>{
 for(const config of [{},{fleetSize:128,importLimitKw:60},{fleetSize:1,baseLoadKw:0,responseKw:500,exportLimitKw:0},{reservePct:80,importLimitKw:0}]){
  const g=createGateway(config),start=g.snapshot().batteries.map(b=>b.energyKwh);g.action('solar',false);g.action('peak',true);
  for(let i=0;i<120;i++){
   const s=g.step(),p=s.plan;near(p.balanceResidualKw,0);assert.ok(p.gridKw<=s.config.importLimitKw+1e-7);assert.ok(p.gridKw>=-s.config.exportLimitKw-1e-7);
   for(const v of s.vehicles){assert.ok(v.powerKw>=0&&v.powerKw<=v.maxKw+1e-8);assert.ok(v.remainingKwh>=-1e-8);near(v.remainingKwh+v.deliveredKwh,v.initialKwh)}
   for(const f of s.flex)assert.ok(f.powerKw<=f.maxKw+1e-8);
   for(const [j,b] of s.batteries.entries()){assert.ok(b.energyKwh>=0&&b.energyKwh<=b.capacityKwh);assert.ok(Math.abs(b.powerKw)<=b.maxKw+1e-8);if(s.config.reservePct===80)assert.ok(b.energyKwh<=start[j]+1e-8)}
  }
 }
 near(allocatePower([{cap:1,weight:10},{cap:10,weight:1}],5).reduce((a,b)=>a+b),5);
});

test('WAN outage preserves dispatch, bounds summaries and never replays actuator commands',()=>{
 const g=createGateway();g.action('wan',false);for(let i=0;i<40;i++)g.step();let s=g.snapshot();assert.equal(s.mode,'grid-connected');assert.equal(s.stats.localCyclesOffline,40);assert.equal(s.uplink.pending,24);assert.equal(s.stats.uplinkDropped,16);const commands=s.stats.commandsIssued;
 g.action('wan',true);s=g.step();assert.equal(s.uplink.pending,0);assert.equal(s.stats.uplinkSent,25);assert.equal(s.stats.commandsIssued-commands,s.lastCommand.setpoints.length);assert.equal(s.lastCommand.timestamp,41);assert.equal(g.export().commands.length,32);
});

test('islanding needs a grid-forming resource, maintains zero interchange and reconnects only after fresh stable dwell',()=>{
 const g=createGateway({reconnectSeconds:3});g.step();g.action('grid',false);let s=g.step();assert.equal(s.plan.pccClosed,false);near(s.plan.gridKw,0);assert.equal(s.plan.evKw,0);s=g.step();assert.equal(s.mode,'islanded');
 g.action('der','BESS-1');s=g.step();assert.equal(s.mode,'deenergized');assert.equal(s.plan.energized,false);assert.ok(s.plan.criticalUnservedKw>0);near(s.plan.gridKw,0);
 g.action('der','BESS-1');g.action('grid',true);g.action('sync',12);for(let i=0;i<5;i++)assert.notEqual(g.step().mode,'grid-connected');g.action('sync',2);assert.equal(g.step().mode,'resynchronizing');assert.equal(g.step().mode,'resynchronizing');assert.equal(g.step().mode,'grid-connected');
});

test('PMU screening rejects nonfinite/out-of-order samples without losing the watermark and never bridges ROCOF gaps',()=>{
 const p=createPMUMonitor();const frame={timestamp:1000,frequencyHz:60,voltagePu:1,angleDeg:179};p.ingest([frame]);frame.frequencyHz=0;
 p.ingest([{...frame,timestamp:900,frequencyHz:60},{...frame,timestamp:910,frequencyHz:60}]);assert.equal(p.snapshot().valid,1);assert.equal(p.snapshot().rejected,2);p.ingest([{timestamp:1033.333,frequencyHz:59,voltagePu:1,angleDeg:-179}]);assert.equal(p.snapshot().maxAbsRocofHzS,null);
 const silent=createPMUMonitor({startTimestamp:0});silent.ingest([],1000);assert.equal(silent.snapshot().missing,60);silent.ingest(frames(2),2000);assert.equal(silent.snapshot().missing,60);
 const gap=createPMUMonitor();gap.ingest([{timestamp:1000,frequencyHz:60,voltagePu:1,angleDeg:0},{timestamp:1016.666666,frequencyHz:NaN,voltagePu:1,angleDeg:0},{timestamp:1100,frequencyHz:60,voltagePu:1,angleDeg:0}]);assert.equal(gap.snapshot().missing,4);assert.equal(gap.snapshot().rejected,1);assert.equal(gap.snapshot().maxAbsRocofHzS,null);
 const eventMonitor=createPMUMonitor();eventMonitor.ingest(frames(1));let events=eventMonitor.ingest(frames(2,59.4));assert.equal(events.filter(e=>e.kind==='pmu_event').length,1);near(events[0].detectedAfterMs,1000/30,1e-5);assert.equal(eventMonitor.snapshot().snippets[0].samples.length,36);assert.equal(eventMonitor.completedSnippets().length,1);assert.equal(eventMonitor.completedSnippets().length,0);eventMonitor.ingest(frames(3));assert.equal(eventMonitor.snapshot().disturbance,false);
 for(let i=4;i<20;i++)eventMonitor.ingest(frames(i));assert.equal(eventMonitor.snapshot().series.length,GATEWAY_LIMITS.pmuFrames);assert.equal(eventMonitor.snapshot().modelBufferBytes,7680);
});

test('adapter PMU timestamps and dropouts cannot falsely authorize reconnection',()=>{
 const g=createGateway({reconnectSeconds:3});assert.throws(()=>g.step(null),/telemetry/);assert.throws(()=>g.step(undefined),/telemetry/);assert.equal(g.snapshot().seconds,0);g.step(telemetry(1,{gridAvailable:false}));
 assert.throws(()=>g.step(telemetry(2,{pmuFrames:[{timestamp:1e12,frequencyHz:60,voltagePu:1,angleDeg:0}]})),/timestamps/);assert.equal(g.snapshot().seconds,1);
 for(let i=2;i<8;i++){const s=g.step(telemetry(i,{pmuFrames:frames(i).slice(-1)}));assert.notEqual(s.mode,'grid-connected');assert.equal(s.stats.commandsApplied,0)}
 for(let i=8;i<10;i++)assert.notEqual(g.step(telemetry(i)).mode,'grid-connected');assert.equal(g.step(telemetry(10)).mode,'grid-connected');
});

test('DER consent changes reallocate the common budget and infeasible requests expose shortfall',()=>{
 const g=createGateway({fleetSize:128,importLimitKw:50,responseKw:500});g.step();g.action('der','BESS-2');let s=g.step();assert.equal(s.batteries[1].powerKw,0);assert.ok(s.plan.responseShortfallKw>0);assert.ok(s.plan.gridKw<=50+1e-7);near(s.plan.achievedResponseKw,s.plan.flexShedKw+s.plan.batteryKw-s.plan.curtailedPvKw);
 for(let i=0;i<180;i++)s=g.step();assert.ok(s.stats.deadlineMisses>0);for(const v of s.vehicles.filter(v=>v.departureSeconds<s.seconds))assert.equal(v.powerKw,0);
});

test('gateway controller serializes work and ignores messages from replaced generations',()=>{
 const workers=[];const c=createGatewayController({workerFactory:()=>{const w={messages:[],postMessage(m){this.messages.push(m)},terminate(){this.terminated=true}};workers.push(w);return w}});
 const reply=(w,state={cycles:0})=>{const q=w.messages.at(-1);w.onmessage({data:{id:q.id,generation:q.generation,state}})};
 c.configure({});const w=workers[0];reply(w);c.step();c.step();assert.equal(w.messages.length,2);reply(w,{cycles:1});c.configure({});reply(workers[1]);reply(w,{cycles:99});assert.equal(c.getState().state.cycles,0);c.dispose();
});

test('downloadable gateway runtime runs offline and emits bounded local simulation dispatch',()=>{
 const stage=mkdtempSync(join(tmpdir(),'gateway-test-'));try{
 execFileSync('tar',['-xzf',new URL('../public/gateway/gateway-runtime.tar.gz',import.meta.url).pathname,'-C',stage]);
 const input=[{type:'configure',mode:'simulation'},{type:'simulation_action',kind:'wan',value:false},{type:'simulation_action',kind:'grid',value:false},{type:'export'},{type:'telemetry'},{type:'telemetry',telemetry:null}].map(JSON.stringify).join('\n')+'\n';
 const result=spawnSync(process.execPath,[join(stage,'gateway-runner.mjs')],{input,encoding:'utf8',timeout:5000});assert.equal(result.status,0,result.stderr);const rows=result.stdout.trim().split('\n').map(JSON.parse);assert.equal(rows[0].type,'configured');assert.equal(rows[1].state.stats.localCyclesOffline,1);assert.equal(rows[2].dispatch.setpoints.find(x=>x.assetId==='PCC').position,'open');assert.equal(rows[3].data.plan.gridKw,0);assert.equal(rows[4].type,'error');assert.equal(rows[5].type,'error');for(const [file,source] of [['gateway-engine.mjs','./gateway-engine.mjs'],['gateway-runner.mjs','../gateway/gateway-runner.mjs'],['README.md','../gateway/README.md']])assert.equal(readFileSync(join(stage,file),'utf8'),readFileSync(new URL(source,import.meta.url),'utf8'));
 }finally{rmSync(stage,{recursive:true,force:true})}
});
