import test from 'node:test';
import assert from 'node:assert/strict';
import { runForecast, scoreForecast, residualBandRadius } from './forecast-model.mjs';

const noWait = { yieldControl: async () => {} };
const config = { horizon: 24, validationWindows: 3, contextLength: 168, maxHistory: 1000, seasonLength: 24, lags: 24, ridge: 0.001 };
function series(length = 400, value = i => 10 + i * 0.03 + 2 * Math.sin(i * 2 * Math.PI / 24)) {
  return { timestamps: Array.from({ length }, (_, i) => Date.UTC(2026, 0, 1) + i * 3600000),
    values: Array.from({ length }, (_, i) => value(i)), channel: 'load', unit: 'kW', source: 'Deterministic test fixture', synthetic: true };
}

test('splits are chronological, context bounded, and nonoverlapping', async () => {
  const result = await runForecast(series(), config, noWait);
  assert.equal(result.splits.length, 4);
  assert.deepEqual(result.splits.map(s => s.testStartIndex), [304, 328, 352, 376]);
  for (const split of result.splits) {
    assert.equal(split.trainEndIndexExclusive, split.testStartIndex);
    assert.equal(split.testEndIndexExclusive - split.testStartIndex, 24);
    assert.equal(split.trainEndIndexExclusive - split.trainStartIndex, 168);
    assert.ok(split.trainEnd < split.testStart);
  }
  for (let i = 1; i < result.splits.length; i++)
    assert.equal(result.splits[i - 1].testEndIndexExclusive, result.splits[i].testStartIndex);
  for (const model of result.models) {
    assert.equal(model.predictions.future.timestamps[0], series().timestamps.at(-1) + 3600000);
    assert.ok(model.predictions.future.actual.every(v => v === null));
  }
});

test('final holdout cannot change validation predictions or winner; future refits see new observations', async () => {
  const first = series(), altered = series();
  altered.values.splice(376, 24, ...Array.from({ length: 24 }, (_, i) => 50 + i * 2));
  const before = await runForecast(first, config, noWait), after = await runForecast(altered, config, noWait);
  assert.equal(before.selectedModel, after.selectedModel);
  for (let i = 0; i < before.models.length; i++) {
    assert.deepEqual(before.models[i].validation, after.models[i].validation);
    assert.deepEqual(before.models[i].predictions.validation, after.models[i].predictions.validation);
    assert.deepEqual(before.models[i].predictions.holdout.prediction, after.models[i].predictions.holdout.prediction);
    assert.notDeepEqual(before.models[i].predictions.future.prediction, after.models[i].predictions.future.prediction);
  }
});

test('winner remains frozen even when another model wins the final holdout', async () => {
  const data = series();
  // Make the final holdout exactly equal to seasonal-naive predictions. Its
  // validation windows still contain a trend which ridge predicts better.
  data.values.splice(376, 24, ...data.values.slice(352, 376));
  const result = await runForecast(data, config, noWait);
  const naive = result.models.find(m => m.model === 'seasonal_naive');
  const ridge = result.models.find(m => m.model === 'ridge_autoregression');
  assert.ok(ridge.validation.mae < naive.validation.mae);
  assert.equal(naive.holdout.mae, 0);
  assert.ok(ridge.holdout.mae > 0);
  assert.equal(result.selectedModel, 'ridge_autoregression');
});

test('seasonal naive repeats exactly and constant histories stay finite', async () => {
  const data = series(400, i => i % 24);
  const result = await runForecast(data, { ...config, models: ['seasonal_naive'] }, noWait);
  assert.equal(result.models[0].validation.mae, 0);
  assert.equal(result.models[0].holdout.mae, 0);
  assert.deepEqual(result.models[0].predictions.future.prediction, data.values.slice(-24));
  const constant = await runForecast(series(400, () => 5), config, noWait);
  for (const model of constant.models) {
    assert.equal(model.holdout.mae, 0);
    assert.equal(model.holdout.mase, null);
    assert.ok(model.predictions.future.prediction.every(v => v === 5));
  }
});

test('metrics and empirical higher-quantile bands match definitions', () => {
  const score = scoreForecast([1, 2], [2, 4], [0, 1, 2, 3], 1);
  assert.equal(score.mae, 1.5);
  assert.equal(score.rmse, Math.sqrt(2.5));
  assert.equal(score.smape, 200 / 3);
  assert.equal(score.wape, 100);
  assert.equal(score.mase, 1.5);
  assert.equal(scoreForecast([0, 0], [0, 0], [0, 0, 0], 1).wape, null);
  assert.equal(residualBandRadius(Array(10).fill(0), Array.from({ length: 10 }, (_, i) => i)), 9);
});

test('clean errors for gaps, missing data, unknown models, limits, and too little history', async () => {
  const missing = series(); missing.values[4] = null;
  const gap = series(); gap.timestamps[10] += 1;
  const duplicate = series(); duplicate.timestamps[2] = duplicate.timestamps[1];
  for (const [data, c, pattern] of [
    [missing, config, /missing or nonfinite/], [gap, config, /Irregular sampling/],
    [duplicate, config, /strictly increasing/], [series(100), config, /Insufficient history/],
    [series(), { ...config, ridge: 0 }, /ridge must/],
    [series(), { ...config, lags: 100 }, /lags must/],
    [series(), { ...config, models: ['xgboost'] }, /supported models/],
  ]) await assert.rejects(runForecast(data, c, noWait), pattern);
});

test('worker-style cancellation executes at yielded task boundaries', async () => {
  let cancelled = false, yields = 0;
  await assert.rejects(runForecast(series(), config, {
    isCancelled: () => cancelled,
    yieldControl: async () => { if (++yields === 3) cancelled = true; },
  }), error => error.name === 'AbortError');
  assert.equal(yields, 3);
});

test('source history remains unchanged and tie-breaking is deterministic', async () => {
  const data = series(400, () => 0), original = structuredClone(data);
  const result = await runForecast(data, config, noWait);
  assert.deepEqual(data, original);
  assert.equal(result.selectedModel, 'ridge_autoregression');
});

test('external estimators receive only a bounded training prefix, never future targets', async () => {
  const data = series(), fits = [];
  const result = await runForecast(data, { ...config, models: ['random_forest', 'skforecast_boosting'] }, {
    ...noWait,
    fitPredict: async payload => {
      fits.push(payload);
      assert.deepEqual(Object.keys(payload).sort(), ['config', 'future', 'model', 'times', 'values']);
      assert.equal(payload.values.length, 168);
      assert.ok(payload.times.at(-1) < payload.future[0]);
      const stop = data.timestamps.indexOf(payload.times.at(-1)) + 1;
      assert.deepEqual(payload.values, data.values.slice(stop - 168, stop));
      return { prediction: payload.future.map(() => payload.values.at(-1)), artifact: { trainedThrough: payload.times.at(-1) } };
    },
  });
  assert.equal(fits.length, 10);
  assert.ok(result.models.every(m => m.status === 'completed'));
  assert.ok(result.models.every(m => m.artifact.trainedThrough === data.timestamps.at(-1)));
});

test('failed providers remain explicit; invalid outputs never enter model scoring', async () => {
  const result = await runForecast(series(), { ...config, models: ['seasonal_naive', 'random_forest', 'skforecast_boosting'] }, {
    ...noWait, fitPredict: async ({ model }) => {
      if (model === 'random_forest') throw Error('Package download unavailable');
      return { prediction: [NaN] };
    },
  });
  assert.equal(result.selectedModel, 'seasonal_naive');
  assert.deepEqual(result.models.map(m => m.status), ['completed', 'failed', 'failed']);
  assert.match(result.models[1].error, /download unavailable/);
  assert.match(result.models[2].error, /invalid predictions/);
  await assert.rejects(runForecast(series(), { ...config, models: ['random_forest'] }, noWait), /runtime is unavailable/);
});

test('a selected provider failing at holdout cannot silently change the selected model', async () => {
  let calls = 0;
  await assert.rejects(runForecast(series(400, () => 0), { ...config, models: ['random_forest', 'seasonal_naive'] }, {
    ...noWait, fitPredict: async ({ future }) => {
      if (++calls > config.validationWindows) throw Error('Holdout fit failed');
      return { prediction: future.map(() => 0) };
    },
  }), /Holdout fit failed/);
});
