import { icon } from './icons.js';

const transformerArt = `<svg class="transformer-art" viewBox="0 0 240 166" fill="none" aria-hidden="true">
  <defs><linearGradient id="transformer-fill" x1="50" y1="30" x2="177" y2="158" gradientUnits="userSpaceOnUse"><stop stop-color="#345365" stop-opacity=".4"/><stop offset="1" stop-color="#0c2632" stop-opacity=".1"/></linearGradient><linearGradient id="transformer-line" x1="40" y1="30" x2="176" y2="153" gradientUnits="userSpaceOnUse"><stop stop-color="#93c2cd"/><stop offset="1" stop-color="#456c7b"/></linearGradient></defs>
  <g stroke="#2b4f60" stroke-width=".65" opacity=".7"><path d="m19 73 117-55 95 43M12 97 117-49 94 43M10 123l121-56 95 41M35 145l95-45 85 37M26 130l84 38M46 120l84 39M67 110l85 40M87 101l85 39M108 91l86 41M24 137l113-52M40 145l114-53M58 153l114-53"/></g>
  <g stroke="url(#transformer-line)" stroke-width=".85" stroke-linejoin="round">
    <path d="m91 115 38-18 46 22-38 18-46-22Z" fill="#0a202b"/>
    <path d="m66 73 43-20 48 21v51l-43 21-48-22V73Z" fill="url(#transformer-fill)"/>
    <path d="m66 73 48 21 43-20M114 94v52M70 77v45l40 18V95L70 77Z"/>
    <path d="m118 97 35-17v42l-35 18V97Z"/>
    <path d="M73 80v41m4-39v41m4-39v41m4-39v41m4-39v41m4-39v41m4-39v41m4-39v41m4-39v41M121 96v42m4-44v42m4-44v42m4-44v42m4-44v42m4-44v42m4-44v42m4-44v42" opacity=".55"/>
    <path d="m69 72 40-17 44 19-40 17-44-19Z"/>
    <path d="m74 72 35-14 37 16-33 14-39-16Z"/>
    <path d="m81 69 26-10 32 14-26 10-32-14Z" opacity=".55"/>
    <path d="m86 67 3-1 3 1v8l-3 1-3-1v-8Zm14-7 3-1 3 1v8l-3 1-3-1v-8Zm16 6 3-1 3 1v8l-3 1-3-1v-8Z" fill="#183a48"/>
    <path d="M89 66V44l31-15m-17 30V43l30-14m-14 36V48l28-14"/>
    <path d="m164 20 4-2 4 2v115l-4 2-4-2V20Z" fill="#15343e"/>
    <path d="M168 23v112m-4-106 8-4m-8 13 8-4m-8 22 8-4m-8 22 8-4m-8 22 8-4m-8 22 8-4"/>
    <path d="m131 36 48-23 4 2-48 23-4-2Z" fill="#193b45"/>
    <path d="m133 39 48-23v5l-48 23v-5Z"/>
    <path d="M139 32v-8l2-1 2 1v7m20-10v-8l2-1 2 1v7m11-6V6l2-1 2 1v7"/>
    <path d="M141 24c-33 22-60 35-114 51m139-61C132 38 90 52 48 71m133-65c-19 10-63 21-86 35m85-26c13 17 33 26 51 32" opacity=".75"/>
    <path d="m155 137 12-6 14 7-13 6-13-7Zm-74-12-5 2 37 17 6-2M121 145l6 3 35-17-6-3"/>
  </g>
  <g stroke="#76a3b2" stroke-width=".8" opacity=".5"><path d="m48 140 58 26m69-18 30-14m-16-1 8 4-12 6-8-4" stroke-dasharray="2 3"/></g>
</svg>`;

function railButton(panel, glyph, label, active = false) {
  return `<button class="rail-button${active ? ' is-active' : ''}" data-panel="${panel}" title="${label}" aria-label="${label}" ${active ? 'aria-current="page"' : ''}>${icon(glyph, 21)}<span>${label}</span></button>`;
}

function layerSwitch(layer, glyph, label, checked = true) {
  return `<label class="layer-row"><span class="layer-icon layer-icon--${layer}">${icon(glyph, 20)}</span><span>${label}</span><input type="checkbox" data-layer="${layer}" aria-label="Show ${label.toLowerCase()}" ${checked ? 'checked' : ''}><span class="switch-track" aria-hidden="true"></span></label>`;
}

export function renderUI() {
  return `
  <header class="app-header">
    <div class="brand-group"><a class="gridscope-logo" href="#" aria-label="GridScope Outage Analyzer">Itron<span class="logo-spark"></span></a><span class="header-divider"></span><span class="product-name">Outage Analyzer</span><span class="header-divider region-divider"></span><span class="region-name">SMARTDS <span>/</span> SFO · P3R</span></div>
    <nav class="top-nav" aria-label="Application"><button data-view="overview">Overview</button><button class="is-active" data-view="outages" aria-current="page">Outage analysis</button><button data-view="network">Network</button><button data-view="scenarios">Scenarios</button></nav>
    <div class="header-tools"><a class="analyzer-link" href="/transformer-analyzer/" title="Open Transformer Analyzer" aria-label="Open Transformer Analyzer">${icon('network',18)}<span>Transformers ↗</span></a><button id="theme-toggle" class="theme-toggle" type="button" title="Switch to light mode" aria-label="Switch to light mode">${icon('sun', 18)}<span>Light mode</span></button><button id="about-button" class="avatar" title="About this study" aria-label="About this study">${icon('info', 18)}</button></div>
  </header>
  <aside class="app-rail" aria-label="Map tools"><div class="rail-main">${railButton('map', 'map', 'Map', true)}${railButton('layers', 'layers', 'Layers')}${railButton('search', 'search', 'Search')}${railButton('bookmarks', 'bookmark', 'Bookmarks')}${railButton('data', 'database', 'Data')}</div><div class="rail-bottom">${railButton('settings', 'settings', 'Settings')}</div></aside>
  <main class="workspace" id="workspace">
    <div id="scene-container" aria-label="Interactive three-dimensional SFO · P3R electrical network"></div>
    <div class="scene-vignette" aria-hidden="true"></div>
    <div id="loading-state" class="loading-state" role="status"><span class="loading-orbit"></span><span>Bringing the network into view<span class="loading-dots">…</span></span></div>
    <div class="view-heading"><div class="eyebrow view-eyebrow">NETWORK INTELLIGENCE</div><h1 id="app-title">See the network. Restore with clarity.</h1><p id="app-subtitle">SFO · P3R <span>•</span> Restoration analysis</p></div>
    <div id="network-tooltip" class="network-tooltip" role="tooltip" hidden></div>
    <div id="map-tooltip" class="map-tooltip" hidden><span class="tooltip-name"></span><span></span></div>
    <section class="glass-panel summary-card" id="summary-card" aria-labelledby="summary-heading">
      <div class="panel-eyebrow" id="summary-heading">OUTAGE SUMMARY</div>
      <div class="summary-stats"><div class="summary-stat"><strong id="stat-feeder">2</strong><span class="status-dot coral"></span><span>Feeder outages</span></div><div class="summary-stat"><strong id="stat-transformer">29</strong><span class="status-dot amber"></span><span>Transformer outages</span></div><div class="summary-stat"><strong id="stat-service">156</strong><span class="status-dot amber"></span><span>Service point outages</span></div></div>
      <div class="study-totals"><span><strong id="study-service-points">—</strong> service points</span><span class="mini-divider"></span><span><strong id="study-events">—</strong> events</span></div>
      <div class="study-period">Virtual scenario · UTC <span>Study totals</span></div>
      <div class="panel-rule"></div>
      <div class="panel-eyebrow layers-heading">MAP LAYERS<span>${icon('layers', 15)}</span></div>
      <div class="layer-switches">${layerSwitch('network', 'network', 'Network')}${layerSwitch('servicePoints', 'points', 'Service points', false)}${layerSwitch('outages', 'bars', 'Outage volumes')}${layerSwitch('buildings', 'building', 'Schematic context')}</div>
    </section>
    <section class="glass-panel asset-card" id="asset-card" aria-labelledby="asset-name" hidden>
      <div class="asset-heading"><div><h2 id="asset-name">Network</h2><p id="asset-circuit">Select a circuit</p></div><button id="close-inspector" class="icon-button inspector-close" title="Close asset inspector" aria-label="Close asset inspector">${icon('close', 17)}</button></div>
      <div id="asset-status" class="asset-status"><span class="status-dot amber"></span>Outage cluster</div>
      <div class="asset-art-wrap">${transformerArt}<span class="asset-art-label">NETWORK EQUIPMENT</span></div>
      <div class="asset-metrics"><div><strong id="asset-voltage">13.2 kV</strong><span>Nominal voltage</span></div><div><strong id="asset-phases">A · B · C</strong><span>Phases</span></div></div>
      <p id="selected-location" class="asset-location" hidden></p>
      <button id="street-view-button" class="explore-button street-view-button" aria-controls="street-view-panel" aria-expanded="false" disabled>Street View</button>
      <button id="explore-circuit" class="explore-button">Explore circuit ${icon('arrowRight', 17)}</button>
      <button id="run-powerflow" class="explore-button powerflow-button">Run power flow ${icon('arrowRight', 17)}</button>
    </section>
    <section id="street-view-panel" class="glass-panel street-view-panel" role="region" aria-labelledby="street-view-heading" hidden>
      <header class="street-view-heading"><div><h2 id="street-view-heading">Street View</h2><p id="street-view-coordinates" aria-live="polite"></p></div><button id="close-street-view" class="icon-button" aria-label="Close Street View" title="Close Street View">${icon('close', 18)}</button></header>
      <div class="street-view-content"><div id="street-view-frame-container"></div><div id="street-view-status" class="street-view-status" role="status" hidden></div></div>
      <footer class="street-view-footer"><span id="street-view-basis">Model location · nearby imagery</span><a id="street-view-external" target="_blank" rel="noopener noreferrer">Open in Google Maps</a></footer>
    </section>
    <div class="map-controls" aria-label="Map camera controls"><button id="reset-view" class="compass-control" title="Reset map view" aria-label="Reset map view"><span>N</span>${icon('compass', 23)}</button><div class="control-stack"><button id="zoom-in" title="Zoom in" aria-label="Zoom in">${icon('plus', 20)}</button><button id="zoom-out" title="Zoom out" aria-label="Zoom out">${icon('minus', 20)}</button></div><div class="control-stack map-mode"><button data-map-mode="2d" title="View map in 2D" aria-label="View map in 2D">2D</button><button data-map-mode="3d" class="is-active" title="View map in 3D" aria-label="View map in 3D" aria-pressed="true">3D</button></div></div>
    <section class="glass-panel timeline-panel" id="timeline-panel" aria-labelledby="replay-heading">
      <div class="timeline-header"><h2 id="replay-heading">Restoration replay <span id="replay-state" class="replay-state"></span></h2><span id="tour-status" class="tour-status" role="status" aria-live="polite"></span><div class="chart-summary"><span class="chart-description" title="Histogram bars count restoration events. Map column heights represent cumulative outage hours.">Restoration events</span><span class="legend-item"><i class="legend-dot amber"></i>Upcoming</span><span class="legend-item"><i class="legend-dot aqua"></i>Restored</span></div></div>
      <div class="timeline-content"><div class="replay-actions"><button id="play-replay" class="play-button" title="Play restoration replay" aria-label="Play restoration replay">${icon('play', 23)}</button><button id="replay-speed" class="speed-button" title="Change replay speed" aria-label="Replay speed 0.75 times. Change speed">0.75×</button></div><div class="range-label range-label-start" id="range-start"><strong>Sep 17, 2026</strong><span>00:00</span></div><div class="replay-plot"><div class="replay-current-time" id="replay-time">—</div><div id="histogram" class="histogram" aria-hidden="true"></div><input id="replay-slider" class="replay-slider" type="range" min="0" max="1000" value="0" aria-label="Restoration replay time"><div class="chart-axis" aria-hidden="true"><span>Sep 17</span><span>Sep 18</span><span>Sep 19</span><span>Sep 20</span><span>Sep 21</span><span>Sep 22</span><span>Sep 23</span><span>Sep 24</span></div></div><div class="range-label range-label-end" id="range-end"><strong>Sep 24, 2026</strong><span>24:00</span></div></div>
    </section>
    <footer class="map-footer"><span id="view-hint">Left-drag to pan <span>·</span> Right-drag to orbit <span>·</span> Scroll to zoom</span><span class="map-provenance">SMARTDS topology <span>·</span> Schematic context</span></footer>
    <aside id="drawer" class="glass-panel drawer" hidden aria-labelledby="drawer-title"><div class="drawer-header"><div><span class="panel-eyebrow">WORKSPACE</span><h2 id="drawer-title">Network</h2></div><button id="close-drawer" class="icon-button" title="Close panel" aria-label="Close panel">${icon('close', 20)}</button></div><div id="drawer-body" class="drawer-body"></div></aside>
    <div id="toast" class="toast" role="status" hidden></div>
  </main>
  <dialog id="about-dialog" class="about-dialog"><div class="dialog-heading"><div><span class="panel-eyebrow">GRIDSCOPE / NETWORK INTELLIGENCE</span><h2>Clarity, across the network.</h2></div><button id="close-about" class="icon-button" title="Close about dialog" aria-label="Close about dialog">${icon('close', 22)}</button></div><p id="about-study-description"></p><div class="about-note"><span class="status-dot aqua"></span><div><strong>Real network. Schematic context.</strong><p>Network coordinates come from the SMARTDS study. Building and pole heights are schematic, and surrounding geometry is representative. Raw notification identifiers are not included.</p></div></div><p id="about-study-totals"></p><p>Timeline bars count restoration events. Map column heights show cumulative outage hours.</p><div class="keyboard-help"><span>Orbit the network</span><kbd>Right-drag</kbd><span>Move across the map</span><kbd>Left-drag</kbd><span>Look closer</span><kbd>Scroll</kbd><span>Close a panel</span><kbd>Esc</kbd></div><p class="dialog-footnote" id="about-study-window"></p></dialog>`;
}
