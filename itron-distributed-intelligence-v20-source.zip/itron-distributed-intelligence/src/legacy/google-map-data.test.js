import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {googleNetworkData,googleNetworkCamera,googlePosition} from './google-map-data.js';
import {transformerNetworkData} from './transformer-map.js';

test('Google overlays preserve exact transformer/bus locations and line bends in the selected feeder',()=>{
  const study=JSON.parse(readFileSync(new URL('../../public/data/smartds.json',import.meta.url)));
  const baseline=JSON.parse(readFileSync(new URL('../../public/data/transformer-baseline.json',import.meta.url)));
  const links=JSON.parse(readFileSync(new URL('../../public/data/transformer-meter-groups.json',import.meta.url))).links;
  const transformers=baseline.transformers.filter(t=>!t.isRegulator);
  const buses=new Map(study.topology.buses.map(b=>[b.id,b]));
  let count=0;
  for(const circuit of baseline.circuits){
    const scope=transformerNetworkData(study.topology,transformers,links,circuit.id);
    const before=JSON.stringify(scope),data=googleNetworkData(study,scope);
    assert.equal(data.transformers.length,scope.transformers.length);
    assert.equal(data.servicePoints.length,scope.servicePoints.length);
    assert.ok(data.transformers.every(t=>t.asset.circuit===circuit.id));
    for(const {asset,position} of data.transformers){
      const candidates=[asset.secondaryBusIndex,...(asset.secondaryBusIndices||[]),...(asset.primaryBusIndices||[]),...asset.windingBuses];
      assert.ok(candidates.some(id=>{const bus=buses.get(circuit.id+'/bus/'+id);return bus&&position.lat===bus.latitude&&position.lng===bus.longitude}));
      count++;
    }
    for(const {asset,path} of data.lines){
      assert.equal(path.length,asset.points.length);
      for(const [key,i] of [['fromBus',0],['toBus',path.length-1]]){
        const bus=buses.get(asset[key]);if(!bus)continue;
        assert.deepEqual(path[i],{lat:bus.latitude,lng:bus.longitude,altitude:0});
      }
    }
    const camera=googleNetworkCamera(data);
    assert.ok(camera.range>=450&&Number.isFinite(camera.range));
    assert.equal(JSON.stringify(scope),before);
  }
  assert.equal(count,1717);
});

test('Google coordinates preserve zero, reject invalid points, and fit tall/narrow map frames',()=>{
  assert.deepEqual(googlePosition({lat:0,lon:0}),{lat:0,lng:0,altitude:0});
  for(const p of [null,{lat:NaN,lon:1},{lat:0,lon:181}])assert.equal(googlePosition(p),null);
  assert.equal(googleNetworkCamera({transformers:[],lines:[]}),null);
  const data={transformers:[{position:{lat:37,lng:-122}},{position:{lat:37.001,lng:-121.9}}],lines:[]};
  assert.ok(googleNetworkCamera(data,.6).range>googleNetworkCamera(data,2).range);
});
