export const DEFAULT_PARAMETERS = Object.freeze({ tol_vmag_pu: 1e-6, tol_vang_rad: 1e-6, MaxIter: 100, run_control: true });

export function resultSummary(result) {
  const finite = values => values.filter(value => typeof value === 'number' && Number.isFinite(value));
  const lines = result.tables?.res_line || [], windings = result.tables?.res_trafo || [];
  const lineLoads = finite(lines.map(row => row.loading_percent));
  const windingLoads = finite(windings.map(row => row.loading_percent));
  const lossRows = [...lines, ...windings], losses = finite(lossRows.map(row => row.pl_mw));
  return {
    lineLoading: lineLoads.length ? Math.max(...lineLoads) : null,
    windingLoading: windingLoads.length ? Math.max(...windingLoads) : null,
    branchLossesKw: losses.length === lossRows.length && losses.length ? losses.reduce((a, b) => a + b, 0) * 1000 : null,
    missingLineRatings: lines.length - lineLoads.length,
    busRows: result.tables?.res_bus?.length || 0,
  };
}

export function createPowerFlow({ onChange }) {
  let worker, request = 0;
  let state = { status: 'idle', circuit: null, message: '', result: null };
  function update(next) { state = { ...state, ...next }; onChange(state); }
  function run(circuit, parameters = DEFAULT_PARAMETERS) {
    if (state.status === 'running') return;
    const id = ++request;
    update({ status: 'running', circuit: { ...circuit }, parameters: { ...parameters }, message: 'Starting the browser solver…', result: null, error: null });
    try {
      worker ??= new Worker(`${import.meta.env.BASE_URL}powerflow/powerflow_worker.mjs`, { type: 'module' });
      const activeWorker = worker;
      worker.onmessage = ({ data }) => {
        if (activeWorker !== worker || data.id !== request) return;
        if (data.type === 'status') { update({ message: data.message }); return; }
        if (data.type === 'error') { update({ status: 'error', error: data.message, message: 'Power flow could not complete.', result: null }); return; }
        if (data.type !== 'result' || data.circuit !== state.circuit.id || data.result?.solved !== true) { update({ status: 'error', message: 'The solver returned an unexpected result.', result: null }); return; }
        update({ status: 'success', message: 'Power flow converged.', result: data.result, modelSha256: data.modelSha256, completedAt: new Date().toISOString() });
      };
      worker.onerror = event => {
        if (activeWorker !== worker) return;
        worker.terminate(); worker = undefined;
        update({ status: 'error', message: 'The browser solver could not start. Check your connection and retry.', error: event.message, result: null });
      };
      worker.postMessage({ id, circuit: String(circuit.id), parameters: { ...parameters } });
    } catch (error) { update({ status: 'error', message: 'The browser solver could not start.', error: error.message, result: null }); }
  }
  function cancel() {
    worker?.terminate(); worker = undefined; request++;
    update({ status: 'cancelled', message: 'Run cancelled. You can start another run.', result: null });
  }
  function download() {
    if (state.status !== 'success') return;
    const output = { ...state.result, circuit: state.circuit.id, substation: state.circuit.substation, completedAt: state.completedAt, modelSha256: state.modelSha256 };
    const url = URL.createObjectURL(new Blob([JSON.stringify(output, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a'); a.href = url; a.download = `SMARTDS_${state.circuit.id}_powerflow.json`; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  return { run, cancel, download, getState: () => state };
}
