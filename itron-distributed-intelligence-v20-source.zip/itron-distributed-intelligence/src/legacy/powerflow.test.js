import { test } from 'node:test';
import assert from 'node:assert/strict';
import { resultSummary } from './powerflow.js';

test('missing ratings remain unavailable and winding losses count every side exactly once', () => {
  const summary = resultSummary({ tables: {
    res_bus: [{ index: 1, phase: 1 }, { index: 1, phase: 2 }],
    res_line: [{ index: 1, loading_percent: null, pl_mw: 0.01 }],
    res_trafo: [{ index: 5, bus: 1, loading_percent: 120, pl_mw: 0.02 }, { index: 5, bus: 2, loading_percent: 90, pl_mw: 0.03 }],
  } });
  assert.equal(summary.lineLoading, null);
  assert.equal(summary.missingLineRatings, 1);
  assert.equal(summary.windingLoading, 120);
  assert.equal(summary.branchLossesKw, 60);
  assert.equal(summary.busRows, 2);
});
