import {googleNetworkData,googleNetworkCamera} from './google-map-data.js';
import {googleNetworkGeometry,nearbyNetworkGeometry,conductorPaths} from './google-network-geometry.js';

let mapsPromise;
const AUTH_ERROR='Google Maps could not authorize this key. Enable Maps JavaScript API and allow this site in the key’s website restrictions. Network 3D is still available.';
function loadGoogleMaps(){
  return mapsPromise??=(async()=>{
    const response=await fetch(`${import.meta.env.BASE_URL}transformer-analyzer/api/maps-config`);
    const config=await response.json();
    if(!response.ok||!config.apiKey)throw Error(config.error||'The Google Maps key is unavailable.');
    await new Promise((resolve,reject)=>{
      let settled=false;
      const finish=error=>{if(settled)return;settled=true;clearTimeout(timer);error?reject(error):resolve()};
      const timer=setTimeout(()=>finish(Error('Google Maps did not respond. Check your connection or choose Network 3D.')),25000);
      window.gm_authFailure=()=>{window.dispatchEvent(new Event('itron-maps-auth-error'));finish(Error(AUTH_ERROR))};
      if(window.google?.maps?.importLibrary){finish();return}
      window.__itronGoogleMapsReady=()=>{delete window.__itronGoogleMapsReady;finish()};
      const script=document.createElement('script');
      const url=new URL('https://maps.googleapis.com/maps/api/js');
      url.search=new URLSearchParams({key:config.apiKey,v:'weekly',loading:'async',callback:'__itronGoogleMapsReady',libraries:'maps3d,marker'});
      script.src=url.href;script.async=true;
      script.onerror=()=>{script.remove();finish(Error('Google Maps could not download. Check your connection or choose Network 3D.'))};
      document.head.append(script);
    });
    const [maps3d,marker]=await Promise.all([google.maps.importLibrary('maps3d'),google.maps.importLibrary('marker')]);
    return {...maps3d,...marker};
  })().catch(error=>{mapsPromise=null;throw error});
}

// Return immediately so rapid feeder changes and table selections can update
// pending state while the SDK is loading. A disposed instance never mounts.
export function createGoogleMapScene({container,study,topology,selectedId,onTransformerSelect,onAssetHover}){
  const data=googleNetworkData(study,topology),transformers=new Map(data.transformers.map(t=>[t.asset.id,t]));
  const geometry=googleNetworkGeometry(data),detailElements=new Map(),overheadRoutes=[];
  const markers=new Map(),meterMarkers=[];
  let map,api,ready=false,disposed=false,flat=false,reducedMotion=false,selected=selectedId,showMeters=true,showEquipment=true,detailTimer;
  let camera=transformers.has(selected)?assetCamera(selected):googleNetworkCamera(data);
  const status=document.createElement('div');status.className='ta-google-status';status.setAttribute('role','status');
  status.textContent='Loading Google 3D imagery…';container.replaceChildren(status);
  const detailStatus=document.createElement('div');detailStatus.className='ta-google-detail';detailStatus.textContent='3D equipment';container.append(detailStatus);
  const fail=message=>{if(disposed)return;status.hidden=false;status.classList.add('error');status.textContent=message};
  const authFailure=()=>fail(AUTH_ERROR);window.addEventListener('itron-maps-auth-error',authFailure);
  function assetCamera(id){return {center:{...transformers.get(id).position,altitude:6},range:260,tilt:65,heading:20}}
  function move(next,animate=true){
    if(!next)return;camera={...next,tilt:flat?0:next.tilt};
    if(map&&ready){map.stopCameraAnimation();map.flyCameraTo({endCamera:{...camera,altitudeMode:'RELATIVE_TO_GROUND'},durationMillis:animate&&!reducedMotion?650:0})}
  }
  function pin(asset,active=false,meter=false){
    const color=meter?asset.groupColor:asset.color;
    return new api.PinElement({background:color||'#719fc9',borderColor:active?'#ffc547':'#284556',glyphColor:meter?color:'#ffffff',scale:meter ? .35 : active ? 1 : .65});
  }
  function styleSelection(id,active){
    const entry=markers.get(id);if(!entry)return;
    entry.marker.replaceChildren(pin(entry.asset,active));
    entry.marker.label=active?entry.asset.label:undefined;entry.marker.zIndex=active?100:1;
  }
  function updateDetails(){
    if(!map||!ready||disposed)return;
    const nearby=nearbyNetworkGeometry(geometry,map.center,map.range,showEquipment&&!flat),wanted=new Map();
    const detailedRoutes=new Set(nearby.spans.map(span=>span.asset.id));
    for(const route of overheadRoutes){
      const groundTrace=detailedRoutes.has(route.asset.id);
      if(groundTrace===route.groundTrace)continue;
      route.groundTrace=groundTrace;route.line.path=groundTrace?route.path.map(p=>({...p,altitude:.15})):route.path;
      route.line.strokeColor=groundTrace?'rgba(67,182,209,0.3)':route.color;
      route.line.strokeWidth=groundTrace?1:1.5;
    }
    for(const pole of nearby.poles)wanted.set(`pole:${pole.id}`,()=>{
      const model=new api.Model3DElement({src:`${import.meta.env.BASE_URL}models/pole-${pole.phases}.glb`,position:pole.position,altitudeMode:'RELATIVE_TO_GROUND',orientation:{heading:pole.heading,tilt:0,roll:0},scale:1});
      model.dataset.networkElement='pole';model.setAttribute('aria-label','Illustrative utility pole with crossarm and insulators');return [model];
    });
    for(const span of nearby.spans)wanted.set(`span:${span.id}`,()=>conductorPaths(span).map(path=>{
      const line=new api.Polyline3DElement({path,strokeColor:span.asset.inService===false?'#85919c':'#82dcf0',strokeWidth:2,altitudeMode:'RELATIVE_TO_GROUND',drawsOccludedSegments:true});
      line.dataset.networkElement='conductor';return line;
    }));
    for(const {asset,position} of nearby.transformers)wanted.set(`transformer:${asset.id}`,()=>{
      const model=new api.Model3DInteractiveElement({src:`${import.meta.env.BASE_URL}models/transformer-symbol.glb`,position:{...position,altitude:3},altitudeMode:'RELATIVE_TO_GROUND',orientation:{heading:20,tilt:0,roll:0},scale:1});
      model.dataset.networkElement='transformer';model.setAttribute('aria-label',`${asset.label} · transformer symbol; mounting unknown`);
      model.addEventListener('gmp-click',()=>{onTransformerSelect(asset);onAssetHover?.({asset:{...asset,kind:'transformer'}})});return [model];
    });
    for(const [id,elements] of detailElements)if(!wanted.has(id)){elements.forEach(e=>e.remove());detailElements.delete(id)}
    for(const [id,create] of wanted)if(!detailElements.has(id)){const elements=create();map.append(...elements);detailElements.set(id,elements)}
    detailStatus.textContent=!showEquipment?'3D equipment hidden':flat?'Plan view · 3D equipment hidden':map.range>2400?'Zoom in for 3D equipment':`${nearby.poles.length} illustrative poles · ${nearby.transformers.length} transformer symbols`;
  }
  function scheduleDetails(){clearTimeout(detailTimer);detailTimer=setTimeout(updateDetails,160)}
  loadGoogleMaps().then(library=>{
    if(disposed)return;api=library;
    if(!camera)throw Error('This network has no geographic coordinates. Choose Network 3D.');
    map=new api.Map3DElement({...camera,range:Math.max(camera.range,1600),mode:'HYBRID',defaultUIHidden:true,gestureHandling:'GREEDY',description:'Google 3D imagery with SMARTDS transformers and connected modeled meters'});
    map.setAttribute('aria-label','Transformer network on Google 3D Maps');map.tabIndex=0;
    map.addEventListener('gmp-error',()=>fail('Google 3D could not initialize. Check Maps JavaScript API access and browser graphics support, or choose Network 3D.'));
    map.addEventListener('gmp-steadychange',event=>{
      if(!event.isSteady||disposed)return;
      // Terrain-relative camera moves are ignored before the first ready frame.
      if(!ready){ready=true;move(camera,false);scheduleDetails()}
      if(!status.classList.contains('error'))status.hidden=true;
    });
    map.addEventListener('gmp-centerchange',scheduleDetails);map.addEventListener('gmp-rangechange',scheduleDetails);
    container.prepend(map);
    for(const {asset,kind,paths} of geometry.routes){
      const color=asset.inService===false?'#85919c':kind==='switch'?'#ffd36c':kind==='underground'?'#c994ff':kind==='overhead'?'#43b6d1':'#d4dce3';
      for(const path of paths){
        const line=new api.Polyline3DElement({path,strokeColor:color,strokeWidth:kind==='overhead'?1.5:3,altitudeMode:'RELATIVE_TO_GROUND',drawsOccludedSegments:true});
        line.dataset.networkElement=kind;line.setAttribute('aria-label',`${asset.label||asset.id} · ${kind}${kind==='switch'?asset.closed?' closed':' open':''}`);map.append(line);
        if(kind==='overhead')overheadRoutes.push({line,asset,path,color,groundTrace:false});
      }
    }
    for(const {asset,position} of data.servicePoints){
      const marker=new api.Marker3DInteractiveElement({position,altitudeMode:'CLAMP_TO_GROUND',drawsWhenOccluded:true,title:`${asset.label||asset.id} · ${asset.transformerLabel||'Modeled meter'}`});
      marker.append(pin(asset,false,true));
      marker.addEventListener('gmp-click',()=>{const parent=transformers.get(asset.transformerId);if(parent)onTransformerSelect(parent.asset);onAssetHover?.({asset:{...asset,kind:'service-point'}})});
      meterMarkers.push(marker);if(showMeters)map.append(marker);
    }
    for(const {asset,position} of data.transformers){
      const marker=new api.Marker3DInteractiveElement({position:{...position,altitude:10},altitudeMode:'RELATIVE_TO_GROUND',drawsWhenOccluded:true,title:`${asset.label} · ${asset.maxWindingLoadingPct.toFixed(1)}% loading`});
      marker.addEventListener('gmp-click',()=>{onTransformerSelect(asset);onAssetHover?.({asset:{...asset,kind:'transformer'}})});
      markers.set(asset.id,{marker,asset});styleSelection(asset.id,asset.id===selected);map.append(marker);
    }
    move(camera,false);
    scheduleDetails();
  }).catch(error=>{
    console.error('Google 3D renderer:',String(error.message).replace(/AIza[\w-]+/g,'[redacted]'));
    fail(error.message?.startsWith('Google')||error.message?.includes('coordinates')||error.message?.includes('configured')?error.message:'Google 3D could not load. Choose Network 3D or reload to retry.');
  });
  return {
    selectCircuit(){},
    selectTransformer(id){if(id===selected)return;styleSelection(selected,false);selected=id;styleSelection(id,true)},
    focusTransformer(id){if(transformers.has(id))move(assetCamera(id))},
    focusCircuit(){move(googleNetworkCamera(data,container.clientWidth/Math.max(1,container.clientHeight)))},
    setView(view){flat=view==='2d';if(map){map.stopCameraAnimation();map.tilt=flat?0:65;scheduleDetails()}else if(camera)camera.tilt=flat?0:65},
    setLayer(name,visible){if(name==='equipment'){showEquipment=visible;updateDetails();return}if(name!=='servicePoints')return;showMeters=visible;for(const marker of meterMarkers)visible?map?.append(marker):marker.remove()},
    zoomBy(factor){if(map){map.stopCameraAnimation();map.range=Math.max(30,Math.min(150000,map.range*factor))}},
    setTheme(){}, // Photographic imagery keeps its natural colors in both UI themes.
    setReducedMotion(value){reducedMotion=value},
    dispose(){disposed=true;clearTimeout(detailTimer);window.removeEventListener('itron-maps-auth-error',authFailure);map?.stopCameraAnimation();map?.remove();status.remove();detailStatus.remove();detailElements.clear();markers.clear();meterMarkers.length=0},
  };
}
