import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {installStudy,events,totals,circuits,study,topology,outageEpisodes,replayStats,histogram,csvRows} from './data.js';
installStudy(JSON.parse(readFileSync(new URL('../../public/data/smartds.json',import.meta.url),'utf8')));
test('SMARTDS assets replace the original network and virtual events are labeled',()=>{
 assert.equal(totals.servicePoints,6091);assert.equal(circuits.length,11);assert.equal(topology.lines.length,6452);assert.equal(topology.transformers.filter(t=>!t.isRegulator).length,1717);assert.equal(outageEpisodes.length,events.length);assert.ok(events.length>50);assert.ok(events.every(e=>e.source==='Virtual DI agent simulation'));assert.ok(circuits.every(c=>c.id.startsWith('p3r')));assert.equal(circuits.reduce((s,c)=>s+c.events,0),events.length);
});
test('all virtual pairs have valid UTC intervals and exact modeled asset anchors',()=>{
 const ids=new Set(circuits.map(c=>c.id));for(const e of events){assert.ok(ids.has(e.circuit));assert.ok(e.startedAt>=study.start&&e.restoredAt<=study.end&&e.startedAt<e.restoredAt);assert.ok(Number.isFinite(e.x)&&Number.isFinite(e.z));assert.ok(e.start>=0&&e.end<=1&&e.start<e.end)}assert.equal(topology.outageCells.reduce((s,c)=>s+c.eventCount,0),events.length);
});
test('replay histogram and CSV preserve paired virtual events exactly once',()=>{
 assert.equal(replayStats(0).restored,0);assert.equal(replayStats(1).restored,events.length);assert.equal(replayStats(1).active,0);assert.equal(histogram().reduce((a,b)=>a+b),events.length);const c=circuits[0];assert.equal(histogram(80,c.id).reduce((a,b)=>a+b),c.events);assert.equal(csvRows(c.id).split('\n').length,c.events+1);assert.equal(csvRows().split('\n').length,events.length+1);
});
