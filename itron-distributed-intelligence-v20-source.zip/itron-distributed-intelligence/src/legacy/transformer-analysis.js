// IEEE C57.91 Clause 7 thermal equations, first ported from the supplied dist_dtr_app.py.
// Overhead (C57.12.20) and padmount oil-immersed units share one 65 °C-rise basis
// (80 °C hottest-spot rise, 110 °C reference at 30 °C ambient) and one C57.91 method; only
// their parameters can differ. The defaults are assumptions, not transformer test results.
export const DEFAULTS = Object.freeze({ambient:30,swing:10,oilRise:55,hotRise:80,lossRatio:5,oilTau:180,windingTau:4,n:.8,m:.8,oilLimit:105,hotLimit:120,charger:7.2,energy:10,arrival:18,arrivalSpread:1.5,delayHour:23,evPf:1,seed:1,scanLimit:100,profile:'constant'});
// C57.91 normal insulation life benchmark used for percent loss of life.
export const NORMAL_LIFE_HOURS=180000;
// C57.91 top-oil time constant at any load, from the rated constant and the initial and ultimate rises.
export function oilTimeConstant(initial,ultimate,a=DEFAULTS){
 const ri=initial/a.oilRise,ru=ultimate/a.oilRise,p=1/a.n;
 if(Math.abs(ru-ri)<1e-6)return a.oilTau*a.n*((ru+ri)/2)**(1-p);
 return a.oilTau*(ru-ri)/(ru**p-ri**p);
}
export function steady(k,a=DEFAULTS,ambient=a.ambient){
 const oilRise=a.oilRise*((k*k*a.lossRatio+1)/(a.lossRatio+1))**a.n;
 const gradient=(a.hotRise-a.oilRise)*k**(2*a.m);
 return {oil:ambient+oilRise,hot:ambient+oilRise+gradient};
}
export function thermal(load,ambient,a=DEFAULTS,dt=15){
 let previous=steady(load[0],a,0),oilRise=previous.oil,gradient=previous.hot-previous.oil;
 const oil=[],hot=[],aging=[];
 for(let i=0;i<load.length;i++){
  const u=steady(load[i],a,0);
  oilRise=u.oil+(oilRise-u.oil)*Math.exp(-dt/oilTimeConstant(oilRise,u.oil,a));
  gradient=(u.hot-u.oil)+(gradient-(u.hot-u.oil))*Math.exp(-dt/a.windingTau);
  oil.push(ambient[i]+oilRise);hot.push(oil[i]+gradient);aging.push(Math.exp(15000/383-15000/(hot[i]+273)));
 }
 return {oil,hot,aging};
}
export const DAILY_SHAPE=[.45,.40,.37,.35,.35,.38,.48,.58,.60,.57,.55,.55,.57,.60,.65,.72,.82,.92,1,.98,.93,.83,.68,.55];
export function validate(a,t,count=3){
 const bounds={ambient:[-20,60],swing:[0,40],oilRise:[1,100],hotRise:[2,160],lossRatio:[.1,50],oilTau:[1,1440],windingTau:[.1,180],n:[.1,2],m:[.1,2],oilLimit:[40,160],hotLimit:[50,200],charger:[.5,50],energy:[.5,100],arrival:[0,23.99],arrivalSpread:[0,6],delayHour:[0,23.99],evPf:[.8,1],scanLimit:[1,200],seed:[1,99999]};
 for(const [key,[lo,hi]] of Object.entries(bounds))if(!Number.isFinite(a[key])||a[key]<lo||a[key]>hi)throw Error(`${key} must be between ${lo} and ${hi}.`);
 if(a.hotRise<=a.oilRise)throw Error('Rated hot-spot rise must exceed rated top-oil rise.');
 if(!['constant','residential'].includes(a.profile))throw Error('Choose a base-load profile.');
 if(!Number.isInteger(count)||count<0||count>200||!Number.isInteger(a.scanLimit))throw Error('EV counts and scan limit must be whole numbers from 0 to 200.');
 if(!t.inService||!Number.isFinite(t.ratedKva)||t.ratedKva<=0||!t.windings?.length)throw Error('An energized transformer with rated winding results is required.');
 for(const w of t.windings)if(![w.pKw,w.qKvar,w.ratedKva].every(Number.isFinite)||w.ratedKva<=0||!['primary','secondary'].includes(w.side))throw Error('Winding power or rating is unavailable.');
}
function random(seed){let s=seed>>>0;return()=>{s+=0x6D2B79F5;let t=s;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296}}
function normal(r){return Math.sqrt(-2*Math.log(Math.max(Number.EPSILON,r())))*Math.cos(2*Math.PI*r())}
export function addSession(profile,startHours,energy,charger,dt=.25){const start=startHours/dt,end=start+energy/charger/dt;for(let k=Math.max(0,Math.floor(start));k<Math.min(profile.length,Math.ceil(end));k++)profile[k]+=charger*Math.max(0,Math.min(end,k+1)-Math.max(start,k));}
export function evProfile(ev,a,delayed,days=8){const p=new Float64Array(days*96),r=random((a.seed*65537+ev*7919)>>>0);let previousEnd=-Infinity;for(let d=0;d<days;d++){const arrival=a.arrival+a.arrivalSpread*normal(r),energy=Math.max(.5,a.energy*(1+.25*normal(r))),offset=2*r();const delay=a.delayHour+(a.delayHour<12?24:0)+offset,start=d*24+(delayed?Math.max(arrival,delay):arrival);if(start<previousEnd-1e-9)throw Error('Sampled sessions overlap for one EV. Reduce daily energy or arrival spread, or increase charger power.');previousEnd=start+energy/a.charger;addSession(p,start,energy,a.charger)}return p}
export function windingLoad(t,baseFactor,evKw,evPf=1){const totals={primary:0,secondary:0};for(const w of t.windings)totals[w.side]+=w.ratedKva;let maximum=0;for(const w of t.windings){const sign=w.side==='primary'?1:-1,extra=evKw*w.ratedKva/totals[w.side];maximum=Math.max(maximum,Math.hypot(sign*w.pKw*baseFactor+extra,sign*w.qKvar*baseFactor+extra*Math.tan(Math.acos(evPf)))/w.ratedKva)}return maximum}
export function thermalSummary(series,a,dt=15){const maxOil=Math.max(...series.oil),maxHot=Math.max(...series.hot),feqa=series.aging.reduce((s,v)=>s+v,0)/series.aging.length,lossOfLifeHours=feqa*series.aging.length*dt/60;return {maxOil,maxHot,feqa,lossOfLifeHours,lossOfLifePct:lossOfLifeHours/NORMAL_LIFE_HOURS*100,pass:feqa<=1+1e-12&&maxOil<=a.oilLimit+1e-12&&maxHot<=a.hotLimit+1e-12,reasons:[...(feqa>1+1e-12?['Aging']:[]),...(maxOil>a.oilLimit+1e-12?['Top oil']:[]),...(maxHot>a.hotLimit+1e-12?['Hot spot']:[])]}}
export function analyzeTransformer(t,a=DEFAULTS,count=3){
 validate(a,t,count);const length=8*96,cap=Math.max(count,a.scanLimit),ambient=Array.from({length},(_,i)=>a.ambient+a.swing/2*Math.sin(2*Math.PI*(i/4-9)/24));
 const base=Array.from({length},(_,i)=>{const h=i/4%24,k=Math.floor(h);return a.profile==='constant'?1:DAILY_SHAPE[k]+(DAILY_SHAPE[(k+1)%24]-DAILY_SHAPE[k])*(h-k)});
 function scenario(evKw){const load=base.map((b,i)=>windingLoad(t,b,evKw[i],a.evPf)),s=thermal(load,ambient,a);const series={oil:s.oil.slice(96),hot:s.hot.slice(96),aging:s.aging.slice(96)};return {...thermalSummary(series,a),maxLoading:Math.max(...load.slice(96))*100,series:{...series,load:load.slice(96).map(k=>k*100),evKw:Array.from(evKw.slice(96)),ambient:ambient.slice(96)}}}
 const baseline=scenario(new Float64Array(length));
 const results={};
 for(const mode of ['uncontrolled','delayed']){
  const ev=new Float64Array(length),scan=[],selectedCount=count;let chosen,capacity=-1,contiguous=baseline.pass,firstFailure=null;
  for(let n=0;n<=cap;n++){
   if(n){const single=evProfile(n,a,mode==='delayed');for(let i=0;i<length;i++)ev[i]+=single[i]}
   const r=n===0?baseline:scenario(ev);const {series,...summary}=r;scan.push({count:n,...summary});if(n===selectedCount)chosen=r;
   if(contiguous&&r.pass)capacity=n;else if(contiguous||n===0){contiguous=false;firstFailure={count:n,...summary}}
  }
  results[mode]={capacity,censored:capacity===cap,firstFailure,selected:chosen,scan};
 }
 return {transformerId:t.id,assumptions:{...a},selectedCount:count,days:7,stepMinutes:15,warmupDays:1,scanCap:cap,baseline,...results};
}
