import test from 'node:test';
import assert from 'node:assert/strict';
import {adoptionScenario,spatialContext,stationStatus} from './ev-spatial.js';
const defaults={residentialPercent:100,vehiclesPerPremise:1,referencePercent:2.8,targetPercent:5};
test('county scenario adds the positive increment, not all assumed EVs',()=>{
  const result=adoptionScenario(100,{...defaults,residentialPercent:50,vehiclesPerPremise:2});
  assert.equal(result.assumedVehiclePool,100);assert.equal(result.referenceVehicles,2.8);assert.equal(result.targetVehicles,5);
  assert.equal(result.additionalVehicles,2.2);assert.equal(result.studyCount,3);
});
test('unknown meter linkage is not zero demand, while an explicit zero residential share is zero',()=>{
  for(const count of [0,undefined,null,NaN,-2])assert.equal(adoptionScenario(count,defaults).available,false);
  assert.equal(adoptionScenario(30,{...defaults,residentialPercent:0}).studyCount,0);
});
test('decreasing adoption cannot remove unmeasured EVs from baseline',()=>{
  assert.equal(adoptionScenario(100,{...defaults,targetPercent:1}).studyCount,0);
});
test('limits and nonfinite inputs are rejected; study count is not silently capped',()=>{
  for(const key of Object.keys(defaults))for(const value of [NaN,Infinity,-1])assert.throws(()=>adoptionScenario(20,{...defaults,[key]:value}));
  assert.throws(()=>adoptionScenario(20,{...defaults,vehiclesPerPremise:11}));
  assert.equal(adoptionScenario(200,{...defaults,referencePercent:0,targetPercent:100}).exceedsStudyLimit,false);
  const result=adoptionScenario(201,{...defaults,referencePercent:0,targetPercent:100});
  assert.equal(result.studyCount,201);assert.equal(result.exceedsStudyLimit,true);
});
test('missing spatial matches remain unavailable and station status preserves uncertainty',()=>{
  assert.equal(spatialContext({transformers:{}},{id:'unmatched'}),null);
  assert.equal(stationStatus({status:'T'}),'Temporarily unavailable in inventory');
  assert.equal(stationStatus({status:'E'}),'Available in inventory');
  assert.equal(stationStatus({}),'Status uncertain');
});
