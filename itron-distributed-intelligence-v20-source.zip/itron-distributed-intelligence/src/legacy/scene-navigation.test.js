import test from 'node:test';
import assert from 'node:assert/strict';
import {networkZoomLimits,keyboardPanDistance,outageTourZoom} from './scene-navigation.js';

test('transformer and kilometer-scale network views both reach equipment detail and regional scale',()=>{
  for(const scale of [1,2])for(const extent of [230,360,6091,9826.53,16346]){
    const limits=networkZoomLimits(extent*scale,scale);
    assert.ok(extent/limits.max<=10);
    assert.ok(limits.max>3.9*10);
    assert.ok(extent/limits.min>=extent/0.025*5);
  }
});

test('keyboard pan stays at thirty screen pixels through the entire zoom range',()=>{
  const extent=9826.53,limits=networkZoomLimits(extent);
  for(const zoom of [limits.min,1,limits.max]){
    const camera={top:extent/2,bottom:-extent/2,zoom},height=700;
    assert.ok(Math.abs(keyboardPanDistance(camera,height)/(extent/zoom/height)-30)<1e-10);
  }
});

test('outage tours frame a 700-meter neighborhood on both local and SMARTDS regional scenes',()=>{
  for(const scale of [1,2])for(const extent of [230,360,9826.53,16346]){
    const zoom=outageTourZoom(extent*scale,scale);
    assert.ok(Math.abs(extent/zoom-700)<1e-8, 'outage columns remain visible at every tour stop');
    const limits=networkZoomLimits(extent*scale,scale);
    assert.ok(zoom>=limits.min&&zoom<=limits.max);
  }
});
