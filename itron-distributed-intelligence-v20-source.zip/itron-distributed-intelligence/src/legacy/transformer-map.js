// Distinct green, blue, gray and brown families identify electrical groups,
// with subtle shade variations within each family. Loading is encoded separately
// in the hovering status dot. Explicit sRGB colors keep gray neutral and brown warm.
const groupColors=[
  ['#73b99a','#86c4a4','#69af89','#91c6ae','#7fb693','#9aceb2'],
  ['#719fc9','#85afd6','#6596bf','#93b9dd','#7ba6c1','#9cc0de'],
  ['#acacab','#bebdb9','#9e9f9e','#cdcbc7','#b1b2af','#c2c3c0'],
  ['#a98057','#b78e66','#9e7652','#c19a73','#ad8964','#c8a17d'],
];
export function transformerGroupColor(id){
  let hash=2166136261;for(const c of id)hash=Math.imul(hash^c.charCodeAt(0),16777619)>>>0;
  const family=groupColors[hash%groupColors.length];
  return family[(hash>>>8)%family.length];
}
export const transformerDotColor=t=>Number.isFinite(t.maxWindingLoadingPct)&&t.maxWindingLoadingPct>150?'#ff4545':transformerGroupColor(t.id);
export function transformerMapData(topology,transformers,links={}){
  const styled=transformers.map(t=>({...t,groupColor:transformerGroupColor(t.id),color:transformerDotColor(t)}));
  const byId=new Map(styled.map(t=>[t.id,t]));
  const servicePoints=topology.servicePoints.map(p=>{
    const id=links[p.id]||p.anchor?.transformerId,t=byId.get(id),matched=t&&t.circuit===p.circuit;
    return {...p,transformerId:matched?t.id:null,transformerLabel:matched?t.label:null,groupColor:matched?t.groupColor:'#94a5ad'};
  });
  return {...topology,transformers:styled,servicePoints,outageCells:[]};
}

// Retain the full study inventory outside the renderer; only the chosen network
// needs GPU geometry and pointer picking targets.
export function transformerNetworkData(topology, transformers, links, circuit) {
  const scoped = {...topology};
  for (const key of ['lines','switches','buses','servicePoints','transformers','generators','outageCells']) {
    scoped[key] = (topology[key] || []).filter(item => item.circuit === circuit);
  }
  return transformerMapData(scoped, transformers.filter(t => t.circuit === circuit), links);
}
