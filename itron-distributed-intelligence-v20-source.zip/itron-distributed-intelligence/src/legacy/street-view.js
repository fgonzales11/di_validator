const METERS_PER_DEGREE = 111320;
const finitePoint = p => Number.isFinite(p?.x) && Number.isFinite(p?.z);

// Undo the exporter's local equirectangular projection (z points south).
export function geographicLocation(point, origin, scale = 1) {
  if (!finitePoint(point) || !Number.isFinite(origin?.lat) || !Number.isFinite(origin?.lon) ||
      !Number.isFinite(scale) || scale <= 0 || Math.abs(origin.lat) >= 90) return null;
  const lat = origin.lat - point.z / scale / METERS_PER_DEGREE;
  const lon = origin.lon + point.x / scale / (METERS_PER_DEGREE * Math.cos(origin.lat * Math.PI / 180));
  return Math.abs(lat) <= 90 && Math.abs(lon) <= 180 ? {lat, lon} : null;
}

// Keep complete geographic pairs together; zero is a valid coordinate.
export function explicitGeographicLocation(asset) {
  for (const [lat, lon] of [[asset?.latitude, asset?.longitude], [asset?.lat, asset?.lon], [asset?.Latitude, asset?.Longitude]]) {
    if (Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180) return {lat, lon};
  }
  return null;
}

export function createAssetLocationResolver(study) {
  const buses = new Map((study?.topology?.buses || []).map(bus => [bus.id, bus]));
  return (asset, point = asset) => {
    const own = explicitGeographicLocation(asset);
    const transformer = asset?.kind === 'transformer' || Array.isArray(asset?.windingBuses);
    if (own) return {...own, source:transformer ? 'Transformer coordinates' : 'Model coordinates'};
    const circuit = asset?.circuit;
    const references = asset?.kind === 'bus' ? [asset.id] : [asset?.bus, asset?.secondaryBusIndex,
      ...(asset?.secondaryBusIndices || []), ...(asset?.primaryBusIndices || []), ...(asset?.windingBuses || [])];
    for (const reference of references) {
      let id = null;
      if (typeof reference === 'string' && reference.includes('/bus/')) {
        if (!circuit || reference.startsWith(circuit + '/bus/')) id = reference;
      } else if (circuit && ((Number.isInteger(reference) && reference >= 0) || (typeof reference === 'string' && /^\d+$/.test(reference)))) {
        id = circuit + '/bus/' + reference;
      }
      const bus = buses.get(id);
      if (!bus || (circuit && bus.circuit && bus.circuit !== circuit)) continue;
      const location = explicitGeographicLocation(bus);
      if (location) return {...location, busId:id, source:(transformer ? 'Connected bus ' : 'Bus ') + id.split('/bus/').pop() + ' coordinates'};
    }
    const projected = geographicLocation(point, study?.origin, study?.worldUnitsPerMeter || 1);
    return projected ? {...projected, source:'Projected model location'} : null;
  };
}

// Conductor geometry has decorative lateral offsets; use the source centerline.
export function selectedNetworkPoint(asset, hitPoint) {
  if (asset?.kind === 'bus') return finitePoint(asset) ? {x: asset.x, z: asset.z} : null;
  if (!['line', 'switch'].includes(asset?.kind) || !finitePoint(hitPoint)) return null;
  let closest = null, distance = Infinity;
  for (let i = 1; i < (asset.points?.length || 0); i++) {
    const [ax, az] = asset.points[i - 1], [bx, bz] = asset.points[i];
    if (![ax, az, bx, bz].every(Number.isFinite)) continue;
    const dx = bx - ax, dz = bz - az, length = dx * dx + dz * dz;
    const t = length ? Math.max(0, Math.min(1, ((hitPoint.x - ax) * dx + (hitPoint.z - az) * dz) / length)) : 0;
    const point = {x: ax + t * dx, z: az + t * dz};
    const d = (hitPoint.x - point.x) ** 2 + (hitPoint.z - point.z) ** 2;
    if (d < distance) { closest = point; distance = d; }
  }
  return closest;
}

export function streetViewURLs(location) {
  if (!Number.isFinite(location?.lat) || !Number.isFinite(location?.lon) ||
      Math.abs(location.lat) > 90 || Math.abs(location.lon) > 180) return null;
  const coordinates = location.lat.toFixed(6) + ',' + location.lon.toFixed(6);
  const request = '/outage-analyzer/api/street-view?' + new URLSearchParams({
    lat:location.lat.toFixed(6), lon:location.lon.toFixed(6)
  });
  const external = new URL('https://www.google.com/maps/@');
  external.search = new URLSearchParams({api: '1', map_action: 'pano', viewpoint: coordinates});
  return {request, external: external.href, coordinates};
}

export function createStreetView({workspace = document.getElementById('workspace'), floating = false,
  focusTarget = () => document.getElementById('scene-container')?.querySelector('canvas')} = {}) {
  const get = id => document.getElementById(id);
  const panel = get('street-view-panel');
  const holder = get('street-view-frame-container'), status = get('street-view-status');
  let selection = null, opened = false, loadedURL = '', timer, frame = null, pending = null;
  function layout() {
    if (!opened || floating) return;
    const box = workspace.getBoundingClientRect(), timeline = get('timeline-panel').getBoundingClientRect();
    const card = get('asset-card'), inspector = card.getBoundingClientRect();
    const bottom = box.bottom - timeline.top + 16;
    const belowInspector = timeline.top - inspector.bottom - 28;
    let right = 100, width = Math.min(650, box.width - 360), height = 310;
    if (box.width <= 760) { right = 12; width = box.width - 24; }
    else if (!card.hidden && belowInspector < 300) {
      right = box.right - inspector.left + 16;
      width = Math.min(650, box.width - right - 22);
    } else if (!card.hidden) height = Math.min(height, belowInspector);
    panel.style.right = right + 'px';
    panel.style.width = Math.max(220, width) + 'px';
    panel.style.height = height + 'px';
    panel.style.bottom = bottom + 'px';
    // Short landscape screens use the available workspace without clipping controls.
    if (timeline.top - box.top < height + 24) {
      panel.style.bottom = '12px';
      panel.style.height = Math.max(240, box.height - 24) + 'px';
    }
  }
  async function load() {
    if (!opened || !selection) return;
    const urls = streetViewURLs(selection.location);
    get('street-view-coordinates').textContent = selection.label + ' · ' + urls.coordinates;
    get('street-view-external').href = urls.external;
    if (loadedURL === urls.request) return;
    loadedURL = urls.request;
    pending?.abort();
    const controller = new AbortController(); pending = controller;
    holder.replaceChildren(); frame = null;
    status.hidden = false; status.textContent = 'Loading nearby street imagery…';
    clearTimeout(timer);
    let embedURL;
    try {
      const response = await fetch(urls.request, {signal:controller.signal});
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Street View could not load.');
      embedURL = new URL(result.url);
      if (embedURL.origin !== 'https://www.google.com' || embedURL.pathname !== '/maps/embed/v1/streetview') throw new Error('Street View could not load.');
    } catch (error) {
      if (pending !== controller || controller.signal.aborted) return;
      status.textContent = 'Street View is unavailable. Open this location in Google Maps below.';
      loadedURL = ''; return;
    }
    if (!opened || pending !== controller || controller.signal.aborted) return;
    const nextFrame = document.createElement('iframe');
    nextFrame.id = 'street-view-frame';
    nextFrame.title = 'Street View near ' + urls.coordinates;
    nextFrame.allowFullscreen = true;
    nextFrame.referrerPolicy = 'strict-origin-when-cross-origin';
    nextFrame.onload = () => { if (opened && frame === nextFrame) { clearTimeout(timer); status.hidden = true; } };
    nextFrame.onerror = () => { if (opened && frame === nextFrame) { clearTimeout(timer); status.hidden = false; status.textContent = 'Street imagery could not load. Open this location in Google Maps below.'; } };
    nextFrame.src = embedURL.href;
    frame = nextFrame;
    holder.replaceChildren(nextFrame);
    timer = setTimeout(() => { status.textContent = 'Imagery unavailable? Open this location in Google Maps below.'; }, 10000);
  }
  function close({restoreFocus = true} = {}) {
    const button = get('street-view-button');
    opened = false; panel.hidden = true; workspace.classList.remove('street-view-open');
    button?.setAttribute('aria-expanded', 'false'); clearTimeout(timer);
    pending?.abort(); pending = null;
    holder.replaceChildren(); frame = null; loadedURL = '';
    if (restoreFocus) {
      const target = button?.getClientRects().length && getComputedStyle(button).visibility !== 'hidden' ? button : focusTarget();
      target?.focus({preventScroll: true});
    }
  }
  function open() {
    if (!selection) return;
    opened = true; panel.hidden = false; workspace.classList.add('street-view-open');
    get('street-view-button')?.setAttribute('aria-expanded', 'true'); layout(); load(); get('close-street-view').focus({preventScroll: true});
  }
  function bindButton() {
    const button = get('street-view-button');
    if (!button) return;
    button.onclick = open;
    button.disabled = !selection;
    button.setAttribute('aria-expanded', String(opened));
  }
  bindButton();
  get('close-street-view').onclick = () => close();
  const observer = new ResizeObserver(layout);
  for (const el of [workspace, get('asset-card'), get('timeline-panel')].filter(Boolean)) observer.observe(el);
  return {
    isOpen: () => opened, close,
    select(point, {origin, scale = 1, label = 'Selected location'} = {}) {
      const location = explicitGeographicLocation(point) || geographicLocation(point, origin, scale);
      selection = location ? {location, label} : null;
      const basis = get('street-view-basis');
      if (basis) basis.textContent = (point?.source || 'Model location') + ' · nearby imagery';
      // Transformer details replace their header on each selection.
      bindButton();
      const text = get('selected-location');
      if (text) {
        text.hidden = !selection;
        text.textContent = selection ? label + ' · ' + streetViewURLs(location).coordinates : '';
      }
      if (!selection) close({restoreFocus: false});
      else if (opened) { layout(); load(); }
    },
    reset() { selection = null; bindButton(); if (get('selected-location')) get('selected-location').hidden = true; close({restoreFocus: false}); }
  };
}
