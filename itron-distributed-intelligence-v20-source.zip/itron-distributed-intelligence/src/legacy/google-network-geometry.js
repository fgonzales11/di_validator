// Model coordinates are real; dimensions and intermediate pole positions are
// illustrative. No measured pole, clearance, sag or mounting data is supplied.
export const NETWORK_GEOMETRY = Object.freeze({height:10.5,span:55,maxSag:1.8,detailRange:2400,maxSpans:100,maxPoles:160,maxTransformers:32});
const metersPerDegree=111320;
export function groundDistance(a,b){return Math.hypot((a.lat-b.lat)*metersPerDegree,(a.lng-b.lng)*metersPerDegree*Math.cos((a.lat+b.lat)*Math.PI/360))}
const mix=(a,b,t)=>({lat:a.lat+(b.lat-a.lat)*t,lng:a.lng+(b.lng-a.lng)*t,altitude:0});
export function phaseOffsets(phases){
  const count=new Set(String(phases||'').split(/[,/\s·-]+/).filter(p=>/^[ABC123]$/i.test(p))).size;
  return count>=3?[-1.5,0,1.5]:count===2?[-1.5,1.5]:[0];
}
export function lineKind(asset){return typeof asset.closed==='boolean'?'switch':asset.overhead===true?'overhead':asset.overhead===false?'underground':'unspecified'}

export function googleNetworkGeometry(data){
  const poles=new Map(),spans=[],routes=[];
  const poleAt=(position,asset,heading,phases)=>{
    const id=`${asset.circuit}:${position.lat.toFixed(6)},${position.lng.toFixed(6)}`;
    const existing=poles.get(id);
    if(!existing||existing.phases<phases)poles.set(id,{id,position,heading,phases,asset});
    return id;
  };
  for(const {asset,path} of data.lines){
    const kind=lineKind(asset),height=kind==='overhead'?NETWORK_GEOMETRY.height:.25;
    // Open switches must not appear electrically connected.
    const routePaths=kind==='switch'&&asset.closed===false?path.slice(1).flatMap((b,i)=>[[path[i],mix(path[i],b,.35)],[mix(path[i],b,.65),b]]):[path];
    routes.push({asset,kind,paths:routePaths.map(points=>points.map(p=>({...p,altitude:height})))});
    if(kind!=='overhead')continue;
    const offsets=phaseOffsets(asset.phases);
    for(let i=1;i<path.length;i++){
      const a=path[i-1],b=path[i],length=groundDistance(a,b);
      if(length<.1)continue;
      const n=Math.max(1,Math.ceil(length/NETWORK_GEOMETRY.span));
      const north=(b.lat-a.lat)*metersPerDegree,east=(b.lng-a.lng)*metersPerDegree*Math.cos((a.lat+b.lat)*Math.PI/360);
      const heading=(Math.atan2(east,north)*180/Math.PI+360)%360;
      for(let j=0;j<n;j++){
        const start=mix(a,b,j/n),end=mix(a,b,(j+1)/n);
        const startPole=poleAt(start,asset,heading,offsets.length),endPole=poleAt(end,asset,heading,offsets.length);
        spans.push({id:`${asset.id}:${i}:${j}`,asset,start,end,position:mix(start,end,.5),length:length/n,heading,offsets,poles:[startPole,endPole]});
      }
    }
  }
  for(const span of spans)span.supports=span.poles.map(id=>poles.get(id));
  return {routes,spans,poles,transformers:data.transformers};
}

export function conductorPaths(span){
  const sag=Math.min(NETWORK_GEOMETRY.maxSag,span.length*.06);
  const attachment=(support,offset)=>{const p=support.position,radians=support.heading*Math.PI/180;return {lat:p.lat-Math.sin(radians)*offset/metersPerDegree,lng:p.lng+Math.cos(radians)*offset/(metersPerDegree*Math.cos(p.lat*Math.PI/180))}};
  return span.offsets.map(offset=>{
    const [start,end]=span.supports.map(support=>attachment(support,offset));
    return Array.from({length:9},(_,i)=>{const t=i/8;return {...mix(start,end,t),altitude:NETWORK_GEOMETRY.height-4*sag*t*(1-t)}});
  });
}

// Bound heavy GLB and fine-conductor elements around the camera target, while
// retaining every source line at regional zoom. Only add/remove changed items.
export function nearbyNetworkGeometry(geometry,center,range,enabled=true){
  const empty={spans:[],poles:[],transformers:[]};
  if(!enabled||!center||!Number.isFinite(range)||range>NETWORK_GEOMETRY.detailRange)return empty;
  const radius=Math.min(1500,Math.max(160,range*.8));
  const nearest=(items,limit)=>items.map(item=>({item,d:groundDistance(item.position,center)})).filter(x=>x.d<=radius).sort((a,b)=>a.d-b.d).slice(0,limit).map(x=>x.item);
  const spans=[],poleIds=new Set();
  for(const span of nearest(geometry.spans,NETWORK_GEOMETRY.maxSpans)){
    const additions=span.poles.filter(id=>!poleIds.has(id));
    if(poleIds.size+additions.length>NETWORK_GEOMETRY.maxPoles)continue;
    spans.push(span);for(const id of additions)poleIds.add(id);
  }
  const poles=[...poleIds].map(id=>geometry.poles.get(id));
  return {spans,poles,transformers:nearest(geometry.transformers,NETWORK_GEOMETRY.maxTransformers)};
}
