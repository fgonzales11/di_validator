import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';
import {transformerGroupColor,transformerDotColor,transformerMapData,transformerNetworkData} from './transformer-map.js';
const read=name=>JSON.parse(readFileSync(new URL('../../public/data/'+name,import.meta.url)));
test('red hovering dots require finite loading strictly above150 percent',()=>{for(const v of [null,undefined,NaN,100,150])assert.notEqual(transformerDotColor({id:'tx1',maxWindingLoadingPct:v}),'#ff4545');assert.equal(transformerDotColor({id:'tx1',maxWindingLoadingPct:150.01}),'#ff4545');});
test('meter colors follow verified identities without moving locations or changing outage topology',()=>{
 const topology=read('smartds.json').topology,baseline=read('transformer-baseline.json').transformers.filter(t=>!t.isRegulator),links=read('transformer-meter-groups.json').links;
 const result=transformerMapData(topology,baseline,links),byId=new Map(result.transformers.map(t=>[t.id,t])),counts=new Map();
 assert.equal(Object.keys(links).length,6091);assert.equal(result.lines,topology.lines);assert.equal(result.servicePoints.length,6091);
 for(let i=0;i<result.servicePoints.length;i++){
  const p=result.servicePoints[i],old=topology.servicePoints[i];assert.equal(p.x,old.x);assert.equal(p.z,old.z);assert.deepEqual(p.anchor,old.anchor);assert.equal(old.groupColor,undefined);
  if(p.transformerId){const t=byId.get(p.transformerId);assert.equal(t.circuit,p.circuit);assert.equal(p.groupColor,t.groupColor);counts.set(t.id,(counts.get(t.id)||0)+1);}
 }
 for(const t of baseline)assert.equal(counts.get(t.id)||0,Object.values(links).filter(id=>id===t.id).length);
 assert.equal(byId.size,1717);assert.equal(topology.transformers.length,1720);assert.equal(transformerGroupColor('tx1'),transformerGroupColor('tx1'));assert.notEqual(transformerGroupColor('tx1'),transformerGroupColor('tx2'));
});

test('switching networks retains all local equipment and meter links without mutating the full study',()=>{
 const study=read('smartds.json'),baseline=read('transformer-baseline.json'),links=read('transformer-meter-groups.json').links;
 const topology=study.topology,transformers=baseline.transformers.filter(t=>!t.isRegulator);
 const original=JSON.stringify(topology);
 let meters=0,markers=0,lines=0;
 for(const circuit of baseline.circuits){
  const scope=transformerNetworkData(topology,transformers,links,circuit.id);
  for(const key of ['lines','switches','buses','servicePoints','transformers','generators'])assert.ok(scope[key].every(item=>item.circuit===circuit.id),key);
  assert.deepEqual(scope.lines,topology.lines.filter(item=>item.circuit===circuit.id));
  const ids=new Set(scope.transformers.map(t=>t.id));
  assert.ok(scope.servicePoints.every(p=>ids.has(p.transformerId)),'every meter still belongs to its transformer');
  meters+=scope.servicePoints.length;markers+=scope.transformers.length;lines+=scope.lines.length;
 }
 assert.equal(meters,topology.servicePoints.length);assert.equal(markers,transformers.length);assert.equal(lines,topology.lines.length);
 assert.equal(JSON.stringify(topology),original);
});
