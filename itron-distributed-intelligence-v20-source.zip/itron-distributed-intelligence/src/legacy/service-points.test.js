import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { servicePointLocations, servicePointSummary, mergeStudyInventory } from './service-points.js';

const data = JSON.parse(readFileSync(new URL('../../public/data/smartds.json', import.meta.url)));
test('every meter inventory row is retained once and location evidence stays separate from schematic anchors', () => {
  const points = data.topology.servicePoints;
  assert.equal(new Set(points.map(p => p.id)).size, 6091);
  const inventoryById = new Map(points.map(p => [p.id, p]));
  for (const event of data.events) assert.equal(inventoryById.get(event.assetId)?.circuit, event.circuit);
  assert.deepEqual(servicePointSummary(points), { total: 6091, recorded: 0, model: 6091, schematic: 0, unlocated: 0, outsideStudy: 0, shown: 6091 });
  const known = new Set(data.circuits.map(c => c.id));
  for (const p of points) {
    if (p.locationBasis === 'outside-study') assert.equal(p.circuit, null);
    else assert.ok(known.has(p.circuit));
    if (['recorded','model'].includes(p.locationBasis)) assert.ok(Number.isFinite(p.x) && Number.isFinite(p.z));
    else assert.equal(p.x, undefined);
    if (p.locationBasis === 'schematic') assert.ok(p.anchor.transformerId && p.anchor.bus && Number.isFinite(p.anchor.x) && Number.isFinite(p.anchor.z));
  }
});

test('schematic layout is stable and one-per-meter, recorded coordinates never move, missing positions stay missing', () => {
  const points = [
    { id: 'M2', circuit: 'a', locationBasis: 'schematic', anchor: { transformerId: 't1', x: 100, z: 200 } },
    { id: 'M1', circuit: 'a', locationBasis: 'schematic', anchor: { transformerId: 't1', x: 100, z: 200 } },
    { id: 'M3', circuit: 'a', locationBasis: 'recorded', x: 101, z: 203 },
    { id: 'M4', circuit: 'a', locationBasis: 'unlocated' },
  ];
  const layout = servicePointLocations(points);
  assert.deepEqual(layout, servicePointLocations([...points].reverse()));
  assert.equal(layout.recorded[0], points[2]);
  assert.equal(layout.schematic.length, 2);
  assert.notDeepEqual([layout.schematic[0].x, layout.schematic[0].z], [layout.schematic[1].x, layout.schematic[1].z]);
  assert.equal(points[0].x, undefined);
  const real = servicePointLocations(data.topology.servicePoints);
  assert.equal(real.recorded.length + real.schematic.length, 6091);
  assert.equal(new Set([...real.recorded, ...real.schematic].map(p => p.id)).size, 6091);
});

test('historical outage activation retains the entire current meter inventory and physical network', () => {
  const historical = { study: { name: 'older' }, events: [{ id: 'E1' }], topology: { servicePoints: [{ x: 0, z: 0 }], outageCells: [{ hours: 3 }] } };
  const merged = mergeStudyInventory(data, historical);
  assert.equal(merged.topology.servicePoints, data.topology.servicePoints);
  assert.equal(merged.topology.lines, data.topology.lines);
  assert.equal(merged.topology.transformers, data.topology.transformers);
  assert.equal(merged.topology.outageCells, historical.topology.outageCells);
  assert.equal(merged.events, historical.events);
});
