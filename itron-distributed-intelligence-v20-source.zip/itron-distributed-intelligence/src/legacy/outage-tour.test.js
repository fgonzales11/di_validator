import { attachVirtualScenario } from '../virtual-di-agent.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { selectOutageTour, createOutageTourClock, advanceOutageTour, OUTAGE_FLIGHT_MS, REPLAY_SPEEDS } from './outage-tour.js';

function replay(stops, { startProgress = 0, speed = () => 1, frameMs = 75 } = {}) {
  const clock = createOutageTourClock(stops, startProgress);
  const visits = [];
  let progress = startProgress, flightUntil = 0, visit;
  for (let now = 0; now < 240000 && progress < 1; now += frameMs) {
    const moving = now < flightUntil;
    const before = progress;
    const step = advanceOutageTour(clock, progress, frameMs, speed(now), moving);
    progress = step.progress;
    assert.ok(progress >= before && progress <= 1, 'the replay stays chronological');
    if (moving) assert.equal(progress, before, 'study time is held throughout the flight');
    if (step.stop) {
      visit = { stop: step.stop, progress, activeViewMs: 0 };
      visits.push(visit);
      flightUntil = now + OUTAGE_FLIGHT_MS;
    } else if (!moving && visit && progress >= visit.stop.start && progress < visit.stop.end) {
      visit.activeViewMs += frameMs;
    }
  }
  assert.equal(progress, 1, 'playback completes after the tour');
  assert.equal(visits.length, clock.stops.length, 'all selected areas are visited');
  for (const visit of visits) {
    assert.ok(visit.progress < visit.stop.end, 'the camera arrives before restoration');
    assert.ok(visit.activeViewMs >= 2000, 'each outage is visible for at least two seconds');
  }
  return visits;
}

test('future outages are reached before onset at every playback speed', () => {
  const stops = [
    { start: 0.7, end: 0.701 },
    { start: 0.1, end: 0.11 },
    { start: 0.4, end: 0.45 },
  ];
  const original = JSON.stringify(stops);
  for (const speed of REPLAY_SPEEDS) {
    const visits = replay(stops, { speed: () => speed });
    assert.deepEqual(visits.map(visit => visit.stop.start), [0.1, 0.4, 0.7]);
    for (const visit of visits) assert.ok(visit.progress < visit.stop.start);
  }
  assert.equal(JSON.stringify(stops), original, 'source event times remain unchanged');
});

test('short overlapping and already-active outages survive travel and speed changes', () => {
  replay([
    { start: 0.49, end: 0.5002 },
    { start: 0.5, end: 0.501 },
    { start: 0.5, end: 0.52 },
    { start: 0.5001, end: 0.5003 },
  ], { startProgress: 0.5, speed: now => now < 1500 ? 0.5 : now < 5000 ? 2 : 0.75 });
});

test('slow frames cannot skip an outage or consume its viewing time in one tick', () => {
  const visits = replay([{ start: 0.01, end: 0.01001 }], { speed: () => 2, frameMs: 1000 });
  assert.ok(visits[0].progress < visits[0].stop.start);
});

test('pausing mid-flight retains the same replay time and remaining observation period', () => {
  const clock = createOutageTourClock([{ start: 0.01, end: 0.02 }]);
  const departure = advanceOutageTour(clock, 0, 1000, 1);
  assert.ok(departure.stop);
  const snapshot = JSON.stringify(clock);
  assert.equal(advanceOutageTour(clock, departure.progress, 120000, 2, true).progress, departure.progress);
  assert.equal(JSON.stringify(clock), snapshot);
  assert.equal(advanceOutageTour(clock, departure.progress, 75, 2).progress, departure.progress);
});

test('real SMARTDS tours remain visible when starting at the beginning, middle, or end', () => {
  const data = JSON.parse(readFileSync(new URL('../../public/data/smartds.json', import.meta.url)));
  attachVirtualScenario(data);
  for (const startProgress of [0, 0.35, 0.7, 0.95]) {
    const stops = selectOutageTour(data.events, { startProgress, radius: 500 * (data.worldUnitsPerMeter || 1) });
    replay(stops, { startProgress, speed: () => 2 });
  }
});

test('an empty tour advances normally', () => {
  const clock = createOutageTourClock([{ start: 0, end: 0.2 }], 0.5);
  assert.equal(advanceOutageTour(clock, 0.5, 6000, 2).progress, 0.7);
});
