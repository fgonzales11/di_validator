import {analyzeTransformer} from './transformer-analysis.js';
self.onmessage=({data:{id,transformer,assumptions,count}})=>{try{self.postMessage({id,result:analyzeTransformer(transformer,assumptions,count)})}catch(error){self.postMessage({id,error:error.message})}};
