export function networkZoomLimits(initialExtent, physicalScale = 1) {
  return {min:0.005, max:Math.max(40, initialExtent / (10 * physicalScale))};
}

export function keyboardPanDistance(camera, viewportHeight) {
  return (camera.top - camera.bottom) / camera.zoom / Math.max(1, viewportHeight) * 30;
}

// Frame the same physical neighborhood regardless of the full network extent.
export function outageTourZoom(initialExtent, physicalScale = 1) {
  const limits = networkZoomLimits(initialExtent, physicalScale);
  return Math.min(limits.max, Math.max(limits.min, initialExtent / (700 * physicalScale)));
}
