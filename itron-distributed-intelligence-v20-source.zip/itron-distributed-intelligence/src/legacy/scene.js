import {networkZoomLimits,keyboardPanDistance,outageTourZoom} from './scene-navigation.js';
import {selectedNetworkPoint} from './street-view.js';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { nearestCircuit } from './network-style.js';
import { addNetworkEquipment, meterMarkers } from './equipment.js';
import { networkBusLocations, flowPaths, sampleFlowPath, lineConductorOffsets } from './powerflow-display.js';
import { createOutageTourClock, advanceOutageTour, OUTAGE_FLIGHT_MS } from './outage-tour.js';

// A deliberately schematic, deterministic digital twin. Geometry and colors are
// illustrative; the elevation of an outage represents duration, never terrain.
const PALETTE = {
  ink: '#081826', ground: '#0e2334', road: '#0a1c2b', curb: '#3d5660',
  building: '#263b44', edge: '#678894', wire: '#6aa8a4', mint: '#a9d8cc',
  amber: '#efba62', coral: '#ee806f', restored: '#78beb5',
};

function seeded(seed = 1729) {
  return () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
}

function segments(coordinates, material) {
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(coordinates, 3));
  return new THREE.LineSegments(geometry, material);
}

function addSegment(a, x1, y1, z1, x2, y2, z2) {
  a.push(x1, y1, z1, x2, y2, z2);
}

function boxEdges(a, x, y, z, w, h, d) {
  const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2;
  for (const yy of [y, y + h]) {
    addSegment(a, x0, yy, z0, x1, yy, z0);
    addSegment(a, x1, yy, z0, x1, yy, z1);
    addSegment(a, x1, yy, z1, x0, yy, z1);
    addSegment(a, x0, yy, z1, x0, yy, z0);
  }
  for (const xx of [x0, x1]) for (const zz of [z0, z1]) addSegment(a, xx, y, zz, xx, y + h, zz);
}

function glowTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 64;
  const ctx = canvas.getContext('2d');
  const radial = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  radial.addColorStop(0, 'rgba(255,255,255,1)');
  radial.addColorStop(0.17, 'rgba(255,255,255,0.95)');
  radial.addColorStop(0.36, 'rgba(255,255,255,0.3)');
  radial.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = radial;
  ctx.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(canvas);
}

function streetLabel(text, x, z, rotate = false) {
  const canvas = document.createElement('canvas');
  canvas.width = 768; canvas.height = 96;
  const ctx = canvas.getContext('2d');
  ctx.font = '500 43px Arial, sans-serif';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillStyle = '#9fbbc7';
  ctx.fillText(text, 384, 48);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(71, 8.9), new THREE.MeshBasicMaterial({ map: texture, transparent: true, opacity: 0.77, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 }));
  mesh.rotation.x = -Math.PI / 2;
  mesh.rotation.z = rotate ? Math.PI / 2 : 0;
  mesh.position.set(x, 0.19, z);
  return mesh;
}

function restorationFraction(value, fallback = 0.7) {
  if (typeof value === 'number' && value >= 0 && value <= 1) return value;
  const stamp = typeof value === 'string' ? Date.parse(value) : Number(value);
  if (!Number.isFinite(stamp)) return fallback;
  return THREE.MathUtils.clamp((stamp - Date.UTC(2026, 8, 17)) / (8 * 86400000), 0.1, 0.98);
}

function matchesCircuit(value, circuit) {
  const normalized = String(value ?? '').toLowerCase().replace(/[\s_-]/g, '');
  return [circuit.id, circuit.circuitId, circuit.name].some((candidate) => String(candidate ?? '').toLowerCase().replace(/[\s_-]/g, '') === normalized);
}

function spatialLineBatches(coordinates, material, parent, tileSize = 500, circuitId = null, pickable = [], assets = []) {
  const tiles = new Map();
  for (let i = 0; i < coordinates.length; i += 6) {
    const key = `${Math.floor((coordinates[i] + coordinates[i + 3]) / 2 / tileSize)},${Math.floor((coordinates[i + 2] + coordinates[i + 5]) / 2 / tileSize)}`;
    if (!tiles.has(key)) tiles.set(key, { coordinates: [], assets: [] });
    tiles.get(key).coordinates.push(...coordinates.slice(i, i + 6));
    if (assets.length) tiles.get(key).assets.push(assets[i / 6]);
  }
  for (const { coordinates, assets } of tiles.values()) {
    const batch = segments(coordinates, material);
    if (circuitId != null) { batch.userData = { circuitId, network: true, segmentAssets: assets }; pickable.push(batch); }
    parent.add(batch);
  }
}

// Bus keys keep equipment connectors from implying an overhead construction type.
export function undergroundBusLocations(lines = []) {
  return networkBusLocations(lines).filter(bus => bus.underground && !bus.overhead);
}

function solidBusPoints(locations, scale, circuitColors, pickable) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 32;
  const context = canvas.getContext('2d');
  context.fillStyle = '#ffffff';
  context.beginPath(); context.arc(16, 16, 14, 0, Math.PI * 2); context.fill();
  const texture = new THREE.CanvasTexture(canvas);
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(locations.flatMap(({ x, z, overhead }) => [x, (overhead ? 10.8 : 0.4) * scale, z]), 3));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(locations.flatMap(({ circuit }) => new THREE.Color(circuitColors.get(circuit) || PALETTE.mint).toArray()), 3));
  const material = new THREE.PointsMaterial({ vertexColors: true, size: 7, map: texture, alphaTest: 0.5, sizeAttenuation: false, transparent: true, depthWrite: false, depthTest: false });
  const points = new THREE.Points(geometry, material);
  points.name = 'network-buses';
  points.renderOrder = 5;
  points.userData = { network: true, circuitIds: locations.map(bus => bus.circuit), assets: locations };
  pickable.push(points);
  return points;
}

function buildRealTopology({ topology, circuits, layers, world, makePoints, scale, pickable, themeMaterial }) {
  const grid = new THREE.GridHelper(40000 * scale, 2000, '#36515d', '#36515d');
  grid.material.transparent = true; grid.material.opacity = 0.2;
  grid.material.depthWrite = false; grid.position.y = 0.005;
  themeMaterial(grid.material, { opacity: 0.12 });
  world.add(grid);
  const groundTrace = [], poleLocations = new Map(), contextSegments = [];
  const circuitColors = new Map(circuits.map(c => [c.id, c.color]));
  const circuitPhases = new Map(circuits.map(c => [c.id, c.phases]));
  const paths = new Map();
  const contextCenter = topology.initialView || { x: 0, z: 0 };
  const height = 10.5 * scale;
  for (const line of topology.lines || []) {
    if (!Array.isArray(line.points)) continue;
    if (!paths.has(line.circuit)) paths.set(line.circuit, { overhead: [], underground: [], connectors: [], assets: { overhead: [], underground: [], connectors: [] } });
    const path = paths.get(line.circuit);
    const before = Object.fromEntries(['overhead', 'underground', 'connectors'].map(kind => [kind, path[kind].length / 6]));
    const { overhead, underground, connectors } = paths.get(line.circuit);
    const isOverhead = line.overhead === true;
    for (let index = 1; index < line.points.length; index++) {
      const [x1, z1] = line.points[index - 1], [x2, z2] = line.points[index];
      if (![x1, z1, x2, z2].every(Number.isFinite)) continue;
      const dx = x2 - x1, dz = z2 - z1, length = Math.hypot(dx, dz);
      if (length < 0.001) continue;
      if (Math.abs((x1 + x2) / 2 - contextCenter.x) < 1800 * scale && Math.abs((z1 + z2) / 2 - contextCenter.z) < 1800 * scale) contextSegments.push({ x1, z1, dx, dz, length });
      addSegment(groundTrace, x1, 0.035, z1, x2, 0.035, z2);
      if (line.overhead == null) {
        addSegment(connectors, x1, 0.14 * scale, z1, x2, 0.14 * scale, z2);
        continue;
      }
      if (!isOverhead) {
        const dashCount = Math.max(1, Math.ceil(length / (7 * scale)));
        for (let dash = 0; dash < dashCount; dash++) {
          const a = dash / dashCount, b = Math.min(1, a + 0.6 / dashCount);
          addSegment(underground, x1 + dx * a, 0.14 * scale, z1 + dz * a, x1 + dx * b, 0.14 * scale, z1 + dz * b);
        }
        continue;
      }
      const spans = Math.max(1, Math.ceil(length / (55 * scale)));
      const nx = -dz / length, nz = dx / length;
      for (let span = 0; span <= spans; span++) {
        const t = span / spans, x = x1 + dx * t, z = z1 + dz * t;
        const key = `${Math.round(x / scale)},${Math.round(z / scale)}`;
        poleLocations.set(key, { x, z, circuit: line.circuit, angle: Math.atan2(nx, nz) });
        if (span === spans) continue;
        for (const offset of lineConductorOffsets(line, circuitPhases.get(line.circuit))) for (let s = 0; s < 5; s++) {
          const a = s / 5, b = (s + 1) / 5;
          const t1 = (span + a) / spans, t2 = (span + b) / spans;
          const sag = Math.min(1.8 * scale, length / spans * 0.06);
          addSegment(overhead,
            x1 + dx * t1 + nx * offset * scale, height - 4 * sag * a * (1 - a), z1 + dz * t1 + nz * offset * scale,
            x1 + dx * t2 + nx * offset * scale, height - 4 * sag * b * (1 - b), z1 + dz * t2 + nz * offset * scale);
        }
      }
    }
    const asset = { kind: 'line', id: line.id, circuit: line.circuit, points: line.points, fromBus: line.fromBus, toBus: line.toBus };
    for (const kind of ['overhead', 'underground', 'connectors']) {
      for (let i = before[kind]; i < path[kind].length / 6; i++) path.assets[kind].push(asset);
    }
  }
  const switchPaths=new Map();
  for(const item of topology.switches||[]) {
    if(!Array.isArray(item.points)||item.points.length<2)continue;
    if(!switchPaths.has(item.circuit))switchPaths.set(item.circuit,{segments:[],assets:[]});
    const path=switchPaths.get(item.circuit),asset={...item,kind:'switch'};
    for(let i=1;i<item.points.length;i++){
      const [x1,z1]=item.points[i-1],[x2,z2]=item.points[i];if(![x1,z1,x2,z2].every(Number.isFinite))continue;
      const intervals=item.closed?[[0,1]]:[[0,.35],[.65,1]];
      for(const [a,b] of intervals){addSegment(path.segments,x1+(x2-x1)*a,.2*scale,z1+(z2-z1)*a,x1+(x2-x1)*b,.2*scale,z1+(z2-z1)*b);path.assets.push(asset)}
    }
  }
  for(const [circuitId,path] of switchPaths)spatialLineBatches(path.segments,themeMaterial(new THREE.LineBasicMaterial({color:'#d1a84f',transparent:true,opacity:.95}),{color:'#9e711c'}),layers.network,500*scale,circuitId,pickable,path.assets);
  for (const [circuitId, path] of paths) {
    const color = circuitColors.get(circuitId) || PALETTE.mint;
    for (const [kind, opacity] of [['overhead', 0.95], ['underground', 0.85], ['connectors', 0.7]]) {
      spatialLineBatches(path[kind], themeMaterial(new THREE.LineBasicMaterial({ color, transparent: true, opacity }), { color: new THREE.Color(color).multiplyScalar(0.3) }), layers.network, 500 * scale, circuitId, pickable, path.assets[kind]);
    }
  }
  spatialLineBatches(groundTrace, themeMaterial(new THREE.LineBasicMaterial({ color: '#35545e', transparent: true, opacity: 0.17 }), { color: '#718b98', opacity: 0.25 }), world, 500 * scale);
  const buses = solidBusPoints(networkBusLocations(topology.lines), scale, circuitColors, pickable);
  themeMaterial(buses.material, { color: '#8d959a' });
  layers.network.add(buses);
  const transformerPoles=new Set((topology.transformers||[]).filter(t=>t.groupColor&&t.mounting==='overhead').map(t=>`${t.circuit}:${Math.round(t.x/scale)},${Math.round(t.z/scale)}`));
  const poles = [...poleLocations.values()].filter(p=>!transformerPoles.has(`${p.circuit}:${Math.round(p.x/scale)},${Math.round(p.z/scale)}`));
  const dummy = new THREE.Object3D();
  const poleMaterial = themeMaterial(new THREE.MeshBasicMaterial({ color: '#ffffff' }), { color: '#8d959a' });
  const poleGeometry = new THREE.CylinderGeometry(0.24 * scale, 0.33 * scale, 1, 5);
  const armGeometry = new THREE.BoxGeometry(1, 1, 1);
  const poleTiles = new Map(), poleTileSize = 2000 * scale;
  for (const pole of poles) {
    const key = `${Math.floor(pole.x / poleTileSize)},${Math.floor(pole.z / poleTileSize)}`;
    if (!poleTiles.has(key)) poleTiles.set(key, []);
    poleTiles.get(key).push(pole);
  }
  const nodes = [];
  // Regional instances need local bounds so a close view does not submit or
  // raycast every pole in the full service territory. Geometry stays shared.
  for (const tile of poleTiles.values()) {
    const poleMesh = new THREE.InstancedMesh(poleGeometry, poleMaterial, tile.length);
    const armMesh = new THREE.InstancedMesh(armGeometry, poleMaterial, tile.length);
    tile.forEach((pole, i) => {
      dummy.position.set(pole.x, height / 2, pole.z); dummy.rotation.set(0, 0, 0); dummy.scale.set(1, height + 0.5 * scale, 1); dummy.updateMatrix(); poleMesh.setMatrixAt(i, dummy.matrix);
      dummy.position.y = height - 0.4 * scale; dummy.rotation.y = pole.angle; dummy.scale.set(0.2 * scale, 0.2 * scale, 4.4 * scale); dummy.updateMatrix(); armMesh.setMatrixAt(i, dummy.matrix);
      const tint = new THREE.Color(circuitColors.get(pole.circuit) || PALETTE.mint).lerp(new THREE.Color('#ffffff'), 0.25);
      poleMesh.setColorAt(i, tint); armMesh.setColorAt(i, tint);
      nodes.push(pole.x, height + 0.35 * scale, pole.z);
    });
    const circuitIds = tile.map(pole => pole.circuit);
    for (const mesh of [poleMesh, armMesh]) {
      mesh.computeBoundingSphere(); mesh.userData = { network: true, circuitIds };
      pickable.push(mesh); layers.network.add(mesh);
    }
  }
  layers.network.add(makePoints(nodes, '#e3efd8', 5, 0.6));
  addNetworkEquipment({ topology, parent: layers.network, pickable, scale });
  layers.servicePoints.add(meterMarkers(topology.servicePoints, scale, pickable));

  // Small building forms indicate service locations only. They are intentionally
  // schematic; parcel footprints and surveyed heights are not present in SMARTDS.
  const locations = (topology.servicePoints || []).filter(p => p.locationBasis === 'recorded' && Number.isFinite(p.x) && Number.isFinite(p.z));
  const random = seeded(482);
  const forms = [], seen = new Set(), outlines = [];
  const cellSize = 20 * scale;
  const corridorCells = new Set(), contextCells = new Map();
  const cellKey = (x, z) => `${Math.floor(x / cellSize)},${Math.floor(z / cellSize)}`;
  // Reserve continuous open lanes, including diagonal stretches and junctions.
  // This is schematic clearance, not a surveyed road network.
  const roadIndex = new Map(), roadTile = 80 * scale, roadHalfWidth = 12 * scale;
  const margin = roadHalfWidth + 10 * scale;
  for (const line of topology.lines || []) for (let i = 1; i < (line.points?.length || 0); i++) {
    const [ax, az] = line.points[i - 1], [bx, bz] = line.points[i];
    if (![ax, az, bx, bz].every(Number.isFinite)) continue;
    const segment = { ax, az, dx: bx - ax, dz: bz - az };
    segment.length2 = segment.dx ** 2 + segment.dz ** 2;
    if (!segment.length2) continue;
    for (let tx = Math.floor((Math.min(ax, bx) - margin) / roadTile); tx <= Math.floor((Math.max(ax, bx) + margin) / roadTile); tx++) {
      for (let tz = Math.floor((Math.min(az, bz) - margin) / roadTile); tz <= Math.floor((Math.max(az, bz) + margin) / roadTile); tz++) {
        const key = `${tx},${tz}`;
        if (!roadIndex.has(key)) roadIndex.set(key, []);
        roadIndex.get(key).push(segment);
      }
    }
  }
  function clearsLane(x, z, w, d) {
    const clearance2 = (roadHalfWidth + Math.hypot(w, d) / 2) ** 2;
    return (roadIndex.get(`${Math.floor(x / roadTile)},${Math.floor(z / roadTile)}`) || []).every(({ ax, az, dx, dz, length2 }) => {
      const t = Math.max(0, Math.min(1, ((x - ax) * dx + (z - az) * dz) / length2));
      return (x - ax - t * dx) ** 2 + (z - az - t * dz) ** 2 >= clearance2;
    });
  }
  // The neutral block texture is visual context, not fabricated GIS. Its parcels
  // occupy a regular display grid alongside genuine line corridors. Source
  // electrical coordinates, customer points, and outage cells are never altered.
  for (const segment of contextSegments) {
    const { x1, z1, dx, dz, length } = segment;
    const count = Math.max(1, Math.ceil(length / (10 * scale)));
    const nx = -dz / length, nz = dx / length;
    for (let i = 0; i <= count; i++) {
      const x = x1 + dx * i / count, z = z1 + dz * i / count;
      corridorCells.add(cellKey(x, z));
      for (const setback of [-38, 38]) {
        const cx = (Math.floor((x + nx * setback * scale) / cellSize) + 0.5) * cellSize;
        const cz = (Math.floor((z + nz * setback * scale) / cellSize) + 0.5) * cellSize;
        contextCells.set(cellKey(cx, cz), [cx, cz]);
      }
    }
  }
  for (const [key, [x, z]] of contextCells) {
    if (corridorCells.has(key) || random() < 0.3) continue;
    seen.add(key);
    const w = (9 + random() * 4) * scale, d = (9 + random() * 4) * scale;
    const h = (random() < 0.075 ? 11 + random() * 6 : 4 + random() * 5) * scale;
    if (!clearsLane(x, z, w, d)) continue;
    forms.push({ x, z, w, d, h });
    boxEdges(outlines, x, 0.08 * scale, z, w, h, d);
  }
  for (const point of locations) {
    if (contextCells.size && Math.abs(point.x - contextCenter.x) < 1650 * scale && Math.abs(point.z - contextCenter.z) < 1650 * scale) continue;
    const key = cellKey(point.x, point.z);
    if (seen.has(key)) continue;
    seen.add(key);
    const offsets = topology.contextMode === 'premises' ? [[0, 0]] : [[20, 20]];
    for (const [dx, dz] of offsets) {
      const w = (7 + random() * 4) * scale, d = (8 + random() * 5) * scale, h = (4 + random() * 7) * scale;
      const x = point.x + dx * scale, z = point.z + dz * scale;
      if (!clearsLane(x, z, w, d)) continue;
      forms.push({ x, z, w, d, h });
      boxEdges(outlines, x, 0.08 * scale, z, w, h, d);
    }
  }
  const buildingTiles = new Map();
  for (const form of forms) {
    const key = `${Math.floor(form.x / (500 * scale))},${Math.floor(form.z / (500 * scale))}`;
    if (!buildingTiles.has(key)) buildingTiles.set(key, []);
    buildingTiles.get(key).push(form);
  }
  const buildingGeometry = new THREE.BoxGeometry(1, 1, 1);
  const buildingMaterial = themeMaterial(new THREE.MeshStandardMaterial({ color: '#304650', roughness: 0.96, metalness: 0.03, emissive: '#2c4350', emissiveIntensity: 0.46 }), { color: '#81949e', emissive: '#a5b7c0', emissiveIntensity: 0.15 });
  for (const tile of buildingTiles.values()) {
    const buildings = new THREE.InstancedMesh(buildingGeometry, buildingMaterial, tile.length);
    tile.forEach((form, i) => {
      dummy.position.set(form.x, form.h / 2 + 0.08 * scale, form.z); dummy.rotation.set(0, 0, 0); dummy.scale.set(form.w, form.h, form.d); dummy.updateMatrix(); buildings.setMatrixAt(i, dummy.matrix);
    });
    buildings.computeBoundingSphere(); layers.buildings.add(buildings);
  }
  spatialLineBatches(outlines, themeMaterial(new THREE.LineBasicMaterial({ color: '#8babaf', transparent: true, opacity: 0.36 }), { color: '#607b88', opacity: 0.48 }), layers.buildings, 500 * scale);
}

export function createScene({ container, circuits = [], topology = null, transformerMarkers = [], onTransformerSelect = () => {}, onSelect = () => {}, onContextChange = () => {}, onOutageSelect = () => {}, onCameraChange = () => {}, onAssetHover = () => {}, onTourStop = () => {}, onTourInterrupted = () => {}, onReady = () => {}, onVisibilityChange = () => {} }) {
  if (!container) throw new Error('The 3D map needs a container.');
  // Theme neutral context and circuit contrast without changing circuit hues or outage categories.
  const themeMaterials = [];
  function themeMaterial(material, light) {
    const dark = Object.fromEntries(Object.keys(light).map(key => [key, material[key]?.isColor ? material[key].clone() : material[key]]));
    themeMaterials.push({ material, light, dark });
    return material;
  }
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
  } catch {
    throw new Error('The 3D network needs WebGL. Enable graphics acceleration in your browser and reload.');
  }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.8));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.NoToneMapping;
  renderer.setClearColor(PALETTE.ink);
  renderer.domElement.setAttribute('aria-label', 'Interactive 3D distribution network. Left-drag to pan, right-drag to orbit, scroll to zoom.');
  renderer.domElement.tabIndex = 0;
  renderer.domElement.style.cssText = 'display:block;width:100%;height:100%;touch-action:none;outline:none;';
  container.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(PALETTE.ink);
  scene.fog = new THREE.FogExp2(PALETTE.ink, 0.00042);
  const world = new THREE.Group();
  scene.add(world);
  const camera = new THREE.OrthographicCamera(-320, 320, 200, -200, 0.1, 2600);
  const physicalScale = Number(topology?.worldUnitsPerMeter) || 1;
  const initialExtent = Number(topology?.initialView?.extent) || 360;
  const initialTarget = new THREE.Vector3(topology?.initialView?.x || 0, 0, topology?.initialView?.z || -18);
  const initialPosition = initialTarget.clone().add(new THREE.Vector3(310, 330, 398).multiplyScalar(initialExtent / 360));
  camera.position.copy(initialPosition);
  const controls = new OrbitControls(camera, renderer.domElement);
  controls.target.copy(initialTarget);
  controls.enableDamping = true;
  controls.dampingFactor = 0.18;
  const zoomLimits = networkZoomLimits(initialExtent, physicalScale);
  controls.minZoom = zoomLimits.min;
  controls.maxZoom = zoomLimits.max;
  controls.mouseButtons.LEFT = THREE.MOUSE.PAN;
  controls.mouseButtons.RIGHT = THREE.MOUSE.ROTATE;
  controls.minPolarAngle = 0.025;
  controls.maxPolarAngle = Math.PI * 0.425;
  controls.rotateSpeed = 0.55;
  controls.zoomSpeed = 0.8;
  controls.panSpeed = 0.75;
  controls.screenSpacePanning = false;
  controls.update();

  scene.add(new THREE.AmbientLight('#adc9d4', 2.1));
  const sunlight = new THREE.DirectionalLight('#bedbe3', 1.85);
  sunlight.position.set(-180, 400, -180);
  scene.add(sunlight);
  const fillLight = new THREE.DirectionalLight('#587c91', 0.55);
  fillLight.position.set(300, 80, 180);
  scene.add(fillLight);

  const pickable = [];
  const layers = {};
  for (const key of ['buildings', 'network', 'servicePoints', 'outages', 'transformers']) {
    layers[key] = new THREE.Group();
    layers[key].name = key;
    world.add(layers[key]);
  }
  layers.servicePoints.visible = false;
  const base = new THREE.Mesh(new THREE.PlaneGeometry(topology ? 50000 : 1600, topology ? 50000 : 1600), new THREE.MeshBasicMaterial({ color: PALETTE.ground }));
  base.rotation.x = -Math.PI / 2;
  base.position.y = -0.05;
  world.add(base);

  const dotTexture = glowTexture();
  const transformerById = new Map(transformerMarkers.map(t => [t.id, t]));
  let transformerSelection;
  if (transformerMarkers.length) {
    const canvas = document.createElement('canvas'); canvas.width = canvas.height = 32;
    const ctx = canvas.getContext('2d'); ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(16,16,12,0,Math.PI*2); ctx.fill();
    const markerTexture = new THREE.CanvasTexture(canvas);
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(transformerMarkers.flatMap(t=>[t.x,15*physicalScale,t.z]),3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(transformerMarkers.flatMap(t=>new THREE.Color(t.color||'#a9d8cc').toArray()),3));
    const points = new THREE.Points(geometry,new THREE.PointsMaterial({size:8,sizeAttenuation:false,vertexColors:true,map:markerTexture,transparent:true,depthTest:false,depthWrite:false}));
    points.userData={transformerSymbol:true,assets:transformerMarkers.map(t=>({...t,kind:'transformer'})),circuitIds:transformerMarkers.map(t=>t.circuit)};
    points.renderOrder=10; layers.transformers.add(points); pickable.push(points);
    const ringCanvas=document.createElement('canvas');ringCanvas.width=ringCanvas.height=64;
    const ring=ringCanvas.getContext('2d');ring.strokeStyle='#ffffff';ring.lineWidth=5;ring.beginPath();ring.arc(32,32,25,0,Math.PI*2);ring.stroke();
    const selectedGeometry=new THREE.BufferGeometry();selectedGeometry.setAttribute('position',new THREE.Float32BufferAttribute([0,16*physicalScale,0],3));
    transformerSelection=new THREE.Points(selectedGeometry,new THREE.PointsMaterial({size:26,sizeAttenuation:false,color:'#efba62',map:new THREE.CanvasTexture(ringCanvas),transparent:true,depthTest:false,depthWrite:false}));
    transformerSelection.visible=false;transformerSelection.renderOrder=11;layers.transformers.add(transformerSelection);
  }

  let roofObject = new THREE.Group();
  function makePoints(positions, color, size, opacity) {
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    return new THREE.Points(geometry, new THREE.PointsMaterial({ color, size, map: dotTexture, transparent: true, depthWrite: false, opacity, blending: THREE.AdditiveBlending, sizeAttenuation: true }));
  }

  // Roads, setbacks, and parcel seams establish scale without fetching map tiles.
  if (!topology) {
  const roadMat = new THREE.MeshBasicMaterial({ color: PALETTE.road });
  const roadGeometry = new THREE.PlaneGeometry(1400, 15);
  const curbs = [], parcels = [], centerLines = [];
  for (let road = -650; road <= 650; road += 100) {
    for (const rotated of [false, true]) {
      const mesh = new THREE.Mesh(roadGeometry, roadMat);
      mesh.rotation.x = -Math.PI / 2;
      mesh.rotation.z = rotated ? Math.PI / 2 : 0;
      mesh.position.set(rotated ? road : 0, 0.025, rotated ? 0 : road);
      world.add(mesh);
      for (const edge of [-9, 9]) {
        if (rotated) addSegment(curbs, road + edge, 0.05, -700, road + edge, 0.05, 700);
        else addSegment(curbs, -700, 0.05, road + edge, 700, 0.05, road + edge);
      }
      for (let along = -700; along < 700; along += 16) {
        if (rotated) addSegment(centerLines, road, 0.045, along, road, 0.045, along + 5);
        else addSegment(centerLines, along, 0.045, road, along + 5, 0.045, road);
      }
    }
  }
  world.add(segments(curbs, new THREE.LineBasicMaterial({ color: PALETTE.curb, transparent: true, opacity: 0.46 })));
  world.add(segments(centerLines, new THREE.LineBasicMaterial({ color: '#55717a', transparent: true, opacity: 0.13 })));
  for (let n = -700; n <= 700; n += 25) {
    addSegment(parcels, n, 0.006, -700, n, 0.006, 700);
    addSegment(parcels, -700, 0.006, n, 700, 0.006, n);
  }
  world.add(segments(parcels, new THREE.LineBasicMaterial({ color: '#63838d', transparent: true, opacity: 0.085 })));
  for (const [name, x, z, rotate] of [
    ['W Cayuga St', -180, -150, false], ['W Mohawk Ave', 130, -150, false],
    ['W Powhatan Ave', -125, 150, false], ['W Comanche Ave', -130, -50, false],
    ['W Hillsborough Ave', 125, 250, false], ['W Crest Ave', -140, -250, false],
    ['N Himes Ave', -250, -40, true], ['N Manhattan Ave', 150, -95, true],
    ['N Armenia Ave', 250, 95, true], ['N Lincoln Ave', -150, 170, true],
  ]) world.add(streetLabel(name, x, z, rotate));

  const random = seeded();
  const buildings = [], buildingEdges = [], roofDetails = [], shadows = [];
  for (let bx = -600; bx <= 600; bx += 100) for (let bz = -600; bz <= 600; bz += 100) {
    for (let ix = -1; ix <= 1; ix++) for (let iz = -1; iz <= 1; iz++) {
      if (random() < 0.13) continue;
      const x = bx + ix * 23 + (random() - 0.5) * 4;
      const z = bz + iz * 23 + (random() - 0.5) * 4;
      const width = 10 + random() * 7;
      const depth = 9 + random() * 9;
      const height = random() < 0.14 ? 16 + random() * 13 : 4 + random() * 9;
      const tint = new THREE.Color(PALETTE.building).multiplyScalar(0.76 + random() * 0.42);
      buildings.push({ x, z, width, depth, height, tint });
      boxEdges(buildingEdges, x, 0.18, z, width, height, depth);
      if (random() > 0.5) {
        addSegment(roofDetails, x - width / 2, height + 0.19, z, x + width / 2, height + 0.19, z);
        addSegment(roofDetails, x, height + 0.19, z - depth / 2, x, height + 0.19, z + depth / 2);
      }
      shadows.push({ x: x + 2, z: z + 2, width: width + 4, depth: depth + 4 });
    }
  }
  const dummy = new THREE.Object3D();
  const buildingMesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.97, metalness: 0.04, emissive: '#233946', emissiveIntensity: 0.25 }), buildings.length);
  buildings.forEach((b, i) => {
    dummy.position.set(b.x, b.height / 2 + 0.15, b.z);
    dummy.scale.set(b.width, b.height, b.depth);
    dummy.rotation.set(0, 0, 0); dummy.updateMatrix();
    buildingMesh.setMatrixAt(i, dummy.matrix); buildingMesh.setColorAt(i, b.tint);
  });
  buildingMesh.instanceMatrix.needsUpdate = true;
  buildingMesh.computeBoundingSphere();
  layers.buildings.add(buildingMesh);
  const edgeObject = segments(buildingEdges, new THREE.LineBasicMaterial({ color: PALETTE.edge, transparent: true, opacity: 0.36 }));
  roofObject = segments(roofDetails, new THREE.LineBasicMaterial({ color: '#698692', transparent: true, opacity: 0.1 }));
  layers.buildings.add(edgeObject, roofObject);
  const footprintMesh = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ color: '#030e15', transparent: true, opacity: 0.43, depthWrite: false }), shadows.length);
  shadows.forEach((s, i) => {
    dummy.position.set(s.x, 0.03, s.z); dummy.rotation.set(-Math.PI / 2, 0, 0);
    dummy.scale.set(s.width, s.depth, 1); dummy.updateMatrix(); footprintMesh.setMatrixAt(i, dummy.matrix);
  });
  footprintMesh.computeBoundingSphere();
  layers.buildings.add(footprintMesh);

  // Three overhead phases sag between each pair of crossarms. All background
  // infrastructure is batched to keep orbiting inexpensive on integrated GPUs.
  const poles = [], conductors = [], insulators = [], nodes = [], serviceLocations = [];
  for (let road = -550; road <= 550; road += 100) {
    for (const orientation of ['x', 'z']) {
      for (let along = -575; along <= 575; along += 50) {
        const x = orientation === 'x' ? along : road + 10;
        const z = orientation === 'x' ? road + 10 : along;
        poles.push({ x, z, orientation });
        nodes.push(x, 0.65, z);
        for (const phase of [-2.3, 0, 2.3]) {
          const px = x + (orientation === 'z' ? phase : 0);
          const pz = z + (orientation === 'x' ? phase : 0);
          insulators.push(px, 13.2, pz);
          if (along < 575) for (let step = 0; step < 12; step++) {
            const t1 = step / 12, t2 = (step + 1) / 12;
            const h1 = 13.1 - 2.4 * 4 * t1 * (1 - t1), h2 = 13.1 - 2.4 * 4 * t2 * (1 - t2);
            addSegment(conductors, px + (orientation === 'x' ? t1 * 50 : 0), h1, pz + (orientation === 'z' ? t1 * 50 : 0), px + (orientation === 'x' ? t2 * 50 : 0), h2, pz + (orientation === 'z' ? t2 * 50 : 0));
          }
        }
      }
    }
  }
  const poleMaterial = new THREE.MeshBasicMaterial({ color: '#b5cfbc' });
  const poleGeometry = new THREE.CylinderGeometry(0.16, 0.23, 1, 5);
  const poleMesh = new THREE.InstancedMesh(poleGeometry, poleMaterial, poles.length);
  const armMesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), poleMaterial, poles.length);
  poles.forEach((pole, i) => {
    dummy.position.set(pole.x, 6.45, pole.z); dummy.rotation.set(0, 0, 0); dummy.scale.set(1, 12.9, 1); dummy.updateMatrix(); poleMesh.setMatrixAt(i, dummy.matrix);
    dummy.position.set(pole.x, 12.4, pole.z); dummy.scale.set(pole.orientation === 'z' ? 6.2 : 0.24, 0.23, pole.orientation === 'x' ? 6.2 : 0.24); dummy.updateMatrix(); armMesh.setMatrixAt(i, dummy.matrix);
  });
  poleMesh.computeBoundingSphere(); armMesh.computeBoundingSphere();
  layers.network.add(poleMesh, armMesh);
  layers.network.add(segments(conductors, new THREE.LineBasicMaterial({ color: PALETTE.wire, transparent: true, opacity: 0.7 })));
  layers.network.add(makePoints(insulators, '#d1e1cf', 4.5, 0.95), makePoints(nodes, '#d2e5d5', 8, 0.9));
  buildings.forEach((b) => serviceLocations.push(b.x + b.width / 2 + 1, 0.75, b.z));
  layers.servicePoints.add(makePoints(serviceLocations, '#a1e0d0', 3.6, 0.95));
  } else {
    buildRealTopology({ topology, circuits, layers, world, makePoints, scale: physicalScale, pickable, themeMaterial });
  }

  const selectionStates = new Map();
  const maxCellHours = Math.max(1, ...(topology?.outageCells || []).map((cell) => Number(cell.hours) || 0));
  let selectedId = circuits[0]?.id;
  let progress = 0, heightScale = 4, scenario = 'baseline', disposed = false, reducedMotion = false, view = '3d';
  let animationFrame = 0, transition = null, needsRender = true, width = 1, height = 1;
  const projection = new THREE.Vector3();
  const clock = new THREE.Clock();
  let flowObject = null, particlePaths = [], particleTime = 0, previousFrame = 0;
  let tour = null, inViewport = true, interacting = false, lastMotion = 0, quality = 'high';
  let hovering = false, renderedFrames = 0;
  const visibilityObserver = new IntersectionObserver(([entry]) => {
    const next = entry.isIntersecting;
    if (next === inViewport) return;
    inViewport = next; previousFrame = 0; needsRender = true;
    onVisibilityChange(next);
  });
  visibilityObserver.observe(container);
  function clearHover() { if (hovering) { hovering = false; onAssetHover(null); } }
  function updateResolution(moving) {
    const ratio = quality === 'low' || moving ? 1 : Math.min(window.devicePixelRatio || 1, 1.8);
    if (renderer.getPixelRatio() !== ratio) { renderer.setPixelRatio(ratio); needsRender = true; }
  }

  function clearFlow() {
    if (flowObject) { layers.network.remove(flowObject); flowObject.geometry.dispose(); flowObject.material.dispose(); }
    flowObject = null; particlePaths = [];
  }
  function updateParticles(dt = 0) {
    if (!flowObject) return;
    particleTime += dt;
    const positions = flowObject.geometry.attributes.position.array;
    let offset = 0;
    for (const path of particlePaths) for (let i = 0; i < path.count; i++) {
      const distance = path.length * (i + 0.5) / path.count + particleTime * 22 * physicalScale * path.direction;
      for (let tail = 0; tail < 3; tail++) {
        sampleFlowPath(path, distance - tail * Math.min(1.5 * physicalScale, path.length / 12) * path.direction, positions, offset);
        offset += 3;
      }
    }
    flowObject.geometry.attributes.position.needsUpdate = true;
    needsRender = true;
  }
  function stopTour(manual = false) {
    if (tour) tour.playing = false;
    if (transition?.flight) {
      if (tour && !manual) tour.pausedTransition = { ...transition, elapsed: performance.now() - transition.start };
      transition = null;
    }
    if (manual) { if (tour) { tour.interrupted = true; tour.pausedTransition = null; } onTourInterrupted(); }
  }

  const renderCircuits = topology?.outageCells?.some((cell) => cell.circuit == null) ? [...circuits, { id: '__unassigned', x: 0, z: 0, unassigned: true }] : circuits;
  renderCircuits.forEach((circuit, index) => {
    const group = new THREE.Group();
    group.position.set(Number(circuit.x) || 0, 0, Number(circuit.z) || 0);
    layers.outages.add(group);
    const realCells = topology?.outageCells?.filter((cell) => circuit.unassigned ? cell.circuit == null : matchesCircuit(cell.circuit, circuit)) || [];
    const placements = topology ? realCells.map((cell) => [cell.x - group.position.x, cell.z - group.position.z, Math.max(1, 65 * Math.max(0, cell.hours || 0) / maxCellHours) * physicalScale, cell]) : [[-43, 21, 23], [-25, -11, 34], [2, 18, 17], [25, -17, 39], [43, 16, 24], [6, -27, 30]];
    const borderX = topology ? initialExtent * 0.22 : 59;
    const borderZ = topology ? initialExtent * 0.14 : 39;
    const groundY = topology ? physicalScale * 0.5 : 0.5;
    const rectPoints = [new THREE.Vector3(-borderX, groundY, -borderZ), new THREE.Vector3(borderX, groundY, -borderZ), new THREE.Vector3(borderX, groundY, borderZ), new THREE.Vector3(-borderX, groundY, borderZ), new THREE.Vector3(-borderX, groundY, -borderZ)];
    const border = new THREE.Line(new THREE.BufferGeometry().setFromPoints(rectPoints), new THREE.LineDashedMaterial({ color: PALETTE.amber, dashSize: 4.5, gapSize: 3, transparent: true, opacity: 0.95 }));
    border.computeLineDistances(); group.add(border);
    const fill = new THREE.Mesh(new THREE.PlaneGeometry(borderX * 2, borderZ * 2), new THREE.MeshBasicMaterial({ color: PALETTE.amber, transparent: true, opacity: 0.035, depthWrite: false, side: THREE.DoubleSide }));
    fill.rotation.x = -Math.PI / 2; fill.position.y = 0.3; group.add(fill);
    fill.userData.circuitId = circuit.id;
    if (!topology) pickable.push(fill);
    if (topology) fill.visible = false;

    const columnGroup = new THREE.Group(); group.add(columnGroup);
    const volumes = [];
    placements.forEach(([x, z, baseHeight, source], i) => {
      const color = i % 3 === 0 ? PALETTE.coral : PALETTE.amber;
      const cellWidth = topology ? 20 * physicalScale : 6.6;
      const columnWidth = topology ? 8 * physicalScale : cellWidth;
      const volume = new THREE.Group(); volume.position.set(x, physicalScale * 0.3, z);
      const material = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.22, depthWrite: false });
      const block = new THREE.Mesh(new THREE.BoxGeometry(columnWidth, 1, columnWidth), material);
      block.position.y = 0.5;
      block.userData.circuitId = circuit.unassigned ? null : circuit.id;
      block.userData.outageCell = source;
      const edges = new THREE.LineSegments(new THREE.EdgesGeometry(block.geometry), new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.94 })); edges.position.y = 0.5;
      const cap = new THREE.Mesh(new THREE.PlaneGeometry(columnWidth, columnWidth), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.8, side: THREE.DoubleSide }));
      cap.rotation.x = -Math.PI / 2; cap.position.y = 1;
      volume.add(block, edges, cap); columnGroup.add(volume); pickable.push(block);
      const footprint = new THREE.Mesh(new THREE.PlaneGeometry(cellWidth, cellWidth), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.11, side: THREE.DoubleSide, depthWrite: false }));
      footprint.position.set(x, physicalScale * 0.23, z); footprint.rotation.x = -Math.PI / 2;
      group.add(footprint);
      const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: dotTexture, color, transparent: true, opacity: 0.45, depthWrite: false, blending: THREE.AdditiveBlending }));
      glow.position.set(x, physicalScale * 1.4, z); glow.scale.set(cellWidth * 2.5, cellWidth * 2.5, 1); group.add(glow);
      volumes.push({ volume, block, edges, cap, glow, footprint, cellWidth, columnWidth, source, baseHeight, color: new THREE.Color(color), threshold: source ? (Number.isFinite(source.restoredFraction) ? source.restoredFraction : restorationFraction(source.restoredAt)) : restorationFraction(circuit.restoredAt, 0.65 + index * 0.04) + (i - 2) * 0.035 });
    });

    const highlightNetwork = new THREE.Group();
    const wireSegments = [], brightPoles = [], brightNodes = [];
    if (!topology) for (const z of [-30, 30]) {
      for (let i = 0; i < 5; i++) {
        const x = -50 + i * 25;
        addSegment(brightPoles, x, 0.5, z, x, 13.5, z);
        addSegment(brightPoles, x, 12.8, z - 3, x, 12.8, z + 3);
        brightNodes.push(x, 0.9, z, x, 13.4, z - 2.5, x, 13.4, z + 2.5);
        if (i < 4) for (const offset of [-2.5, 0, 2.5]) for (let step = 0; step < 8; step++) {
          const t1 = step / 8, t2 = (step + 1) / 8;
          addSegment(wireSegments, x + t1 * 25, 13.3 - 4 * t1 * (1 - t1), z + offset, x + t2 * 25, 13.3 - 4 * t2 * (1 - t2), z + offset);
        }
      }
    }
    const anchorPoints = [];
    if (topology) {
      for (const line of topology.lines || []) {
        if (!matchesCircuit(line.circuit, circuit)) continue;
        for (let i = 1; i < line.points.length; i++) {
          const [x1, z1] = line.points[i - 1], [x2, z2] = line.points[i];
          anchorPoints.push([x1, z1]);
          const y = (line.overhead === true ? 10.5 : 0.2) * physicalScale;
          addSegment(wireSegments, x1 - group.position.x, y, z1 - group.position.z, x2 - group.position.x, y, z2 - group.position.z);
        }
      }
    }
    const circuitTint = new THREE.Color(circuit.color || PALETTE.mint).lerp(new THREE.Color('#ffffff'), 0.3);
    const selectedLines = segments(wireSegments, themeMaterial(new THREE.LineBasicMaterial({ color: circuitTint, transparent: true, opacity: 0.7 }), { color: circuitTint.clone().multiplyScalar(0.3) }));
    selectedLines.userData.circuitId = circuit.id;
    selectedLines.userData.network = true;
    // Selection is picked from the actual rendered network, including poles and buses.
    highlightNetwork.add(segments(brightPoles, new THREE.LineBasicMaterial({ color: '#f1ca83' })), selectedLines, makePoints(brightNodes, '#ffe0a2', 5.5, 0.8));
    group.add(highlightNetwork);
    const ring = new THREE.Mesh(new THREE.RingGeometry(2.3, 3, 40), new THREE.MeshBasicMaterial({ color: circuitTint, side: THREE.DoubleSide, transparent: true, opacity: 0.95 }));
    ring.rotation.x = -Math.PI / 2; ring.position.set(0, 1, 0); group.add(ring);
    const beacon = new THREE.Sprite(new THREE.SpriteMaterial({ map: dotTexture, color: circuitTint, depthWrite: false, transparent: true, blending: THREE.AdditiveBlending }));
    beacon.scale.set(7, 7, 1); beacon.position.set(0, 2, 0); group.add(beacon);
    selectionStates.set(circuit.id, { circuit, group, border, fill, volumes, highlightNetwork, ring, beacon, anchorPoints });
  });

  function updateOutages() {
    const multiplier = scenario === 'storm' ? 1.55 : scenario === 'restoration' ? 0.63 : 1;
    for (const [id, state] of selectionStates) {
      const selected = id === selectedId || Boolean(state.circuit.unassigned);
      state.border.visible = selected && !topology; state.ring.visible = selected && !state.circuit.unassigned; state.beacon.visible = selected && !state.circuit.unassigned;
      state.highlightNetwork.visible = id === selectedId && layers.network.visible;
      state.fill.material.opacity = selected ? 0.035 : 0.012;
      state.volumes.forEach((v) => {
        const threshold = v.threshold;
        let restored = progress >= threshold;
        let occurred = true;
        let displayHeight = v.baseHeight;
        if (v.source?.intervals?.length) {
          const timeShift = 0; // Display scenarios never alter recorded event times.
          const started = v.source.intervals.filter((interval) => progress >= interval.startFraction);
          occurred = started.length > 0;
          let elapsedHours = 0;
          let active = false;
          for (const interval of started) {
            const end = Math.max(interval.startFraction + 0.000001, Math.min(1, interval.endFraction + timeShift));
            elapsedHours += interval.hours * THREE.MathUtils.clamp((progress - interval.startFraction) / (end - interval.startFraction), 0, 1);
            if (progress < end) active = true;
          }
          restored = occurred && !active;
          displayHeight = Math.max(1, 65 * elapsedHours / maxCellHours) * physicalScale;
        }
        const growth = progress < 0.45 ? 0.46 + progress * 1.2 : Math.max(0.25, 1 - (progress - 0.45) * 1.5);
        const h = restored ? 0.8 * physicalScale : displayHeight * multiplier * (topology ? heightScale : growth * (selected ? 1 : 0.54));
        v.volume.scale.y = h;
        const footprintRatio = restored ? v.cellWidth / v.columnWidth : 1;
        v.volume.scale.x = footprintRatio; v.volume.scale.z = footprintRatio;
        v.volume.visible = occurred; v.glow.visible = occurred; v.footprint.visible = occurred && !restored;
        const color = restored ? new THREE.Color(PALETTE.restored) : v.color;
        v.block.material.color.copy(color); v.edges.material.color.copy(color); v.cap.material.color.copy(color); v.glow.material.color.copy(color); v.footprint.material.color.copy(color);
        v.block.material.opacity = selected ? 0.25 : 0.13;
        v.edges.material.opacity = selected ? 0.97 : 0.43;
        v.cap.material.opacity = selected ? 0.85 : 0.4;
        v.glow.material.opacity = restored ? 0.16 : selected ? 0.46 : 0.13;
      });
    }
    needsRender = true;
  }

  function cameraChanged() {
    needsRender = true;
    clearHover();
    // Keep the expanded regional footprint in front of the camera and inside
    // its depth range as orthographic zoom reveals the whole service area.
    const regionalScale = 1 / Math.min(1, camera.zoom);
    const distance = (view === '2d' ? 600 : initialPosition.distanceTo(initialTarget)) * regionalScale;
    const direction = camera.position.clone().sub(controls.target).normalize();
    camera.position.copy(controls.target).addScaledVector(direction, distance);
    const far = Math.max(2600, distance + initialExtent * regionalScale * 2);
    if (camera.far !== far) { camera.far = far; camera.updateProjectionMatrix(); }
    scene.fog.density = 0.00042 / (Math.max(1, initialExtent / 360) * regionalScale);
    layers.servicePoints.traverse(object => {
      if (object.userData.meterSymbol) object.material.size = Math.max(2, 18 * Math.min(1, camera.zoom));
    });
    const selected = selectionStates.get(selectedId);
    const target = selected?.group.position || new THREE.Vector3();
    projection.copy(target);
    if (selected?.anchorPoints.length) {
      let best = Infinity;
      for (const [x, z] of selected.anchorPoints) {
        const distance = (x - controls.target.x) ** 2 + (z - controls.target.z) ** 2;
        if (distance < best) { best = distance; projection.x = x; projection.z = z; }
      }
    }
    projection.y = 18 * physicalScale; projection.project(camera);
    onCameraChange({ azimuth: controls.getAzimuthalAngle(), pitch: 90 - THREE.MathUtils.radToDeg(controls.getPolarAngle()), screenX: (projection.x + 1) * width / 2, screenY: (1 - projection.y) * height / 2, visible: projection.z > -1 && projection.z < 1 && Math.abs(projection.x) < 1.1 && Math.abs(projection.y) < 1.1 });
  }
  controls.addEventListener('change', cameraChanged);
  let navigationTarget = null, pendingContext = false;
  function updateNavigationContext() {
    if (!topology) return;
    const id = nearestCircuit(topology.lines, controls.target, selectedId, initialExtent / camera.zoom / 3);
    if (id && id !== selectedId) onContextChange(id);
  }
  controls.addEventListener('start', () => {
    interacting = true; clearHover(); navigationTarget = controls.target.clone(); pendingContext = false; stopTour(true); transition = null; renderer.domElement.style.cursor = 'grabbing'; });
  controls.addEventListener('end', () => {
    interacting = false; lastMotion = performance.now();
    renderer.domElement.style.cursor = 'grab';
    if (topology && navigationTarget && navigationTarget.distanceTo(controls.target) > physicalScale) {
      pendingContext = true;
    }
    navigationTarget = null;
  });
  renderer.domElement.style.cursor = 'grab';

  function resize() {
    width = Math.max(container.clientWidth, 1); height = Math.max(container.clientHeight, 1);
    const extent = initialExtent * (width < 700 ? 1.083 : 1);
    camera.left = -extent * width / height / 2; camera.right = extent * width / height / 2;
    camera.top = extent / 2; camera.bottom = -extent / 2; camera.updateProjectionMatrix();
    renderer.setSize(width, height, false);
    cameraChanged();
  }
  const resizeObserver = new ResizeObserver(resize); resizeObserver.observe(container);

  const raycaster = new THREE.Raycaster(), pointer = new THREE.Vector2();
  raycaster.params.Line.threshold = 2.5 * physicalScale;
  raycaster.params.Points.threshold = 2.5 * physicalScale;
  let pointerDown = null;
  function onPointerDown(e) { if (e.button === 0) pointerDown = { x: e.clientX, y: e.clientY, time: performance.now() }; }
  function pick(e, onlyAssets = false) {
    const rect = renderer.domElement.getBoundingClientRect();
    pointer.set((e.clientX - rect.left) / rect.width * 2 - 1, -(e.clientY - rect.top) / rect.height * 2 + 1);
    const unitsPerPixel = (camera.top - camera.bottom) / camera.zoom / height;
    const hitTolerance = Math.max(0.01 * physicalScale, unitsPerPixel * 5);
    raycaster.params.Line.threshold = hitTolerance; raycaster.params.Points.threshold = hitTolerance;
    raycaster.setFromCamera(pointer, camera);
    const visible = pickable.filter(object => {
      if (onlyAssets && !object.userData.assets && !object.userData.segmentAssets) return false;
      if (object.userData.transformerSymbol) return layers.transformers.visible;
      if (object.userData.meterSymbol) return layers.servicePoints.visible;
      return object.userData.network ? layers.network.visible : layers.outages.visible && object.parent.visible;
    });
    const hits = raycaster.intersectObjects(visible.filter(object => !object.userData.meterSymbol && !object.userData.transformerSymbol), false);
    const meters = [];
    for (const object of visible.filter(object => object.userData.meterSymbol || object.userData.transformerSymbol)) {
      // Match the visible M circle at every zoom, including its outer ring.
      raycaster.params.Points.threshold = unitsPerPixel * object.material.size / 2;
      raycaster.intersectObject(object, false, meters);
    }
    // Meter symbols are drawn above the network. Resolve crowded symbols by
    // screen proximity instead of the distance from the camera to the ground.
    meters.sort((a, b) => a.distanceToRay - b.distanceToRay || a.distance - b.distance);
    return [...meters, ...hits];
  }
  function hitAsset(hit) {
    const data = hit.object.userData;
    return data.assets?.[hit.instanceId ?? hit.index] ?? data.segmentAssets?.[Math.floor(hit.index / 2)];
  }
  function showHit(hits, e) {
    // Buses share endpoints with lines. Prefer their explicit point symbol
    // within the pick tolerance so its results remain reachable at junctions.
    const hit = hits.find(h => hitAsset(h)?.kind === 'transformer') || hits.find(h => hitAsset(h)?.kind === 'service-point') || hits.find(h => hitAsset(h)?.kind === 'bus') || hits.find(h => hitAsset(h));
    if (!hit) { clearHover(); return; }
    const rect = renderer.domElement.getBoundingClientRect();
    hovering = true;
    onAssetHover({ asset: hitAsset(hit), x: e.clientX - rect.left, y: e.clientY - rect.top });
  }
  let lastHover = 0;
  function onPointerMove(e) {
    if (e.buttons || transition || e.pointerType === 'touch' || performance.now() - lastHover < 90) return;
    lastHover = performance.now();
    showHit(pick(e, true), e);
  }
  function onPointerLeave() { pointerDown = null; clearHover(); }
  function onPointerUp(e) {
    if (!pointerDown || e.button !== 0) return;
    const moved = Math.hypot(e.clientX - pointerDown.x, e.clientY - pointerDown.y);
    const elapsed = performance.now() - pointerDown.time; pointerDown = null;
    if (moved > 6 || elapsed > 550 || (!layers.outages.visible && !layers.network.visible && !layers.servicePoints.visible && !layers.transformers.visible)) return;
    const hits = pick(e);
    const asset=hits[0]&&hitAsset(hits[0]);
    if (asset?.kind==='transformer') onTransformerSelect(asset);
    else if (asset?.kind==='service-point'&&transformerById.has(asset.transformerId)) onTransformerSelect(transformerById.get(asset.transformerId));
    else if (hits[0]?.object.userData.outageCell) onOutageSelect(hits[0].object.userData.outageCell);
    else if (hits[0]) {
      const hit = hits.find(h => hitAsset(h)?.kind === 'bus') || hits.find(h => ['line','switch'].includes(hitAsset(h)?.kind)) || hits[0], data = hit.object.userData;
      const pickedAsset = hitAsset(hit);
      const id = pickedAsset?.circuit ?? data.circuitId ?? data.circuitIds?.[hit.instanceId ?? hit.index];
      if (id) onSelect(id, {asset:pickedAsset, point:selectedNetworkPoint(pickedAsset, hit.point)});
    }
    showHit(hits, e);
  }
  function onKeyDown(e) {
    if (e.target !== renderer.domElement) return;
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) {
      e.preventDefault();
      stopTour(true); transition = null;
      const step = keyboardPanDistance(camera, height);
      const offset = new THREE.Vector3(e.key === 'ArrowLeft' ? -step : e.key === 'ArrowRight' ? step : 0, 0, e.key === 'ArrowUp' ? -step : e.key === 'ArrowDown' ? step : 0);
      controls.target.add(offset); camera.position.add(offset); controls.update(); cameraChanged(); updateNavigationContext();
    } else if (e.key === '+' || e.key === '=') api.zoom(1);
    else if (e.key === '-') api.zoom(-1);
    else if (e.key.toLowerCase() === 'r') api.reset();
  }
  renderer.domElement.addEventListener('pointerdown', onPointerDown);
  renderer.domElement.addEventListener('pointerup', onPointerUp);
  renderer.domElement.addEventListener('pointermove', onPointerMove);
  renderer.domElement.addEventListener('pointerleave', onPointerLeave);
  renderer.domElement.addEventListener('keydown', onKeyDown);

  function moveTo(position, target, zoom = camera.zoom) {
    pendingContext = false;
    if (reducedMotion) {
      camera.position.copy(position); controls.target.copy(target); camera.zoom = zoom; camera.updateProjectionMatrix(); controls.update(); cameraChanged(); return;
    }
    transition = { start: performance.now(), fromPosition: camera.position.clone(), fromTarget: controls.target.clone(), fromZoom: camera.zoom, position, target, zoom };
    needsRender = true;
  }
  function flyToOutage(stop) {
    const target = new THREE.Vector3(stop.x, 0, stop.z);
    const direction = camera.position.clone().sub(controls.target).normalize();
    const zoom = outageTourZoom(initialExtent, physicalScale);
    const distance = controls.target.distanceTo(target);
    const broadZoom = THREE.MathUtils.clamp(initialExtent / Math.max(initialExtent * 2, distance * 1.25), controls.minZoom, Math.min(0.5, camera.zoom, zoom));
    transition = { flight: true, start: performance.now(), duration: OUTAGE_FLIGHT_MS, fromTarget: controls.target.clone(), target,
      fromZoom: camera.zoom, broadZoom, zoom, direction };
    pendingContext = false;
    if (stop.circuit) onContextChange(stop.circuit);
    onTourStop({ ...stop, index: tour.index + 1, total: tour.stops.length });
    needsRender = true;
  }
  let lastPulse = -1;
  function animate() {
    if (disposed) return;
    animationFrame = requestAnimationFrame(animate);
    const now = performance.now();
    const dt = previousFrame ? Math.min((now - previousFrame) / 1000, 1) : 0;
    previousFrame = now;
    if (document.hidden || !inViewport) return;
    if (transition) {
      const t = Math.min(1, (now - transition.start) / (transition.duration || 700));
      const ease = t * t * (3 - 2 * t);
      if (transition.flight) {
        const smooth = v => { const n = THREE.MathUtils.clamp(v, 0, 1); return n * n * (3 - 2 * n); };
        controls.target.lerpVectors(transition.fromTarget, transition.target, smooth((t - 0.28) / 0.44));
        camera.zoom = t < 0.28 ? THREE.MathUtils.lerp(transition.fromZoom, transition.broadZoom, smooth(t / 0.28))
          : t > 0.72 ? THREE.MathUtils.lerp(transition.broadZoom, transition.zoom, smooth((t - 0.72) / 0.28)) : transition.broadZoom;
        const distance = (view === '2d' ? 600 : initialPosition.distanceTo(initialTarget)) / Math.min(1, camera.zoom);
        camera.position.copy(controls.target).addScaledVector(transition.direction, distance);
      } else {
        camera.position.lerpVectors(transition.fromPosition, transition.position, ease);
        controls.target.lerpVectors(transition.fromTarget, transition.target, ease);
        camera.zoom = THREE.MathUtils.lerp(transition.fromZoom, transition.zoom, ease);
      }
      camera.updateProjectionMatrix();
      if (t === 1) transition = null;
      needsRender = true;
    }
    const cameraMoving = controls.update();
    if (cameraMoving || transition || interacting) lastMotion = now;
    updateResolution(interacting || Boolean(transition) || now - lastMotion < 160);
    if (pendingContext && !cameraMoving && !transition) { pendingContext = false; updateNavigationContext(); }
    const pulse = Math.floor(clock.getElapsedTime() * 24);
    if (flowObject && layers.network.visible && !reducedMotion) { updateParticles(Math.min(dt, 0.1)); needsRender = true; }
    if (layers.outages.visible && !reducedMotion && pulse !== lastPulse) {
      lastPulse = pulse;
      const state = selectionStates.get(selectedId);
      if (state) {
        const wave = (Math.sin(pulse / 11) + 1) / 2;
        state.beacon.material.opacity = 0.65 + 0.35 * wave;
        state.ring.scale.setScalar(1 + wave * 0.13);
      }
      needsRender = true;
    }
    if (needsRender) {
      renderer.render(scene, camera); needsRender = false;
      if (import.meta.env.DEV) {
        renderer.domElement.dataset.renderFrames = String(++renderedFrames);
        renderer.domElement.dataset.drawCalls = String(renderer.info.render.calls);
        renderer.domElement.dataset.pixelRatio = String(renderer.getPixelRatio());
      }
    }
  }

  const api = {
    setTheme(value) {
      const light = value === 'light';
      const background = light ? '#e5edf0' : PALETTE.ink;
      renderer.setClearColor(background); scene.background.set(background); scene.fog.color.set(background);
      base.material.color.set(light ? '#dbe5ea' : PALETTE.ground);
      for (const entry of themeMaterials) {
        for (const [key, next] of Object.entries(light ? entry.light : entry.dark)) {
          if (entry.material[key]?.isColor) entry.material[key].set(next);
          else entry.material[key] = next;
        }
      }
      needsRender = true;
    },
    setPowerFlow(index) {
      clearFlow(); onAssetHover(null);
      particlePaths = flowPaths(topology?.lines || [], index, physicalScale);
      if (!particlePaths.length) { needsRender = true; return; }
      // One GPU batch, bounded particle density, no per-line animation timers.
      const count = particlePaths.reduce((sum, path) => sum + path.count * 3, 0);
      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(count * 3), 3).setUsage(THREE.DynamicDrawUsage));
      const colors = new Float32Array(count * 3);
      for (let i = 0; i < count; i++) new THREE.Color(['#efffff', '#77efe9', '#238dba'][i % 3]).toArray(colors, i * 3);
      geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
      flowObject = new THREE.Points(geometry, new THREE.PointsMaterial({ vertexColors: true, size: 7, sizeAttenuation: false,
        map: dotTexture, transparent: true, opacity: 0.95, depthWrite: false, blending: THREE.AdditiveBlending }));
      flowObject.name = 'converged-power-flow'; flowObject.frustumCulled = false;
      layers.network.add(flowObject); particleTime = 0; updateParticles();
    },
    startOutageTour(stops) {
      tour = { ...createOutageTourClock(stops, progress), playing: !reducedMotion, interrupted: false };
    },
    advanceReplay(elapsedMs, speed) {
      if (!tour?.playing || reducedMotion) return Math.min(1, progress + elapsedMs / 60000 * speed);
      const step = advanceOutageTour(tour, progress, elapsedMs, speed, Boolean(transition));
      if (step.stop) flyToOutage(step.stop);
      return step.progress;
    },
    resumeOutageTour() {
      if (tour && !reducedMotion) {
        tour.playing = true; tour.interrupted = false;
        if (tour.pausedTransition) {
          transition = { ...tour.pausedTransition, start: performance.now() - tour.pausedTransition.elapsed };
          tour.pausedTransition = null;
        }
      }
    },
    pauseOutageTour() { stopTour(); },
    clearOutageTour() { stopTour(); tour = null; },
    setLayer(name, visible) {
      if (!layers[name]) return;
      layers[name].visible = Boolean(visible);
      if (!visible) onAssetHover(null);
      if (name === 'network') updateOutages();
      needsRender = true;
    },
    setView(nextView) {
      stopTour(true);
      view = nextView === '2d' ? '2d' : '3d';
      controls.enableRotate = view === '3d';
      const target = controls.target.clone();
      const position = view === '2d' ? target.clone().add(new THREE.Vector3(0, 600, 0.1)) : target.clone().add(new THREE.Vector3(310, 330, 398).multiplyScalar(initialExtent / 360));
      moveTo(position, target);
    },
    zoom(direction) {
      stopTour(true); transition = null;
      camera.zoom = THREE.MathUtils.clamp(camera.zoom * (direction > 0 ? 1.18 : 1 / 1.18), controls.minZoom, controls.maxZoom);
      camera.updateProjectionMatrix(); cameraChanged();
    },
    reset() {
      stopTour(true);
      view = '3d'; controls.enableRotate = true;
      const id = topology && nearestCircuit(topology.lines, initialTarget, selectedId);
      if (id) onContextChange(id);
      moveTo(initialPosition.clone(), initialTarget.clone(), 1);
    },
    selectTransformer(id) {
      const t=transformerById.get(id); if (!t || !transformerSelection) return;
      transformerSelection.position.set(t.x,0,t.z);transformerSelection.visible=true;needsRender=true;
    },
    focusTransformer(id) {
      const t=transformerById.get(id);if(!t)return;
      api.selectTransformer(id);stopTour(true);
      const target=new THREE.Vector3(t.x,0,t.z),direction=camera.position.clone().sub(controls.target);
      moveTo(target.clone().add(direction),target,Math.max(camera.zoom,1.8));
    },
    focusCircuit(id) {
      stopTour(true);
      const state = selectionStates.get(id); if (!state) return;
      api.selectCircuit(id);
      // Use the pending view direction so an initial 2D transition is not
      // overwritten by fitting. Fit actual geometry, which may be asymmetric
      // around the substation or span many kilometers.
      const direction = transition?.position
        ? transition.position.clone().sub(transition.target)
        : camera.position.clone().sub(controls.target);
      const points = (topology?.lines || []).filter(line => line.circuit === id)
        .flatMap(line => line.points.map(([x, z]) => new THREE.Vector3(x, 0, z)));
      if (!points.length) {
        const target = state.group.position.clone();
        moveTo(target.clone().add(direction), target, Math.max(camera.zoom, 1.2));
        return;
      }
      const target = new THREE.Box3().setFromPoints(points).getCenter(new THREE.Vector3());
      const fittedCamera = camera.clone();
      fittedCamera.position.copy(target).add(direction);
      fittedCamera.lookAt(target); fittedCamera.updateMatrixWorld(true);
      const bounds = new THREE.Box3().setFromPoints(points.map(point => point.applyMatrix4(fittedCamera.matrixWorldInverse)));
      const size = bounds.getSize(new THREE.Vector3());
      const zoom = THREE.MathUtils.clamp(Math.min(
        (camera.right - camera.left) / Math.max(1, size.x * 1.15),
        (camera.top - camera.bottom) / Math.max(1, size.y * 1.15)
      ), controls.minZoom, controls.maxZoom);
      moveTo(target.clone().add(direction), target, zoom);
    },
    selectCircuit(id) { if (!selectionStates.has(id)) return; selectedId = id; updateOutages(); cameraChanged(); },
    setProgress(value) { progress = THREE.MathUtils.clamp(Number(value) || 0, 0, 1); updateOutages(); },
    setHeightScale(value) { heightScale = THREE.MathUtils.clamp(Number(value) || 1, 1, 8); updateOutages(); },
    setScenario(value) { scenario = ['baseline', 'storm', 'restoration'].includes(value) ? value : 'baseline'; updateOutages(); },
    setQuality(value) {
      quality = value === 'low' ? 'low' : 'high';
      const high = quality === 'high';
      updateResolution(interacting);
      roofObject.visible = high; resize();
    },
    setReducedMotion(value) { reducedMotion = Boolean(value); controls.enableDamping = !reducedMotion; if (reducedMotion) { stopTour(); transition = null; } needsRender = true; },
    getCamera() { return { position: camera.position.toArray(), target: controls.target.toArray(), zoom: camera.zoom, view }; },
    restoreCamera(saved) {
      if (!saved || !Array.isArray(saved.position) || !Array.isArray(saved.target) || saved.position.length !== 3 || saved.target.length !== 3 || ![...saved.position, ...saved.target].every(Number.isFinite)) return;
      pendingContext = false; transition = null; camera.position.fromArray(saved.position); controls.target.fromArray(saved.target);
      stopTour(true);
      camera.zoom = THREE.MathUtils.clamp(Number(saved.zoom) || 1, controls.minZoom, controls.maxZoom);
      view = saved.view === '2d' ? '2d' : '3d'; controls.enableRotate = view === '3d';
      camera.updateProjectionMatrix(); controls.update(); cameraChanged();
    },
    dispose() {
      disposed = true; cancelAnimationFrame(animationFrame); resizeObserver.disconnect(); visibilityObserver.disconnect(); controls.dispose();
      renderer.domElement.removeEventListener('pointerdown', onPointerDown); renderer.domElement.removeEventListener('pointerup', onPointerUp); renderer.domElement.removeEventListener('keydown', onKeyDown);
      renderer.domElement.removeEventListener('pointermove', onPointerMove); renderer.domElement.removeEventListener('pointerleave', onPointerLeave);
      const geometries = new Set(), materials = new Set(), textures = new Set();
      scene.traverse((object) => {
        if (object.geometry) geometries.add(object.geometry);
        for (const material of Array.isArray(object.material) ? object.material : object.material ? [object.material] : []) {
          materials.add(material); if (material.map) textures.add(material.map);
        }
      });
      geometries.forEach((g) => g.dispose()); materials.forEach((m) => m.dispose()); textures.forEach((t) => t.dispose());
      renderer.dispose(); renderer.domElement.remove();
    },
  };
  updateOutages(); resize(); animate();
  requestAnimationFrame(() => { if (!disposed) { cameraChanged(); onReady(); } });
  return api;
}
