import test from 'node:test';
import assert from 'node:assert/strict';
import {DEFAULTS,NORMAL_LIFE_HOURS,steady,thermal,oilTimeConstant,thermalSummary,addSession,evProfile,windingLoad,analyzeTransformer,validate} from './transformer-analysis.js';
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);
const tx=(p=40,kva=50)=>({id:'test',inService:true,ratedKva:kva,windings:[{side:'primary',ratedKva:kva,pKw:p,qKvar:0},{side:'secondary',ratedKva:kva/2,pKw:-p/2,qKvar:0},{side:'secondary',ratedKva:kva/2,pKw:-p/2,qKvar:0}]});
test('steady state matches supplied Python and C57.91 rated temperatures',()=>{
 for(const [k,oil,hot] of [[0,43.11721657679817,43.11721657679817],[.5,55.09502910309473,63.34195354542532],[1,85,110],[1.2,100.6143183387,134.08233699059483]]){const actual=steady(k);near(actual.oil,oil);near(actual.hot,hot)}
 near(thermal([1],[30]).aging[0],1);
});
test('top oil follows the C57.91 load-dependent time constant when heating and cooling',()=>{
 const load=[.5,.5,1.5,1.5,1.5,1.5,1.5,1.5,.5,.5,.5],s=thermal(load,load.map(()=>30));
 const expected=[55.0950291031,55.0950291031,62.3440001225,68.9778967681,75.0192840945,80.4997845141,85.4557678145,89.9256666020,86.7014983021,83.8008462605,81.1875384226];s.oil.forEach((v,i)=>near(v,expected[i]));
 const i=steady(.5,DEFAULTS,0).oil,u=steady(1.5,DEFAULTS,0).oil,r=DEFAULTS.oilRise,tau=DEFAULTS.oilTau*(u/r-i/r)/((u/r)**1.25-(i/r)**1.25);
 near(s.oil[2],30+u+(i-u)*Math.exp(-15/tau));assert.ok(tau<DEFAULTS.oilTau);
 near(oilTimeConstant(0,r),DEFAULTS.oilTau);assert.ok(Math.abs(oilTimeConstant(40,40.01)/oilTimeConstant(40.005,40.005)-1)<1e-7);
 const linear={...DEFAULTS,n:1};near(oilTimeConstant(20,90,linear),DEFAULTS.oilTau);near(oilTimeConstant(90,20,linear),DEFAULTS.oilTau);
});
test('loss of life integrates equivalent aging over the study period against 180,000 h',()=>{
 const s=thermalSummary({oil:[85,85],hot:[110,110],aging:[1,3]},DEFAULTS);near(s.feqa,2);near(s.lossOfLifeHours,1);near(s.lossOfLifePct,100/NORMAL_LIFE_HOURS);
 const rated=analyzeTransformer(tx(50),{...DEFAULTS,swing:0,scanLimit:1,arrivalSpread:0},0).baseline;near(rated.lossOfLifeHours,168);
});
test('fractional charging bins conserve the source example energy and cross midnight',()=>{const p=new Float64Array(192);addSession(p,18.1,10,7.2);near(p.reduce((s,v)=>s+v,0)*.25,10);[4.32,7.2,7.2,7.2,7.2,6.88].forEach((v,i)=>near(p[72+i],v));const late=new Float64Array(192);addSession(late,23.5,10,7.2);assert.ok(late[96]>0);near(late.reduce((s,v)=>s+v,0)*.25,10)});
test('signed winding demand preserves center taps, reactive power and a hot phase',()=>{near(windingLoad(tx(),1,10),1);near(windingLoad(tx(-40),1,10),.6);const unbalanced=tx();unbalanced.windings[1].pKw=-30;unbalanced.windings[2].pKw=-10;near(windingLoad(unbalanced,1,0),1.2);unbalanced.windings[1].qKvar=-40;near(windingLoad(unbalanced,1,0),2);});
test('hosting distinguishes baseline failure, zero capacity and a censored scan',()=>{const a={...DEFAULTS,swing:0,scanLimit:3,arrivalSpread:0};const failing=analyzeTransformer(tx(60),a,0);assert.equal(failing.uncontrolled.capacity,-1);const rated=analyzeTransformer(tx(50),a,0);assert.equal(rated.uncontrolled.capacity,0);near(rated.baseline.feqa,1);const idle=analyzeTransformer(tx(0,500),a,3);assert.equal(idle.delayed.capacity,3);assert.equal(idle.delayed.censored,true);assert.equal(idle.baseline.series.oil.length,672)});
test('changing scan bound preserves existing EV sessions and selected result',()=>{const a={...DEFAULTS,scanLimit:4};assert.deepEqual(evProfile(1,a,false),evProfile(1,{...a,scanLimit:9},false));const r1=analyzeTransformer(tx(),a,2),r2=analyzeTransformer(tx(),{...a,scanLimit:8},2);assert.deepEqual(r1.uncontrolled.selected,r2.uncontrolled.selected);assert.notDeepEqual(r1.uncontrolled.selected.series.evKw,r1.delayed.selected.series.evKw)});
test('invalid thermal inputs and overlapping per-vehicle sessions are explicit errors',()=>{assert.throws(()=>validate({...DEFAULTS,hotRise:50},tx()),/exceed/);assert.throws(()=>validate({...DEFAULTS,charger:NaN},tx()),/charger/);assert.throws(()=>evProfile(1,{...DEFAULTS,charger:1.4,energy:40},false),/overlap/)});
