import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { attachVirtualScenario } from '../virtual-di-agent.js';
import { selectOutageTour, DEFAULT_REPLAY_SPEED } from './outage-tour.js';
import { indexPowerFlow, assetResults, flowPaths, sampleFlowPath, networkBusLocations, totalResult, lineConductorOffsets } from './powerflow-display.js';

test('tour uses distinct high-impact areas, caps stops at four, and avoids derived double counting', () => {
  const events = [1, 2, 3, 4, 5, 6].map((n) => ({ id: String(n), assetId: String(n), type: 'servicePoint', x: n * 2000, z: 0, durationHours: n, start: 0, end: 1 }));
  events.push({ ...events[0], type: 'feeder', durationHours: 10000 });
  events.push({ ...events[1], id: 'extra', assetId: 'extra', x: 4010, durationHours: 20 });
  const stops = selectOutageTour(events, { maxStops: 50 });
  assert.equal(stops.length, 4);
  assert.equal(stops[0].customerHours, 22);
  assert.equal(stops[0].servicePoints, 2);
  assert.deepEqual(stops.map(s => s.customerHours), [22, 6, 5, 4]);
  assert.equal(selectOutageTour(events, { startProgress: 1 }).length, 0);
  assert.equal(selectOutageTour([{ ...events[0], x: null }]).length, 0);
  assert.equal(selectOutageTour([events[0]]).length, 1);
  assert.ok(DEFAULT_REPLAY_SPEED < 1);
});

test('SMARTDS tour has two to four separated areas and preserves the study', () => {
  const data = JSON.parse(readFileSync(new URL('../../public/data/smartds.json', import.meta.url)));
  attachVirtualScenario(data);
  const original = JSON.stringify(data.events);
  for (const startProgress of [0, 0.35]) {
    const stops = selectOutageTour(data.events, { startProgress });
    assert.ok(stops.length >= 2 && stops.length <= 4);
    for (const [i, s] of stops.entries()) {
      assert.ok(s.customerHours > 0 && s.servicePoints > 0);
      for (const other of stops.slice(i + 1)) assert.ok(Math.hypot(s.x - other.x, s.z - other.z) >= 1000);
    }
  }
  assert.equal(JSON.stringify(data.events), original);
});

const state = { status: 'success', circuit: { id: '13080' }, result: { solved: true, tables: {
  res_bus: [{ index: 426, phase: 1, vm_pu: 0.99 }, { index: 426, phase: 2, vm_pu: 1.01 }],
  res_line: [{ index: 0, circuit: 0, i_ka: 0.05, p_from_mw: -0.01, loading_percent: null }],
} } };
const line = { id: 'L-13080-0', circuit: '13080', fromBus: 'network_0/bus/426', toBus: 'network_0/bus/422', points: [[0, 0], [100, 0]], overhead: true };

test('overhead conductor layout follows the source span phases', () => {
  assert.deepEqual(lineConductorOffsets({ phases: 'A, B' }), [-1.5, 1.5]);
  assert.deepEqual(lineConductorOffsets({ phases: 'A' }), [0]);
  assert.deepEqual(lineConductorOffsets({ phases: '' }), [0]);
  assert.deepEqual(lineConductorOffsets({}, 'A · B · C'), [-1.5, 1.5]);
});

test('results require convergence and exact circuit/element identity, retaining missing ratings', () => {
  const index = indexPowerFlow(state);
  assert.equal(assetResults(index, { kind: 'bus', id: line.fromBus, circuit: '13080' }).length, 2);
  assert.equal(assetResults(index, { kind: 'bus', id: line.fromBus, circuit: '13081' }).length, 0);
  assert.equal(assetResults(index, { ...line, kind: 'line', id: 'L-13080-999' }).length, 0);
  assert.equal(assetResults(index, { ...line, kind: 'line' })[0].loading_percent, null);
  for (const status of ['idle', 'running', 'cancelled', 'error']) assert.equal(indexPowerFlow({ ...state, status }), null);
  assert.equal(indexPowerFlow({ ...state, result: { ...state.result, solved: false } }), null);
  assert.equal(totalResult([{ p: 1 }, { p: null }], 'p'), null);
});

test('particles follow solved line geometry, reverse power, and exclude unknown/zero flow', () => {
  const paths = flowPaths([line, { ...line, circuit: '13081' }], indexPowerFlow(state));
  assert.equal(paths.length, 1);
  assert.equal(paths[0].direction, -1);
  assert.equal(paths[0].points[0][1], 10.5);
  assert.ok(paths[0].points.some(p => p[1] < 10));
  const sample = sampleFlowPath(paths[0], paths[0].length / 2, []);
  assert.ok(Math.abs(sample[0] - 50) < 1e-8);
  assert.equal(sample[2], 0);
  assert.equal(flowPaths([line], null).length, 0);
  const zero = { ...state, result: { solved: true, tables: { res_line: [{ index: 0, i_ka: 0, p_from_mw: 0 }] } } };
  assert.equal(flowPaths([line], indexPowerFlow(zero)).length, 0);
  assert.equal(networkBusLocations([line, { ...line, circuit: '13081' }]).length, 4);
});
