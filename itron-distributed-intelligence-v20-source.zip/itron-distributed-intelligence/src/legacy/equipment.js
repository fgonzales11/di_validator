import * as THREE from 'three';
import { servicePointLocations } from './service-points.js';

const located = point => Number.isFinite(point.x) && Number.isFinite(point.z);

// Bus identities are scoped to a model, never inferred from nearby coordinates.
export function generatorConnections(transformers = [], generators = []) {
  const buses = new Map();
  for (const transformer of transformers) for (const bus of transformer.windingBuses || []) {
    if (!buses.has(bus)) buses.set(bus, []);
    buses.get(bus).push(transformer.id);
  }
  return generators.filter(located).map(generator => ({
    ...generator, padmountTransformerIds: buses.get(generator.bus) || [],
  }));
}

function glyphTexture(letter, fill, stroke, dashed = false) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 128;
  const ctx = canvas.getContext('2d');
  ctx.beginPath(); ctx.arc(64, 64, 57, 0, Math.PI * 2);
  ctx.fillStyle = fill; ctx.fill();
  ctx.lineWidth = 7; ctx.strokeStyle = stroke;
  if (dashed) ctx.setLineDash([10, 7]);
  ctx.stroke();
  ctx.font = 'bold 75px Arial, sans-serif';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillStyle = '#f3fff9'; ctx.fillText(letter, 64, 68);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

// Solid circles indicate recorded coordinates; broken rings indicate the
// individual inventory meters arranged schematically at their transformer.
export function meterMarkers(locations = [], scale = 1, pickable = []) {
  const group = new THREE.Group(); group.name = 'service-point-meters';
  for (const [basis, points] of Object.entries(servicePointLocations(locations, scale))) {
    const schematic = basis === 'schematic';
    const colored = points.some(p => p.groupColor);
    const geometry = new THREE.BufferGeometry();
    if (colored) geometry.setAttribute('color', new THREE.Float32BufferAttribute(points.flatMap(p => new THREE.Color(p.groupColor || '#94a5ad').toArray()), 3));
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(points.flatMap(p => [p.x, 0.65 * scale, p.z]), 3));
    const mesh = new THREE.Points(geometry, new THREE.PointsMaterial({
      map: glyphTexture('M', colored ? '#253038' : schematic ? '#193342' : '#163e44', colored ? '#ffffff' : schematic ? '#87a6b8' : '#a6dfd0', schematic), vertexColors: colored,
      size: 18, sizeAttenuation: false, transparent: true, alphaTest: 0.1, depthTest: false, depthWrite: false,
    }));
    mesh.name = `service-point-${basis}`; mesh.renderOrder = 8;
    mesh.userData = {
      meterSymbol: true,
      assets: points.map(point => ({ ...point, kind: 'service-point' })),
      circuitIds: points.map(point => point.circuit),
    };
    group.add(mesh); pickable.push(mesh);
  }
  return group;
}

export function addNetworkEquipment({ topology, parent, pickable, scale = 1 }) {
  const transformers = (topology.transformers || []).filter(t => t.mounting === 'padmount' && located(t));
  const dummy = new THREE.Object3D();
  function instances(name, geometry, material, locations, position, dimensions, flat = false) {
    const mesh = new THREE.InstancedMesh(geometry, material, locations.length);
    locations.forEach((item, index) => {
      dummy.position.set(...position(item).map(n => n * scale));
      // Source x/z coordinates are already in world units.
      dummy.position.x += item.x; dummy.position.z += item.z;
      dummy.rotation.set(flat ? -Math.PI / 2 : 0, 0, 0);
      dummy.scale.set(...dimensions.map(n => n * scale));
      dummy.updateMatrix(); mesh.setMatrixAt(index, dummy.matrix);
      if(item.groupColor) mesh.setColorAt(index,new THREE.Color(item.groupColor));
    });
    mesh.computeBoundingSphere(); mesh.name = name;
    mesh.userData = { network: true, circuitIds: locations.map(item => item.circuit), ...(locations.some(t=>t.groupColor)?{assets:locations.map(t=>({...t,kind:'transformer'}))}:{}) };
    parent.add(mesh); pickable.push(mesh);
    return mesh;
  }

  if (transformers.length) {
    // Schematic display dimensions keep the cabinet visible beside the network.
    // These are symbols at real bus positions, not surveyed equipment envelopes.
    const box = new THREE.BoxGeometry(1, 1, 1);
    const colored = transformers.some(t=>t.groupColor);
    const green = colored ? new THREE.MeshBasicMaterial({color:'#ffffff'}) : new THREE.MeshStandardMaterial({ color: '#365d32', roughness: 0.8, metalness: 0.12 });
    const darkGreen = colored ? new THREE.MeshBasicMaterial({color:'#c4c4c4'}) : new THREE.MeshStandardMaterial({ color: '#284c25', roughness: 0.78, metalness: 0.15 });
    instances('padmount-concrete-pads', box, new THREE.MeshStandardMaterial({ color: '#61736b', roughness: 1 }), transformers, () => [0, 0.25, 0], [6.7, 0.5, 5.7]);
    instances('padmount-cabinets', box, green, transformers, () => [0, 2.5, 0], [5.8, 4, 4.8]);
    const roof = new THREE.BoxGeometry(1, 1, 1);
    const positions = roof.attributes.position;
    for (let i = 0; i < positions.count; i++) {
      if (positions.getY(i) > 0) positions.setY(i, positions.getY(i) + (0.5 - positions.getZ(i)) * 0.65);
    }
    roof.computeVertexNormals();
    instances('padmount-sloped-lids', roof, darkGreen, transformers, () => [0, 4.58, 0], [6, 0.65, 5]);
    instances('padmount-left-handles', box, new THREE.MeshBasicMaterial({ color: '#adc0a2' }), transformers, () => [-0.32, 2.65, 2.44], [0.13, 0.55, 0.13]);
    instances('padmount-right-handles', box, new THREE.MeshBasicMaterial({ color: '#adc0a2' }), transformers, () => [0.32, 2.65, 2.44], [0.13, 0.55, 0.13]);
    const seams = [];
    for (const t of transformers) {
      for (const [a, b] of [
        [[0, 0.65, 2.43], [0, 4.42, 2.43]],
        [[-2.72, 0.65, 2.43], [2.72, 0.65, 2.43]],
        [[-2.72, 4.42, 2.43], [2.72, 4.42, 2.43]],
        [[-2.72, 0.65, 2.43], [-2.72, 4.42, 2.43]],
        [[2.72, 0.65, 2.43], [2.72, 4.42, 2.43]],
      ]) for (const p of [a, b]) seams.push(t.x + p[0] * scale, p[1] * scale, t.z + p[2] * scale);
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(seams, 3));
    const doors = new THREE.LineSegments(geometry, new THREE.LineBasicMaterial({ color: '#182d22' }));
    doors.name = 'padmount-door-seams'; parent.add(doors);
  }

  const overhead=(topology.transformers||[]).filter(t=>t.mounting==='overhead'&&t.groupColor&&located(t));
  if(overhead.length){
    const material=new THREE.MeshBasicMaterial({color:'#ffffff'}),box=new THREE.BoxGeometry(1,1,1);
    instances('transformer-poles',new THREE.CylinderGeometry(.34,.44,1,8),material,overhead,()=>[0,5.5,0],[1,11,1]);
    instances('transformer-crossarms',box,material,overhead,()=>[0,10.1,0],[4.4,.25,.3]);
    instances('pole-transformer-cans',new THREE.CylinderGeometry(1,1,1,12),material,overhead,()=>[1.05,8.2,0],[.75,2.2,.75]);
    instances('pole-transformer-lids',new THREE.CylinderGeometry(1,1,1,12),new THREE.MeshBasicMaterial({color:'#c4c4c4'}),overhead,()=>[1.05,9.38,0],[.83,.16,.83]);
  }

  // The source does not specify mounting. Use neutral symbols without inventing equipment construction.
  for(const regulator of [false,true]) {
    const items=(topology.transformers||[]).filter(t=>located(t)&&!['padmount','overhead'].includes(t.mounting)&&Boolean(t.isRegulator)===regulator);
    if(!items.length)continue;
    const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(items.flatMap(t=>[t.x,1.2*scale,t.z]),3));
    const markers=new THREE.Points(geometry,new THREE.PointsMaterial({map:glyphTexture(regulator?'R':'T',regulator?'#746136':'#355866',regulator?'#e0c47c':'#a8d5e3'),size:regulator?16:12,sizeAttenuation:false,transparent:true,alphaTest:.1,depthTest:false,depthWrite:false}));
    markers.name=regulator?'model-regulators':'model-transformers-unknown-mounting';markers.renderOrder=7;markers.userData={network:true,circuitIds:items.map(t=>t.circuit),assets:items.map(t=>({...t,kind:'transformer'}))};parent.add(markers);pickable.push(markers);
  }
  const generators = generatorConnections(transformers, topology.generators);
  if (generators.length) {
    // Offset only the schematic symbol; its lead terminates at the exact bus.
    const offset = [13, 0.8, 5];
    const material = new THREE.MeshBasicMaterial({
      map: glyphTexture('G', '#6947a5', '#d0b3ff'), transparent: true,
      alphaTest: 0.1, depthWrite: false, depthTest: false, side: THREE.DoubleSide,
    });
    const markers = instances('generator-ground-markers', new THREE.PlaneGeometry(1, 1), material, generators, () => offset, [12, 12, 1], true);
    markers.renderOrder = 7;
    const leads = [];
    for (const g of generators) leads.push(g.x, 0.7 * scale, g.z, g.x + offset[0] * scale, 0.7 * scale, g.z + offset[2] * scale);
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(leads, 3));
    const lines = new THREE.LineSegments(geometry, new THREE.LineBasicMaterial({ color: '#b391e3', transparent: true, opacity: 0.95, depthTest: false, depthWrite: false }));
    lines.name = 'generator-bus-connections'; lines.renderOrder = 6; parent.add(lines);
  }
}
