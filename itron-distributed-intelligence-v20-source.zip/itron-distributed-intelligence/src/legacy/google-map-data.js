import {createAssetLocationResolver, geographicLocation} from './street-view.js';

export const googlePosition = location => location && Number.isFinite(location.lat) && Number.isFinite(location.lon) && Math.abs(location.lat)<=90 && Math.abs(location.lon)<=180
  ? {lat:location.lat, lng:location.lon, altitude:0} : null;

export function googleNetworkData(study, topology) {
  const locate=createAssetLocationResolver(study);
  const buses=new Map(study.topology.buses.map(bus=>[bus.id,bus]));
  const markers=assets=>assets.map(asset=>({asset,position:googlePosition(locate(asset))})).filter(item=>item.position);
  const lines=[...(topology.lines||[]),...(topology.switches||[])].map(asset=>{
    const path=(asset.points||[]).map(([x,z])=>googlePosition(geographicLocation({x,z},study.origin,study.worldUnitsPerMeter||1)));
    for(const [key,index] of [['fromBus',0],['toBus',path.length-1]]){
      const bus=buses.get(asset[key]);
      if(path.length && bus?.circuit===asset.circuit)path[index]=googlePosition(locate(bus));
    }
    return {asset,path};
  }).filter(line=>line.path.length>1&&line.path.every(Boolean));
  return {transformers:markers(topology.transformers||[]),servicePoints:markers(topology.servicePoints||[]),lines};
}

export function googleNetworkCamera(data, aspect=1.4) {
  const points=[...data.transformers.map(t=>t.position),...data.lines.flatMap(l=>l.path)];
  if(!points.length)return null;
  const south=Math.min(...points.map(p=>p.lat)),north=Math.max(...points.map(p=>p.lat));
  const west=Math.min(...points.map(p=>p.lng)),east=Math.max(...points.map(p=>p.lng));
  const lat=(south+north)/2, lng=(west+east)/2;
  const height=(north-south)*111320,width=(east-west)*111320*Math.cos(lat*Math.PI/180);
  return {center:{lat,lng,altitude:0},range:Math.max(450,Math.max(height,width/Math.max(.5,aspect))*2.8),heading:0,tilt:45};
}
