const located = p => Number.isFinite(p.x) && Number.isFinite(p.z);

export function servicePointSummary(points = []) {
  const counts = { total: points.length, recorded: 0, model: 0, schematic: 0, unlocated: 0, outsideStudy: 0, shown: 0 };
  for (const p of points) {
    if (p.locationBasis === 'outside-study') counts.outsideStudy++;
    else if (p.locationBasis === 'schematic' && located(p.anchor || {})) counts.schematic++;
    else if (p.locationBasis === 'recorded' && located(p)) counts.recorded++;
    else if (p.locationBasis === 'model' && located(p)) counts.model++;
    else counts.unlocated++;
  }
  counts.shown = counts.recorded + counts.model + counts.schematic;
  return counts;
}

// One symbol per inventory service point. Offsets form a schematic arrangement
// around an exactly matched transformer, never a claimed geographic location.
export function servicePointLocations(points = [], scale = 1) {
  const recorded = [], schematic = [], groups = new Map();
  for (const p of points) {
    if (!p.circuit) continue;
    if (['recorded','model'].includes(p.locationBasis) && located(p)) recorded.push(p);
    else if (p.locationBasis === 'schematic' && p.anchor?.transformerId && located(p.anchor)) {
      const key = `${p.circuit}:${p.anchor.transformerId}`;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(p);
    }
  }
  for (const group of groups.values()) {
    group.sort((a, b) => a.id.localeCompare(b.id));
    group.forEach((p, index) => {
      const angle = index * Math.PI * (3 - Math.sqrt(5));
      const radius = (14 + 8 * Math.sqrt(index)) * scale;
      schematic.push({ ...p, x: p.anchor.x + Math.cos(angle) * radius, z: p.anchor.z + Math.sin(angle) * radius });
    });
  }
  return { recorded, schematic };
}

export function mergeStudyInventory(base, study) {
  return { ...base, ...study, topology: { ...base.topology, ...study.topology,
    lines: base.topology.lines, transformers: base.topology.transformers,
    generators: base.topology.generators, servicePoints: base.topology.servicePoints,
  } };
}
