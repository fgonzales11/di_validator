// County registration shares inform scenarios, never observed transformer ownership.
export function adoptionScenario(linkedPoints, assumptions) {
  const {residentialPercent, vehiclesPerPremise, referencePercent, targetPercent}=assumptions;
  for (const [name,value,max] of [['Residential share',residentialPercent,100],['Vehicles per premise',vehiclesPerPremise,10],['Reference share',referencePercent,100],['Target share',targetPercent,100]]) {
    if (!Number.isFinite(value)||value<0||value>max) throw Error(`${name} must be between 0 and ${max}.`);
  }
  if (!Number.isInteger(linkedPoints)||linkedPoints<=0) return {available:false,reason:'No linked service-point count is available. Geographic context remains available.'};
  const vehiclePool=linkedPoints*residentialPercent/100*vehiclesPerPremise;
  const referenceVehicles=vehiclePool*referencePercent/100;
  const targetVehicles=vehiclePool*targetPercent/100;
  const additionalVehicles=vehiclePool*Math.max(0,targetPercent-referencePercent)/100;
  const studyCount=Math.ceil(Number(additionalVehicles.toFixed(10)));
  return {available:true,linkedServicePoints:linkedPoints,assumedVehiclePool:vehiclePool,referenceVehicles,targetVehicles,additionalVehicles,studyCount,exceedsStudyLimit:studyCount>200,assumptions:{...assumptions},basis:'One residential premise per assumed residential service point. County shares are reference assumptions, not measured transformer EV ownership. Only positive incremental adoption is added to the electrical baseline.'};
}

export function spatialContext(spatial, transformer) {
  const match=spatial.transformers[transformer.id];
  if (!match) return null;
  return {match,census:spatial.censusTracts.find(t=>t.id===match.censusTractId),affordability:spatial.affordabilityTracts.find(t=>t.id===match.affordabilityTractId),nearest:spatial.chargingSites.find(s=>s.id===match.nearestSiteId)};
}

export function stationStatus(site) {
  return site.status==='E'?'Available in inventory':site.status==='T'?'Temporarily unavailable in inventory':'Status uncertain';
}
