import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { generatorConnections } from './equipment.js';

test('generator connections require the same scoped winding bus, not nearby positions or bus numbers', () => {
  const transformers = [{ id: 'one/tx/1', windingBuses: ['one/bus/1', 'one/bus/2'] }];
  const generators = [
    { id: 'shared', bus: 'one/bus/2', x: 100, z: 200, transformerIds: ['one/tx/1'] },
    { id: 'nearby', bus: 'one/bus/3', x: 100, z: 200 },
    { id: 'other-model', bus: 'two/bus/2', x: 100, z: 200 },
  ];
  const result = generatorConnections(transformers, generators);
  assert.deepEqual(result.map(g => g.padmountTransformerIds), [['one/tx/1'], [], []]);
  assert.deepEqual(result[0].transformerIds, ['one/tx/1']);
  assert.equal(generators[0].padmountTransformerIds, undefined);
});

test('verified equipment covers every circuit and preserves exact bus links and modeled load groups', () => {
  const bytes = readFileSync(new URL('../../public/data/smartds.json', import.meta.url));
  const data = JSON.parse(bytes);
  const provenance = JSON.parse(readFileSync(new URL('../../public/data/provenance.json', import.meta.url)));
  const { transformers, generators, servicePoints } = data.topology;
  assert.equal(transformers.length, 1720);
  assert.equal(new Set(transformers.map(t => t.circuit)).size, 11);
  assert.equal(generators.length, 288);
  assert.equal(servicePoints.length, 6091);
  assert.equal(provenance.sources.length, 11);
  assert.equal(new Set([...transformers, ...generators].map(e => e.id)).size, 2008);
  assert.deepEqual(provenance.sources.map(s=>s.circuit).sort(), data.circuits.map(c=>c.id).sort());
  const circuits = new Set(data.circuits.map(c => c.id));
  for (const item of [...transformers, ...generators]) {
    assert.ok(circuits.has(item.circuit));
    assert.ok(Number.isFinite(item.x) && Number.isFinite(item.z));
  }
  for (const t of transformers) {
    assert.equal(t.mounting, 'unknown');
    assert.ok(t.windingBuses.includes(t.bus));
  }
  const linked = generatorConnections(transformers, generators);
  assert.equal(linked.filter(g => g.padmountTransformerIds.length).length, 0);
  for (let i = 0; i < linked.length; i++) assert.deepEqual(linked[i].padmountTransformerIds, generators[i].padmountTransformerIds);
});
