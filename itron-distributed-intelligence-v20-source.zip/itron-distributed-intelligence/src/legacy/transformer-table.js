// Fleet table filtering and sorting. `oil` maps a transformer to its steady top-oil estimate.
export const COLUMNS={
 id:{dir:1,value:t=>t.label},
 loading:{dir:-1,value:t=>t.maxWindingLoadingPct},
 voltage:{dir:1,value:t=>t.secondaryMinPu},
 oil:{dir:-1}
};
export const LOADING_FILTERS={all:()=>true,over100:v=>v>100,over150:v=>v>150,within:v=>v<=100};
export const VOLTAGE_FILTERS={all:()=>true,outside:t=>t.secondaryMinPu<.95||t.secondaryMaxPu>1.05,low:t=>t.secondaryMinPu<.95,high:t=>t.secondaryMaxPu>1.05,within:t=>t.secondaryMinPu>=.95&&t.secondaryMaxPu<=1.05};
export const OIL_FILTERS={all:()=>true,over:(v,limit)=>v>limit,within:(v,limit)=>v<=limit};
export function filterTransformers(transformers,{query='',circuit='',loading='all',voltage='all',oilFilter='all'}={},{oil,oilLimit}){
 const q=query.trim().toLowerCase(),byLoading=LOADING_FILTERS[loading]||LOADING_FILTERS.all,byVoltage=VOLTAGE_FILTERS[voltage]||VOLTAGE_FILTERS.all,byOil=OIL_FILTERS[oilFilter]||OIL_FILTERS.all;
 return transformers.filter(t=>(!circuit||t.circuit===circuit)&&(!q||`${t.label} ${t.circuit} ${t.substation} ${t.id}`.toLowerCase().includes(q))&&byLoading(t.maxWindingLoadingPct)&&byVoltage(t)&&(oilFilter==='all'||byOil(oil(t),oilLimit)));
}
export function sortTransformers(list,key,dir,oil){
 const value=key==='oil'?oil:(COLUMNS[key]||COLUMNS.loading).value;
 return list.sort((a,b)=>{const x=value(a),y=value(b);return (typeof x==='string'?x.localeCompare(y):x-y)*dir});
}
