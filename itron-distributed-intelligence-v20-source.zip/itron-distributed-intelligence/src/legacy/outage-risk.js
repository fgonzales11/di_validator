const HOUR=3600000;
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const riskScore=v=>Number.isFinite(v)?v.toFixed(2):'Unavailable';
export const riskTime=(v,short=false)=>Number.isFinite(Date.parse(v))?new Intl.DateTimeFormat('en-US',{timeZone:'UTC',month:short?undefined:'short',day:short?undefined:'numeric',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(v)):'—';
export function isCurrentRisk(data,now=Date.now()){
  const start=Math.ceil(now/HOUR)*HOUR,issued=Date.parse(data?.issuedAt),weather=Date.parse(data?.weatherRetrievedAt);
  return data?.schemaVersion===1&&Date.parse(data.windowStart)===start&&Date.parse(data.windowEnd)===start+24*HOUR&&issued<=now&&weather<=issued&&now-weather<=HOUR;
}
export function summarizeRisk(feeder,current=true){
  const hours=Array.isArray(feeder?.hours)?feeder.hours:[],valid=current?hours.filter(h=>Number.isFinite(h.score)&&h.score>=0&&h.score<=100):[];
  const peak=valid.reduce((a,h)=>!a||h.score>a.score?h:a,null);
  return {count:valid.length,peak:valid.length===24?peak?.score:null,peakAt:valid.length===24?peak?.start:null,partial:valid.length>0&&valid.length<24};
}
const reasons={missing_feeder_location:'Feeder location unavailable',missing_forecast_weather:'Forecast weather unavailable',county_outside_training_context:'County outside model training',stale_forecast:'Forecast needs updating',scored_transfer_proxy:'24 hourly scores available'};
export function needsRiskRefresh(data,now=Date.now()){
  return !data||!isCurrentRisk(data,now)||!!data.refreshNotice||data.feeders.some(f=>f.hours.some(h=>h.status==='missing_forecast_weather'));
}
export function riskWeatherNotice(data){
  if(data?.weatherSource?.reducedInputs)return 'Using National Weather Service backup with a reduced-input model. Rainfall and pressure are excluded.';
  if(data?.weatherStatus?.failures?.some(f=>f.status===429))return 'The primary weather provider has reached its request limit, and backup weather is currently incomplete. The forecast will retry automatically.';
  if(data?.weatherStatus?.receivedLocations===0)return 'Weather forecasts could not be retrieved. The forecast will retry automatically.';
  return '';
}
export function createOutageRisk({isOpen,getCircuits,onSelect}){
  let data=null,error='',loading=false,query='',scope='mapped',active=null,container=null,lastAttemptAt=0;
  const rows=()=>{
    const list=[...(data?.feeders||[])],known=new Set(list.map(f=>f.id));
    for(const c of getCircuits())if(!known.has(String(c.id)))list.push({id:String(c.id),name:c.name,onMap:true,hours:[],locationConfidence:'unavailable'});
    const current=isCurrentRisk(data);
    return list.filter(f=>(scope!=='mapped'||f.onMap)&&(scope!=='unavailable'||summarizeRisk(f,current).count<24)&&`${f.name} ${f.id} ${f.county||''}`.toLowerCase().includes(query.toLowerCase().trim())).sort((a,b)=>(summarizeRisk(b,current).peak??-1)-(summarizeRisk(a,current).peak??-1)||a.id.localeCompare(b.id));
  };
  function renderList(){
    if(!container)return;
    const list=rows(),current=isCurrentRisk(data),target=container.querySelector('#risk-feeders');if(!target)return;
    container.querySelector('#risk-result-count').textContent=`${list.length} feeders · highest score first`;
    target.innerHTML=list.map(f=>{const s=summarizeRisk(f,current);return `<button class="asset-result risk-row ${f.id===active?'is-selected':''}" data-risk-id="${esc(f.id)}" aria-pressed="${f.id===active}"><span><strong>${esc(f.name)} · ${esc(f.id)}</strong><small>${f.onMap?'Mapped feeder':'Outside displayed network'}${s.count<24?' · '+esc(current?(reasons[f.hours?.find(h=>h.status!=='scored_transfer_proxy')?.status]||'Score unavailable'):'Needs update'):''}</small></span><span class="risk-row-score">${riskScore(s.peak)}${s.peak!==null?'<small>/ 100</small>':''}</span></button>`}).join('')||'<div class="empty-state">No feeders match this filter.</div>';
  }
  function renderDetail(){
    const target=container?.querySelector('#risk-detail');if(!target)return;
    const f=data?.feeders.find(f=>f.id===active),current=isCurrentRisk(data);if(!f){target.innerHTML='';return;}
    const s=summarizeRisk(f,current),max=Math.max(1,...f.hours.map(h=>current&&Number.isFinite(h.score)?h.score:0)),scale=Math.ceil(max*100)/100;
    const chart=f.hours.map(h=>`<div class="risk-hour" title="${esc(riskTime(h.start))} UTC: ${current?riskScore(h.score):'Unavailable'}"><i style="height:${current&&Number.isFinite(h.score)?Math.max(1,h.score/scale*100):0}%"></i></div>`).join('');
    target.innerHTML=`<section class="risk-selected"><div class="panel-eyebrow">SELECTED FEEDER</div><h3>${esc(f.name)} · ${esc(f.id)}</h3><div class="risk-peak"><strong>${riskScore(s.peak)}</strong>${s.peak!==null?'<span>/ 100 peak hourly score</span>':''}</div><p>${s.peakAt?`Peak starts ${riskTime(s.peakAt)} UTC`:`${s.count} of 24 hours scored. A complete 24-hour score is unavailable.`}</p><div class="risk-hour-chart" role="img" aria-label="Hourly risk trend; chart scale 0 to ${scale} out of 100">${chart}</div><div class="risk-chart-axis"><span>${riskTime(data.windowStart,true)} UTC</span><span>Scale 0–${scale.toFixed(2)}</span><span>${riskTime(data.windowEnd,true)}</span></div><details class="risk-hour-details"><summary>View all 24 hourly scores</summary><table><thead><tr><th>Hour start · UTC</th><th>Score / 100</th><th>Gust · m/s</th></tr></thead><tbody>${f.hours.map(h=>`<tr><td>${riskTime(h.start)}</td><td>${current?riskScore(h.score):'Unavailable'}</td><td>${Number.isFinite(h.gustMps)?h.gustMps.toFixed(1):'—'}</td></tr>`).join('')}</tbody></table></details><p class="small-note">${esc(f.county||'County unavailable')} · ${f.locationConfidence==='sample_only'?'Location estimated from a sample of service points.':esc(f.locationConfidence||'Location unavailable')}${f.locationCoverage!=null?' Location coverage '+(f.locationCoverage*100).toFixed(1)+'%.':''}${f.hours.some(h=>h.outOfRange)?' Weather outside the training range; interpret with caution.':''}</p></section>`;
  }
  function render(body){
    container=body;
    if(!data){body.innerHTML=`<p class="drawer-lead">Weather-based feeder outlook for the next 24 complete hours.</p><div class="empty-state" role="status">${loading?'Loading the latest forecast…':esc(error||'Forecast not loaded.')}</div><button class="primary-button" id="risk-refresh" ${loading?'disabled':''}>${loading?'Loading…':'Retry forecast'}</button>`;body.querySelector('#risk-refresh').onclick=refresh;if(!loading&&!error)void refresh();return;}
    const current=isCurrentRisk(data),scored=data.feeders.filter(f=>summarizeRisk(f,current).count===24),mapped=data.feeders.filter(f=>f.onMap),model=data.model;
    if(!active)active=scored.filter(f=>f.onMap).sort((a,b)=>summarizeRisk(b).peak-summarizeRisk(a).peak)[0]?.id||data.feeders[0]?.id;
    body.innerHTML=`<p class="drawer-lead">Weather-based feeder outlook. Scores compare modeled weather risk; they are not calibrated probabilities of a feeder outage.</p><div class="risk-status ${current?'':'risk-unavailable'}" role="status"><span class="status-dot ${current?'aqua':'amber'}"></span>${current?'Current forecast':'Current forecast unavailable'}${loading?' · Updating…':''}</div>${error||data.refreshNotice||riskWeatherNotice(data)?`<p class="risk-message">${esc(error||data.refreshNotice||riskWeatherNotice(data))}</p>`:''}<div class="risk-window"><strong>${riskTime(data.windowStart)} → ${riskTime(data.windowEnd)} UTC</strong><span>24 complete hours · starts at the next hour boundary</span></div><div class="overview-grid"><div class="overview-metric"><strong>${scored.filter(f=>f.onMap).length} / ${mapped.length}</strong><span>Mapped feeders with 24-hour scores</span></div><div class="overview-metric"><strong>${scored.length} / ${data.feeders.length}</strong><span>SMARTDS inventory with 24-hour scores</span></div></div><div class="risk-model"><strong>${esc(model.label)}${model.fallback?' · Fallback predictor':''}</strong><span>${model.fallback?'Runs without Hugging Face model downloads.':'Notebook forecast using the SMARTDS weather model.'}</span></div><div class="drawer-actions"><button class="secondary-button" id="risk-refresh" ${loading?'disabled':''}>${loading?'Updating…':'Refresh forecast'}</button><button class="secondary-button" id="risk-download">Export forecast ↓</button></div><div id="risk-detail"></div><section class="drawer-section risk-list-section"><h3>Feeder risk scores</h3><label class="risk-search-label" for="risk-search">Find a feeder</label><input class="search-input" id="risk-search" type="search" placeholder="Name, feeder ID or county" value="${esc(query)}"><label class="risk-filter-label">Show <select id="risk-scope"><option value="mapped" ${scope==='mapped'?'selected':''}>Mapped feeders</option><option value="all" ${scope==='all'?'selected':''}>All SMARTDS feeders</option><option value="unavailable" ${scope==='unavailable'?'selected':''}>Unavailable / incomplete</option></select></label><p id="risk-result-count" class="small-note"></p><div id="risk-feeders"></div></section><details class="risk-method"><summary>Model and data details</summary><dl class="detail-list"><div><dt>Forecast generated</dt><dd>${riskTime(data.issuedAt)} UTC</dd></div><div><dt>Weather retrieved</dt><dd>${riskTime(data.weatherRetrievedAt)} UTC</dd></div><div><dt>Weather source</dt><dd>${esc(data.weatherSource?.label||'Open-Meteo')}</dd></div><div><dt>Training labels</dt><dd>2023 county outages</dd></div><div><dt>County target</dt><dd>≥ ${Number(model.thresholdCustomers).toLocaleString()} customers</dd></div><div><dt>Predictor</dt><dd>${esc(model.id)}</dd></div></dl><p>${esc(model.reason||'TabPFN V2 is evaluated at each feeder’s forecast weather.')}</p><p>The score is 100 × the county-model exceedance probability evaluated at feeder weather. The 24-hour score is the maximum hourly score, not the probability of any outage during the day. No confirmed feeder-level negative labels are available to calibrate feeder probabilities.</p><p>${esc(data.weatherSource?.details||'Open-Meteo best-match forecast; precipitation and gusts describe the preceding hour. Other weather values are at the hour end.')} Calendar features use America/New_York. Frozen storm context predates 2023. Location estimates are based on sampled service points. Missing inputs remain unscored.</p><p>Forecasts use SMARTDS inventory independently of the restoration replay and any uploaded historical outages. Weather retrieval time is not the provider’s model issuance time. Current forecasts expire when their hour window or weather freshness is no longer valid.</p><a href="${data.weatherSource?.id==='nws'?'https://www.weather.gov/':'https://open-meteo.com/'}" target="_blank" rel="noreferrer">Weather data by ${esc(data.weatherSource?.label||'Open-Meteo')}</a></details>`;
    body.querySelector('#risk-refresh').onclick=refresh;body.querySelector('#risk-download').onclick=download;
    body.querySelector('#risk-search').oninput=e=>{query=e.target.value;renderList();};
    body.querySelector('#risk-scope').onchange=e=>{scope=e.target.value;renderList();};
    body.onclick=e=>{const b=e.target.closest('[data-risk-id]');if(!b)return;active=b.dataset.riskId;const f=data.feeders.find(f=>f.id===active);if(f?.onMap)onSelect(active);renderDetail();renderList();body.querySelector('#risk-detail').scrollIntoView({block:'nearest',behavior:'instant'});};
    renderDetail();renderList();
  }
  async function refresh(){
    if(loading)return;loading=true;lastAttemptAt=Date.now();error='';if(isOpen()&&container)render(container);
    try{const response=await fetch('/outage-analyzer/api/outage-risk',{cache:'no-store',signal:AbortSignal.timeout(45000)});if(!response.ok)throw Error('The forecast service is temporarily unavailable. The forecast will retry automatically, or you can retry now.');const next=await response.json();if(next.schemaVersion!==1||!Array.isArray(next.feeders))throw Error('The forecast response could not be read.');data=next;}
    catch(e){error=e.name==='TimeoutError'?'The weather service took too long. The forecast will retry automatically, or you can retry now.':e.message;}
    finally{loading=false;if(isOpen()&&container)render(container);}
  }
  function download(){const current=isCurrentRisk(data),content={...data,exportedAt:new Date().toISOString(),currentAtExport:current,scoreInterpretation:'Transferred county-weather score, not calibrated feeder probability; daily summary is maximum hourly score.'};const url=URL.createObjectURL(new Blob([JSON.stringify(content,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='teco-feeder-risk-24h.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  // Recheck hour-boundary freshness while open. Refresh is independent of replay.
  const recheck=()=>{if(isOpen()&&!loading&&Date.now()-lastAttemptAt>=60000&&needsRiskRefresh(data))void refresh();};
  setInterval(recheck,60000);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)recheck();});
  return {render,refresh};
}
