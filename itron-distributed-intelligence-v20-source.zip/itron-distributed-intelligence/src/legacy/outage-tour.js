// Rank physical areas using meter-pair hours only: derived feeder/transformer
// episodes would count the same customer interruption a second time.
export function selectOutageTour(events, { startProgress = 0, maxStops = 4, radius = 500 } = {}) {
  const limit = Math.min(4, Math.max(2, Math.floor(maxStops)));
  const located = events.filter(e => e.type === 'servicePoint' && Number.isFinite(e.x) && Number.isFinite(e.z)
    && Number.isFinite(e.start) && Number.isFinite(e.end) && e.end > e.start
    && Number.isFinite(e.durationHours) && e.durationHours > 0 && e.end > startProgress);
  const candidates = located.map(center => {
    const members = located.filter(e => Math.hypot(e.x - center.x, e.z - center.z) <= radius);
    const customerHours = members.reduce((sum, e) => sum + e.durationHours, 0);
    const anchor = members.reduce((best, e) => e.durationHours > best.durationHours ? e : best, members[0]);
    return { x: anchor.x, z: anchor.z, circuit: anchor.circuit, start: anchor.start, end: anchor.end, customerHours,
      servicePoints: new Set(members.map(e => e.assetId)).size, members };
  }).sort((a, b) => b.customerHours - a.customerHours || b.servicePoints - a.servicePoints || a.x - b.x || a.z - b.z);
  const stops = [], assigned = new Set();
  for (const candidate of candidates) {
    if (stops.some(s => Math.hypot(s.x - candidate.x, s.z - candidate.z) < radius * 2)) continue;
    if (candidate.members.some(e => assigned.has(e))) continue;
    candidate.members.forEach(e => assigned.add(e));
    const { members, ...stop } = candidate;
    stops.push(stop);
    if (stops.length === limit) break;
  }
  return stops;
}

export const DEFAULT_REPLAY_SPEED = 0.75;
export const REPLAY_SPEEDS = [0.5, 0.75, 1, 2];

export const OUTAGE_FLIGHT_MS = 3000;
const ARRIVAL_SETTLE_MS = 500;
const OUTAGE_VIEW_MS = 2000;

export function createOutageTourClock(stops, startProgress = 0) {
  // Select by impact, then visit in event order. Already-active outages with
  // the earliest restoration get the first view.
  const ordered = stops.filter(stop => stop.end > startProgress).slice(0, 4)
    .sort((a, b) => Math.max(startProgress, a.start) - Math.max(startProgress, b.start) || a.end - b.end);
  return { stops: ordered, index: -1, settledMs: 0, viewedMs: 0 };
}

export function advanceOutageTour(clock, progress, elapsedMs, speed, moving = false) {
  // Flight time is presentation time, not study time. This also protects an
  // outage when the speed changes or a frame takes longer than expected.
  if (moving) return { progress };
  const current = clock.stops[clock.index];
  const visibleMs = Math.min(elapsedMs, 250);
  if (current && clock.settledMs < ARRIVAL_SETTLE_MS) {
    clock.settledMs += visibleMs;
    return { progress };
  }
  if (current && progress >= current.start) clock.viewedMs += visibleMs;
  let nextProgress = Math.min(1, progress + elapsedMs / 60000 * speed);
  const next = clock.stops[clock.index + 1];
  const departure = next && Math.max(0, next.start - ARRIVAL_SETTLE_MS / 60000 * speed);
  if (next && (!current || clock.viewedMs >= OUTAGE_VIEW_MS) && nextProgress >= departure) {
    clock.index++;
    clock.settledMs = 0;
    clock.viewedMs = 0;
    return { progress: Math.max(progress, Math.min(nextProgress, departure)), stop: next };
  }
  // Keep short or overlapping outages visible long enough to inspect. Future
  // stops cannot restore while the user is watching an earlier stop.
  if (current && clock.viewedMs < OUTAGE_VIEW_MS) {
    nextProgress = Math.min(nextProgress, Math.max(progress, (current.start + current.end) / 2));
  }
  for (const pending of clock.stops.slice(clock.index + 1)) {
    const latestArrival = pending.start + (pending.end - pending.start) * 0.1;
    nextProgress = Math.min(nextProgress, Math.max(progress, latestArrival));
  }
  return { progress: nextProgress };
}
