import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { styleCircuits, nearestCircuit } from './network-style.js';
import { undergroundBusLocations } from './scene.js';

const data = JSON.parse(readFileSync(new URL('../../public/data/smartds.json', import.meta.url), 'utf8'));

test('all SMARTDS circuits retain distinct shades and stable substation families across dataset ordering', () => {
  const styled = styleCircuits(data.circuits);
  const reordered = styleCircuits([...data.circuits].reverse().map(c => ({ ...c, events: 0 })));
  assert.equal(new Set(styled.map(c => c.color)).size, 11);
  assert.equal(new Set(styled.map(c => c.familyColor)).size, 2);
  for (const c of styled) {
    assert.equal(reordered.find(other => other.id === c.id).color, c.color);
    assert.ok(styled.filter(other => other.substation === c.substation).every(other => other.familyColor === c.familyColor));
  }
});

test('map context uses segment proximity, preserves shared-junction selection, and ignores distant paths', () => {
  const lines = [
    { circuit: 'long', points: [[-1000, 0], [1000, 0]] },
    { circuit: 'near-endpoint', points: [[0, 10], [0, 20]] },
    { circuit: 'crossing', points: [[0, -100], [0, 100]] },
  ];
  assert.equal(nearestCircuit(lines, { x: 200, z: 1 }), 'long');
  assert.equal(nearestCircuit(lines, { x: 0, z: 0 }, 'crossing'), 'crossing');
  assert.equal(nearestCircuit(lines, { x: 0, z: 0 }, 'long'), 'long');
  assert.equal(nearestCircuit(lines, { x: 2000, z: 2000 }, null, 20), null);
  assert.equal(nearestCircuit(data.topology.lines, data.initialView), 'p3rhs1_1247--p3rdt1194');
});

test('connectors do not produce overhead buses and actual OH/UG transitions keep poles', () => {
  const lines = [
    { circuit: 'a', fromBus: 'n/1', toBus: 'n/2', overhead: false, points: [[0, 0], [10, 0]] },
    { circuit: 'a', fromBus: 'n/1', toBus: 'n/3', overhead: null, points: [[0, 0], [0, 10]] },
    { circuit: 'a', fromBus: 'n/2', toBus: 'n/4', overhead: true, points: [[10, 0], [20, 0]] },
  ];
  assert.deepEqual(undergroundBusLocations(lines).map(({ x, z }) => [x, z]), [[0, 0]]);
  assert.equal(undergroundBusLocations(data.topology.lines).length, 758);
});
