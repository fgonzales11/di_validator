import {readFileSync} from 'node:fs';
// Pure regression tests: no Google requests or DOM are required.
import test from 'node:test';
import assert from 'node:assert/strict';
import {geographicLocation, selectedNetworkPoint, streetViewURLs, createAssetLocationResolver, explicitGeographicLocation} from './street-view.js';

const origin = {lat:37.59063544817409, lon:-121.88249695694624};
const close = (actual, expected, epsilon = 1e-8) => assert.ok(Math.abs(actual-expected) < epsilon, `${actual} != ${expected}`);

test('SMARTDS transformer coordinates restore the source model location', () => {
  // Independent source fixture from bus_geo for p3rhs1_1247--p3rdt1322/trafo1ph/0.
  // Exporter rounds x/z to millimeters; tolerance accommodates that rounding.
  const actual = geographicLocation({x:2117.719,z:5278.765}, origin);
  close(actual.lat, 37.54321571382945);
  close(actual.lon, -121.85848892446792);
  assert.deepEqual(geographicLocation({x:0,z:0}, origin), origin);
});

test('projection respects southward z, non-unit scale, and invalid coordinates', () => {
  const point = {x:2117.719,z:5278.765};
  assert.deepEqual(geographicLocation({x:point.x*2,z:point.z*2},origin,2), geographicLocation(point,origin));
  assert.ok(geographicLocation(point,origin).lat < origin.lat);
  assert.ok(geographicLocation(point,origin).lon > origin.lon);
  for (const scale of [0,-1,NaN,Infinity]) assert.equal(geographicLocation(point,origin,scale),null);
  for (const bad of [null,{}, {x:NaN,z:0},{x:0,z:Infinity}]) assert.equal(geographicLocation(bad,origin),null);
  for (const badOrigin of [null,{}, {lat:90,lon:0},{lat:-90,lon:0},{lat:NaN,lon:0}]) assert.equal(geographicLocation(point,badOrigin),null);
});

test('bus selections use bus position and conductor hits project onto the source centerline', () => {
  const line={kind:'line',points:[[0,0],[100,0],[100,100]]};
  assert.deepEqual(selectedNetworkPoint(line,{x:72,z:1.5}),{x:72,z:0});
  assert.deepEqual(selectedNetworkPoint(line,{x:101.5,z:80}),{x:100,z:80});
  assert.deepEqual(selectedNetworkPoint(line,{x:100,z:130}),{x:100,z:100});
  assert.deepEqual(selectedNetworkPoint({kind:'line',points:[[0,0],[100,100]]},{x:50,z:54}),{x:52,z:52});
  assert.deepEqual(selectedNetworkPoint({kind:'bus',x:100,z:0},{x:95,z:3}),{x:100,z:0});
  assert.equal(selectedNetworkPoint({kind:'line',points:[]},{x:0,z:0}),null);
  assert.equal(selectedNetworkPoint({kind:'line',points:[[NaN,0],[100,0]]},{x:0,z:0}),null);
  assert.equal(selectedNetworkPoint(line,{x:0,z:NaN}),null);
});

test('embed endpoint and Google Maps fallback use identical selected coordinates', () => {
  const location={lat:37.54321571382945,lon:-121.85848892446792};
  const links=streetViewURLs(location);
  const request=new URL(links.request,'https://example.test');
  const external=new URL(links.external);
  assert.equal(request.searchParams.get('lat'),'37.543216');
  assert.equal(request.searchParams.get('lon'),'-121.858489');
  assert.equal(external.origin,'https://www.google.com');
  assert.equal(external.searchParams.get('viewpoint'),'37.543216,-121.858489');
  assert.equal(external.searchParams.get('map_action'),'pano');
  assert.notEqual(streetViewURLs(origin).request,links.request);
  for (const point of [{lat:91,lon:0},{lat:0,lon:-181},{lat:null,lon:0},{lat:Infinity,lon:0}]) assert.equal(streetViewURLs(point),null);
});

test('switch selections use their source polyline', () => { assert.deepEqual(selectedNetworkPoint({kind:'switch',points:[[0,0],[10,0]]},{x:6,z:1}),{x:6,z:0}); });


test('asset coordinates win; connected bus lookup accepts bus zero and stays within its circuit', () => {
  const resolve=createAssetLocationResolver({origin,topology:{buses:[
    {id:'a/bus/0',circuit:'a',latitude:37.1,longitude:-121.1},
    {id:'b/bus/0',circuit:'b',latitude:37.2,longitude:-121.2}
  ]}});
  const own=resolve({kind:'transformer',latitude:0,longitude:0,circuit:'a',bus:'a/bus/0'});
  assert.equal(own.lat,0);assert.equal(own.lon,0);assert.equal(own.source,'Transformer coordinates');
  const fallback=resolve({kind:'transformer',latitude:91,longitude:0,circuit:'b',secondaryBusIndex:0});
  assert.equal(fallback.lat,37.2);assert.equal(fallback.lon,-121.2);assert.equal(fallback.busId,'b/bus/0');
  assert.equal(resolve({kind:'transformer',circuit:'a',bus:'b/bus/0'}),null);
  assert.equal(resolve({kind:'bus',id:'a/bus/0',circuit:'a'}).lat,37.1);
  for(const asset of [{latitude:null,longitude:0},{latitude:0,lon:0},{lat:'37.1',lon:-121.1},{lat:Infinity,lon:0}])assert.equal(explicitGeographicLocation(asset),null);
});

test('missing bus coordinates use projection only with a valid model point and origin', () => {
  const point={x:2117.719,z:5278.765};
  const place=createAssetLocationResolver({origin})({bus:'a/bus/999',circuit:'a'},point);
  close(place.lat,37.54321571382945);assert.equal(place.source,'Projected model location');
  assert.equal(createAssetLocationResolver({})({bus:'a/bus/999',circuit:'a'}),null);
});

test('every supplied transformer resolves directly to its connected SMARTDS bus without map coordinates', () => {
  const study=JSON.parse(readFileSync(new URL('../../public/data/smartds.json',import.meta.url)));
  const resolve=createAssetLocationResolver(study),byId=new Map(study.topology.buses.map(bus=>[bus.id,bus]));
  assert.equal(byId.size,8549);assert.equal(study.topology.transformers.length,1720);
  for(const transformer of study.topology.transformers){
    const {x,z,...asset}=transformer,place=resolve(asset),bus=byId.get(asset.bus);
    assert.equal(place.busId,asset.bus);assert.equal(place.lat,bus.latitude);assert.equal(place.lon,bus.longitude);
  }
});
