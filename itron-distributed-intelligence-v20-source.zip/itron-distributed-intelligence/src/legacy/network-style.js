// Muted color families retain the Orbit palette while separating substations.
const FAMILY_HUES = {
  Baycourt: 165, Clearview: 18, Cypress: 218, 'El Prado': 90,
  Granada: 285, 'Gray St': 45, Himes: 190, 'Hyde Park': 335,
  Interbay: 115, Louis: 255, Macdil: 5, Manhatan: 205,
  Matanzas: 145, 'Plant View': 60, Rome: 310,
};

function colorHex(h, s, l) {
  s /= 100; l /= 100;
  const a = s * Math.min(l, 1 - l);
  const channel = n => {
    const k = (n + h / 30) % 12;
    return Math.round(255 * (l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)))).toString(16).padStart(2, '0');
  };
  return `#${channel(0)}${channel(8)}${channel(4)}`;
}

export function styleCircuits(circuits) {
  const families = new Map();
  for (const circuit of circuits) {
    const name = circuit.substation || circuit.area || circuit.name;
    if (!families.has(name)) families.set(name, []);
    families.get(name).push(circuit);
  }
  const styles = new Map();
  for (const [substation, members] of families) {
    const hue = FAMILY_HUES[substation] ?? [...substation].reduce((n, c) => (n * 31 + c.charCodeAt(0)) % 360, 0);
    members.sort((a, b) => String(a.circuitId || a.id).localeCompare(String(b.circuitId || b.id), 'en', { numeric: true }));
    members.forEach((circuit, index) => {
      const shade = members.length === 1 ? 0.5 : index / (members.length - 1);
      styles.set(circuit.id, { substation, familyColor: colorHex(hue, 48, 68), color: colorHex(hue, 48 - shade * 8, 60 + shade * 19) });
    });
  }
  return circuits.map(circuit => ({ ...circuit, ...styles.get(circuit.id) }));
}

// Compare geographic segments, not circuit centroids (which may be far away).
export function nearestCircuit(lines, point, preferredId = null, maxDistance = Infinity) {
  let best = maxDistance * maxDistance, result = null;
  for (const line of lines || []) {
    if (line.circuit == null) continue;
    for (let i = 1; i < (line.points?.length || 0); i++) {
      const [ax, az] = line.points[i - 1], [bx, bz] = line.points[i];
      if (![ax, az, bx, bz, point.x, point.z].every(Number.isFinite)) continue;
      const dx = bx - ax, dz = bz - az, length = dx * dx + dz * dz;
      const t = length ? Math.max(0, Math.min(1, ((point.x - ax) * dx + (point.z - az) * dz) / length)) : 0;
      const distance = (point.x - ax - t * dx) ** 2 + (point.z - az - t * dz) ** 2;
      if (distance < best - 1e-8 || (Math.abs(distance - best) < 1e-8 && line.circuit === preferredId)) {
        best = distance; result = line.circuit;
      }
    }
  }
  return result;
}
