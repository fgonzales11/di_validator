import test from 'node:test';
import assert from 'node:assert/strict';
import {filterTransformers,sortTransformers} from './transformer-table.js';
const tx=(label,loading,min,max,circuit='13080',oil=loading)=>({id:label,label,circuit,substation:'Baycourt',maxWindingLoadingPct:loading,secondaryMinPu:min,secondaryMaxPu:max,oil});
const fleet=[tx('TX-3',160,.93,1.00),tx('TX-1',80,.98,1.01,'13166'),tx('TX-2',120,.99,1.06)];
const ctx={oil:t=>t.oil,oilLimit:105};
const labels=list=>list.map(t=>t.label);
test('column filters combine text, circuit, loading, voltage and top oil',()=>{
 assert.deepEqual(labels(filterTransformers(fleet,{},ctx)),['TX-3','TX-1','TX-2']);
 assert.deepEqual(labels(filterTransformers(fleet,{query:'tx-1'},ctx)),['TX-1']);
 assert.deepEqual(labels(filterTransformers(fleet,{query:'baycourt',circuit:'13080'},ctx)),['TX-3','TX-2']);
 assert.deepEqual(labels(filterTransformers(fleet,{loading:'over100'},ctx)),['TX-3','TX-2']);
 assert.deepEqual(labels(filterTransformers(fleet,{loading:'over150'},ctx)),['TX-3']);
 assert.deepEqual(labels(filterTransformers(fleet,{voltage:'outside'},ctx)),['TX-3','TX-2']);
 assert.deepEqual(labels(filterTransformers(fleet,{voltage:'low'},ctx)),['TX-3']);
 assert.deepEqual(labels(filterTransformers(fleet,{voltage:'within'},ctx)),['TX-1']);
 assert.deepEqual(labels(filterTransformers(fleet,{oilFilter:'over'},ctx)),['TX-3','TX-2']);
 assert.deepEqual(labels(filterTransformers(fleet,{oilFilter:'within',loading:'within'},ctx)),['TX-1']);
});
test('sorting follows column and direction',()=>{
 assert.deepEqual(labels(sortTransformers([...fleet],'loading',-1,ctx.oil)),['TX-3','TX-2','TX-1']);
 assert.deepEqual(labels(sortTransformers([...fleet],'voltage',1,ctx.oil)),['TX-3','TX-1','TX-2']);
 assert.deepEqual(labels(sortTransformers([...fleet],'id',1,ctx.oil)),['TX-1','TX-2','TX-3']);
 assert.deepEqual(labels(sortTransformers([...fleet],'oil',1,ctx.oil)),['TX-1','TX-2','TX-3']);
});
