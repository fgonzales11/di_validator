import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {googleNetworkGeometry,nearbyNetworkGeometry,conductorPaths,groundDistance,phaseOffsets,NETWORK_GEOMETRY} from './google-network-geometry.js';

const origin={lat:37,lng:-122,altitude:0},end={lat:37.001,lng:-122,altitude:0};
const line=(id,extra={})=>({asset:{id,circuit:'feeder',phases:'A · B · C',...extra},path:[origin,end]});
test('only overhead routes infer supports; phase geometry sags within bounded spans and open switches retain a gap',()=>{
  const input={transformers:[],lines:[line('OH',{overhead:true}),line('UG',{overhead:false}),line('unknown'),line('switch',{closed:false})]};
  const before=JSON.stringify(input),g=googleNetworkGeometry(input);
  assert.equal(g.spans.length,3);assert.equal(g.poles.size,4);
  assert.ok(g.spans.every(s=>s.asset.id==='OH'&&s.length<=55));
  assert.deepEqual(g.routes.map(r=>r.kind),['overhead','underground','unspecified','switch']);
  assert.equal(g.routes[3].paths.length,2);assert.ok(groundDistance(g.routes[3].paths[0].at(-1),g.routes[3].paths[1][0])>30);
  const paths=conductorPaths(g.spans[0]);assert.equal(paths.length,3);
  for(const path of paths){assert.equal(path[0].altitude,10.5);assert.equal(path.at(-1).altitude,10.5);assert.ok(path[4].altitude<10.5&&path[4].altitude>=8.7)}
  assert.ok(Math.abs(groundDistance(paths[0][0],paths[2][0])-3)<.01);
  assert.deepEqual(phaseOffsets('A'),[0]);assert.deepEqual(phaseOffsets('A · B'),[-1.5,1.5]);assert.deepEqual(phaseOffsets('A A A'),[0]);
  assert.equal(JSON.stringify(input),before);
});

test('conductors attach to the retained crossarm orientation at bends, and selected spans retain both support models',()=>{
  const bend={lat:37.0004,lng:-122,altitude:0},corner={lat:37.0004,lng:-121.9995,altitude:0};
  const g=googleNetworkGeometry({transformers:[],lines:[{...line('bend',{overhead:true}),path:[origin,bend,corner]}]});
  const first=conductorPaths(g.spans[0]),second=conductorPaths(g.spans[1]);
  for(let phase=0;phase<3;phase++)assert.deepEqual(first[phase].at(-1),second[phase][0]);
  // Distinct nearby short spans can reach the model budget before span budget.
  const many=googleNetworkGeometry({transformers:[],lines:Array.from({length:140},(_,i)=>({asset:{id:String(i),circuit:'test',overhead:true},path:[{...origin,lng:origin.lng+i*.000002},{...origin,lng:origin.lng+i*.000002,lat:origin.lat+.0003}]}))});
  const detail=nearbyNetworkGeometry(many,origin,260),ids=new Set(detail.poles.map(p=>p.id));
  assert.ok(detail.poles.length<=160&&detail.spans.length<=100);
  assert.ok(detail.spans.every(s=>s.poles.every(id=>ids.has(id))));
  const edge=googleNetworkGeometry({transformers:[],lines:[{asset:{id:'edge',circuit:'test',overhead:true},path:[{...origin,lat:origin.lat+135/111320},{...origin,lat:origin.lat+180/111320}]}]});
  const edgeDetail=nearbyNetworkGeometry(edge,origin,100);
  assert.equal(edgeDetail.spans.length,1);assert.equal(edgeDetail.poles.length,2);
});

test('camera detail has bounded geometry and removes all models for overview, plan view or hidden layer',()=>{
  const g=googleNetworkGeometry({transformers:Array.from({length:100},(_,i)=>({asset:{id:String(i)},position:origin})),lines:Array.from({length:300},(_,i)=>line(String(i),{overhead:true}))});
  const near=nearbyNetworkGeometry(g,origin,260);
  assert.equal(near.spans.length,NETWORK_GEOMETRY.maxSpans);assert.ok(near.poles.length<=NETWORK_GEOMETRY.maxPoles);assert.equal(near.transformers.length,32);
  for(const [center,range,enabled] of [[origin,3000,true],[origin,200,false],[null,200,true],[{lat:38,lng:-121},200,true]])assert.deepEqual(nearbyNetworkGeometry(g,center,range,enabled),{spans:[],poles:[],transformers:[]});
});

test('network GLBs contain self-contained core PBR meshes with grounded, upright meter dimensions',()=>{
  for(const name of ['pole-1','pole-2','pole-3','transformer-symbol']){
    const bytes=readFileSync(new URL(`../../public/models/${name}.glb`,import.meta.url));
    assert.equal(bytes.readUInt32LE(0),0x46546c67);assert.equal(bytes.readUInt32LE(4),2);assert.equal(bytes.readUInt32LE(8),bytes.length);
    const jsonLength=bytes.readUInt32LE(12),gltf=JSON.parse(bytes.subarray(20,20+jsonLength).toString());
    assert.equal(gltf.asset.version,'2.0');assert.equal(gltf.extensionsUsed,undefined);assert.equal(gltf.buffers[0].uri,undefined);
    const positions=gltf.meshes[0].primitives.map(p=>gltf.accessors[p.attributes.POSITION]);
    assert.ok(Math.abs(Math.min(...positions.map(p=>p.min[2])))<.00001);
    assert.ok(Math.abs(Math.max(...positions.map(p=>p.max[2]))-(name.startsWith('pole')?10.5:3))<.00001);
    for(const v of gltf.bufferViews)assert.ok(v.byteOffset+v.byteLength<=gltf.buffers[0].byteLength);
    assert.ok(bytes.length<70000);
  }
});
