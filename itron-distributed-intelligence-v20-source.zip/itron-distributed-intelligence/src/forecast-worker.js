import {runForecast} from './forecast-model.mjs';
let pythonModule;
const fitPython=async(payload,id)=>{
 const url=new URL(`${import.meta.env.BASE_URL}forecasting/runtime.mjs`,self.location.origin).href;
 const module=await(pythonModule??=import(/* @vite-ignore */url).catch(e=>{pythonModule=null;throw e}));
 return module.fitPythonForecast(payload,message=>self.postMessage({type:'status',id,message}));
};
let busy=false;
self.onmessage=async({data})=>{if(busy)return;busy=true;const id=data.id;try{
 const o=data.options,series={timestamps:data.series.map(x=>x.timestamp),values:data.series.map(x=>x.value),channel:o.channel,unit:o.channel==='load_kw'?'kW':'pu',source:data.provenance.source,synthetic:true};
 const result=await runForecast(series,{horizon:o.horizon,contextLength:o.context,validationWindows:o.windows,seasonLength:o.seasonLength,lags:o.lags,ridge:o.ridge,models:o.models,trees:o.trees,maxDepth:o.maxDepth,minLeaf:o.minLeaf,seed:o.seed},{onProgress:e=>self.postMessage({type:'status',id,message:e.message}),fitPredict:payload=>fitPython(payload,id)});
 result.provenance=data.provenance;result.generatedAt=new Date().toISOString();result.sourceSha256=[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(series))))].map(x=>x.toString(16).padStart(2,'0')).join('');self.postMessage({type:'result',id,result});
 }catch(e){self.postMessage({type:'error',id,message:e.message})}finally{busy=false}};
