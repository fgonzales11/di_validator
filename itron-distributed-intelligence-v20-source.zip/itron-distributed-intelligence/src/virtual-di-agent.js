// Reproducible browser virtual meters. These profiles are simulations, never field telemetry.
export const INTERVAL_MS = 15 * 60 * 1000;
export const SCENARIO_START = Date.UTC(2026, 8, 1);
export const SAMPLE_COUNT = 14 * 96;
export const SCENARIO_END = SCENARIO_START + SAMPLE_COUNT * INTERVAL_MS;
export const hash = value => { let h=2166136261; for(const c of String(value)) h=Math.imul(h^c.charCodeAt(0),16777619); return h>>>0; };
const noise = (seed,i) => ((hash(`${seed}:${i}`) / 4294967295) * 2 - 1);
export function meterOutages(meter) {
  const seed=hash(meter.id);
  if(seed%47!==0)return [];
  const index=3*96+seed%(9*96), duration=2+(seed%7);
  return [{id:`VDI-${meter.id}-1`,startIndex:index,endIndex:index+duration,startedAt:SCENARIO_START+index*INTERVAL_MS,restoredAt:SCENARIO_START+(index+duration)*INTERVAL_MS}];
}
// Single-sample generation keeps compact edge workers from allocating full histories.
export function virtualMeterSample(meter,i) {
  if(!meter?.id||!Number.isInteger(i)||i<0||i>=SAMPLE_COUNT)throw Error('Invalid virtual meter sample.');
  const seed=hash(meter.id),outages=meterOutages(meter),base=Number.isFinite(meter.inputLoadKw)?meter.inputLoadKw:0,voltage=Number(meter.baselineVoltagePu)||1;
    const timestamp=SCENARIO_START+i*INTERVAL_MS,d=new Date(timestamp),hour=d.getUTCHours()+d.getUTCMinutes()/60,weekend=[0,6].includes(d.getUTCDay());
    const shape=.4+.22*Math.exp(-(((hour-7)/2.6)**2))+.6*Math.exp(-(((hour-19)/3.5)**2))+(weekend?.08:0);
    const off=outages.some(e=>i>=e.startIndex&&i<e.endIndex),kw=off?0:Math.max(0,base*(shape+.045*noise(seed,i)));
    return {timestamp,load_kw:kw,voltage_pu:off?0:voltage-.008*(shape-.65)+.0015*noise(seed+1,i),quality:'simulated',power:off?'off':'on'};
}
export function meterProfile(meter) {
  if(!meter?.id)throw Error('Select a modeled meter.');
  const seed=hash(meter.id), outages=meterOutages(meter), base=Number.isFinite(meter.inputLoadKw)?meter.inputLoadKw:0, voltage=Number(meter.baselineVoltagePu)||1;
  const samples=Array.from({length:SAMPLE_COUNT},(_,i)=>virtualMeterSample(meter,i));
  return {meterId:meter.id,circuit:meter.circuit,source:'Virtual DI agent simulation',intervalMs:INTERVAL_MS,seed,modelInputLoadKw:base,baselineVoltagePu:voltage,samples,events:outages.flatMap(e=>[{id:e.id+'-PON',pairId:e.id,meterId:meter.id,circuit:meter.circuit,kind:'PON',timestamp:e.startedAt,description:'Power outage notification',source:'simulated'},{id:e.id+'-PRN',pairId:e.id,meterId:meter.id,circuit:meter.circuit,kind:'PRN',timestamp:e.restoredAt,description:'Power restoration notification',source:'simulated'}])};
}
export function attachVirtualScenario(data) {
  const meters=data.topology.servicePoints, circuits=new Map(data.circuits.map(c=>[c.id,c]));
  const pairs=meters.flatMap(m=>meterOutages(m).map(e=>{const c=circuits.get(m.circuit);return {...e,assetId:m.id,circuit:m.circuit,circuitName:`${c?.name||''} · ${m.circuit}`,type:'servicePoint',status:'virtual_agent_outage',source:'Virtual DI agent simulation',qualifies:true,start:(e.startedAt-SCENARIO_START)/(SCENARIO_END-SCENARIO_START),end:(e.restoredAt-SCENARIO_START)/(SCENARIO_END-SCENARIO_START),durationHours:(e.restoredAt-e.startedAt)/3600000,x:m.x??m.anchor?.x,z:m.z??m.anchor?.z,locationBasis:'model',inventoryMeters:1,requiredMetersDown:1,peakMetersDown:1}}));
  data.events=pairs;data.outageEpisodes=pairs;data.study.notes=data.study.notes.filter(n=>!n.includes('Event arrays are empty.'));data.study.notes.push('Profiles and PON/PRN pairs in the browser are deterministic virtual-agent simulations, not supplied field records.');
  data.topology.outageCells=pairs.map(e=>({x:e.x,z:e.z,circuit:e.circuit,hours:e.durationHours,restoredAt:e.end,restoredFraction:e.end,eventCount:1,intervals:[{startFraction:e.start,endFraction:e.end,hours:e.durationHours}]}));
  Object.assign(data.study,{start:SCENARIO_START,end:SCENARIO_END,source:'SMARTDS snapshots + virtual DI agent',scenario:'Deterministic simulated meter profiles and paired PON/PRN events. No supplied field histories.'});
  Object.assign(data.study.totals,{events:pairs.length,episodes:pairs.length,servicePoint:pairs.length,transformer:0,feeder:0,linkedEvents:pairs.length,unassignedEvents:0});
  Object.assign(data.study.sourceCounts,{rawEventRows:pairs.length*2,pairedEvents:pairs.length,validEventPairs:pairs.length,linkedEventPairs:pairs.length,qualifyingEpisodes:pairs.length,derivedEpisodes:pairs.length,exportedEventRecords:pairs.length,distinctPairedServicePoints:new Set(pairs.map(e=>e.assetId)).size,outageCells:pairs.length});
  data.circuits.forEach(c=>{const ev=pairs.filter(e=>e.circuit===c.id);c.events=ev.length;c.outages={servicePoint:ev.length,transformer:0,feeder:0};c.restoredAt=ev.length?Math.max(...ev.map(e=>e.end)):0});
  return data;
}
export function createVirtualDIAgent() {
  let meters=[],selected=null,profile=null,cursor=0,timer=null,status='ready',waveform=null;
  const listeners=new Set();
  const state=()=>({status,meter:selected,profile,cursor,sample:profile?.samples[cursor],events:profile?.events.filter(e=>e.timestamp<=profile.samples[cursor].timestamp)||[],waveform});
  const emit=()=>listeners.forEach(f=>f(state()));
  const pause=()=>{clearInterval(timer);timer=null;if(status==='replaying')status='paused';emit()};
  return {
    configure(items){pause();meters=items;this.select(items[0]?.id)},
    select(id){const meter=meters.find(m=>m.id===id);if(!meter)throw Error('The modeled meter is unavailable.');pause();selected=meter;profile=meterProfile(meter);cursor=0;status='ready';waveform=null;emit();return state()},
    play(){if(!profile||timer)return;if(cursor>=profile.samples.length-1)cursor=0;status='replaying';emit();timer=setInterval(()=>{cursor=Math.min(cursor+4,profile.samples.length-1);if(cursor===profile.samples.length-1){clearInterval(timer);timer=null;status='complete'}emit()},350)},
    pause,
    seek(index){if(!profile)return;cursor=Math.max(0,Math.min(profile.samples.length-1,Math.floor(Number(index))||0));emit()},
    reset(){pause();cursor=0;status='ready';emit()},
    assignWaveform(record){if(!selected)throw Error('Select a meter first.');waveform={recordId:record.id,meterId:selected.id,source:'RTDS recording replay; virtual assignment only',record};emit();return waveform},
    getState:state,
    subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn)},
    getProfile(id){return id===selected?.id?profile:meterProfile(meters.find(m=>m.id===id))},
  };
}
export const diAgent=createVirtualDIAgent();
