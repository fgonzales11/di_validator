import test from 'node:test';
import assert from 'node:assert/strict';
import {createPageStateStore,capturePageDOM,restorePageDOM,createPagePortals,restoreAnalysisTable} from './page-state.js';
const input=(id,value,extra={})=>({id,tagName:'INPUT',type:'number',name:id,value,checked:false,...extra});
function root(controls,{details=[],all=[]}={}){return {querySelector:()=>null,querySelectorAll:selector=>selector==='input,select,textarea'?controls:selector==='details'?details:all}}
test('page contexts and unsaved drafts remain independent',()=>{
 const pages=createPageStateStore();pages.set('network',{circuit:'A',filter:'bus 3',scroll:700});pages.set('workspace',{circuit:'B',filter:'line 7',scroll:200});
 assert.deepEqual(pages.get('network'),{circuit:'A',filter:'bus 3',scroll:700});assert.equal(pages.get('workspace').circuit,'B');assert.equal(pages.get('unvisited'),undefined);
});
test('restore draft values, checkbox, details and table scroll without restoring stale busy flags',()=>{
 const before=root([input('horizon','48'),input('noise','on',{type:'checkbox',checked:true}),input('measurement-file','private.json',{type:'file'})],{details:[{open:true}],all:[{scrollTop:75,scrollLeft:120}]});
 const saved=capturePageDOM(before,{scrollX:5,scrollY:930});
 const controls=[input('horizon','96',{disabled:false}),input('noise','on',{type:'checkbox'}),input('measurement-file','',{type:'file'})],details=[{open:false}],all=[{scrollTop:0,scrollLeft:0}];
 restorePageDOM(root(controls,{details,all}),saved);
 assert.equal(controls[0].value,'48');assert.equal(controls[0].disabled,false);assert.equal(controls[1].checked,true);assert.equal(controls[2].value,'');assert.equal(details[0].open,true);assert.deepEqual(all[0],{scrollTop:75,scrollLeft:120});assert.equal(saved.y,930);
});
test('DOM snapshots cannot overwrite selected feeder/meter or live replay position',()=>{
 const saved=capturePageDOM(root([input('circuit-picker','old'),input('di-meter','old'),input('di-seek','300')]),{});
 const controls=[input('circuit-picker','new'),input('di-meter','new'),input('di-seek','450')];restorePageDOM(root(controls),saved);
 assert.deepEqual(controls.map(c=>c.value),['new','new','450']);
});
test('portals keep iframe/scene host connected and reuse it through hidden page renders',()=>{
 const old=globalThis.ResizeObserver;globalThis.ResizeObserver=class{observe(){}disconnect(){}};
 try{
  const children=[],doc={body:{append(el){children.push(el);el.isConnected=true}},createElement(){return {dataset:{},style:{},children:[],setAttribute(k,v){this[k]=v},remove(){this.isConnected=false}}}};
  const view={scrollX:4,scrollY:20},slot=()=>({isConnected:true,getBoundingClientRect:()=>({left:10,top:100,width:800,height:600})});
  const portals=createPagePortals(doc,view);portals.activate('outage');const host=portals.mount('outage','outage',slot());const iframe={runtime:{result:'computed',camera:[1,2,3]}};host.children.push(iframe);
  portals.activate('network');assert.equal(host.isConnected,true);assert.equal(host.style.visibility,'hidden');assert.equal(host.inert,true);
  portals.activate('outage');assert.equal(portals.mount('outage','outage',slot()),host);assert.equal(children.length,1);assert.equal(host.children[0],iframe);assert.equal(host.style.visibility,'visible');assert.equal(host.style.top,'120px');portals.dispose();assert.equal(host.isConnected,false);
 }finally{globalThis.ResizeObserver=old}
});
test('analysis filter/sort/page restoration uses the refreshed result handlers',()=>{
 const state={filter:'',sort:false,page:0};const select={value:'first',options:[{value:'cases'}],onchange(){state.filter='';state.page=0}},input={value:'',oninput(){state.filter=this.value;state.page=0}},sort={dataset:{analysisSort:'loading'},click(){state.sort=!state.sort}},next={get disabled(){return state.page>=2},click(){state.page++}};
 const doc={querySelector(s){return {'#analysis-result-table':select,'#analysis-result-filter':input,'#analysis-next':next}[s]},querySelectorAll(){return [sort]}};
 restoreAnalysisTable(doc,{table:'cases',filter:'islanded',sort:'loading',descending:false,page:99});assert.deepEqual(state,{filter:'islanded',sort:true,page:2});assert.equal(select.value,'cases');
});

test('form draft and scroll keys survive extra controls and result rows',()=>{
 const field=value=>({tagName:'INPUT',type:'number',name:'tolerance',value,closest:()=>({id:'settings'})});
 const scroller=(top,left)=>({tagName:'DIV',className:'result-table-scroll',scrollTop:top,scrollLeft:left});
 const saved=capturePageDOM(root([field('0.002')],{all:[scroller(75,340)]}),{});
 const draft=field('0.1'),scroll=scroller(0,0);restorePageDOM(root([input('new-result-filter',''),draft],{all:[{tagName:'P',className:'new-result'},scroll]}),saved);
 assert.equal(draft.value,'0.002');assert.equal(scroll.scrollTop,75);assert.equal(scroll.scrollLeft,340);
});
