import {analysisDefinition,validateAnalysisParameters} from './analysis-types.js';
export function createAnalysis({onChange,workerFactory=()=>new Worker(`${import.meta.env.BASE_URL}analysis/worker.mjs`,{type:'module'})}){
 let worker,request=0,state={status:'idle',circuit:null,analysis:'power_flow',result:null,message:''};
 const update=next=>{state={...state,...next};onChange(state)};
 function run(circuit,parameters,analysis='power_flow'){
  if(state.status==='running')return;
  const id=++request;
  try{parameters=validateAnalysisParameters(analysis,parameters);
   update({status:'running',circuit:{...circuit},analysis,parameters:{...parameters},result:null,error:null,message:`Starting ${analysisDefinition(analysis).label.toLowerCase()}…`});
   worker??=workerFactory();const active=worker;
   worker.onmessage=({data})=>{if(worker!==active||data.id!==request||state.status!=='running')return;if(data.type==='status'){update({message:data.message});return}if(data.type==='error'){update({status:'error',message:'Analysis could not complete.',error:data.message,result:null});return}if(data.type!=='result'||data.circuit!==state.circuit.id||data.result?.analysis!==state.analysis||data.result?.completed!==true||typeof data.result?.converged!=='boolean'){update({status:'error',message:'The study returned an unexpected result.',result:null});return}update({status:data.result.converged===false?'not_converged':'success',message:data.result.message||'Analysis complete.',result:data.result,modelSha256:data.modelSha256,solverSha256:data.solverSha256,completedAt:new Date().toISOString()})};
   worker.onerror=e=>{if(worker!==active)return;worker.terminate();worker=undefined;update({status:'error',message:'The browser analysis worker could not start.',error:e.message,result:null})};
   worker.postMessage({id,circuit:String(circuit.id),analysis,parameters});
  }catch(e){worker?.terminate();worker=undefined;update({status:'error',circuit:{...circuit},analysis,result:null,error:e.message,message:'Check study settings.'})}
 }
 function cancel(){request++;worker?.terminate();worker=undefined;update({status:'cancelled',result:null,error:null,message:'Analysis cancelled. You can start another run.'})}
 function reset(){if(state.status==='running')cancel();else request++;update({status:'idle',result:null,error:null,message:'Ready to run analysis.'})}
 function exportResult(){return state.result&&['success','not_converged'].includes(state.status)?{...state.result,circuit:state.circuit.id,parameters:state.parameters,modelSha256:state.modelSha256,solverSha256:state.solverSha256,completedAt:state.completedAt}:null}
 return {run,cancel,reset,exportResult,getState:()=>state};
}
