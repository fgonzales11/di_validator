import {attachVirtualScenario} from './virtual-di-agent.js';
import {styleCircuits} from './network-style.js';
export let study={},circuits=[],events=[],totals={},topology={},outageEpisodes=[];
export const clamp=(x,lo=0,hi=1)=>Math.min(hi,Math.max(lo,Number.isFinite(Number(x))?Number(x):lo));
export function installStudy(data){
  if(!data.study||!Array.isArray(data.circuits)||!Array.isArray(data.events)||!data.topology)throw new Error('The network dataset is incomplete.');
  if(data.study.dataset?.toLowerCase()==='smartds')attachVirtualScenario(data);
  study=data.study;circuits=styleCircuits(data.circuits);events=data.events;totals=study.totals;outageEpisodes=data.outageEpisodes||[];
  topology={...data.topology,initialView:data.initialView,worldUnitsPerMeter:data.worldUnitsPerMeter};
  return data;
}
export async function loadStudy(){const response=await fetch(`${import.meta.env.BASE_URL}data/smartds.json`);if(!response.ok)throw new Error('Could not load the SMARTDS study.');return installStudy(await response.json());}
export function replayStats(progress,circuitId){const p=clamp(progress),scope=circuitId?events.filter(e=>e.circuit===circuitId):events;const ended=scope.filter(e=>e.end<=p),active=scope.filter(e=>e.start<=p&&e.end>p);return {restored:ended.length,active:active.length,remaining:scope.length-ended.length,total:scope.length,affectedAssets:new Set(active.map(e=>e.assetId)).size};}
export function histogram(binCount=112,circuitId){const counts=Array.from({length:binCount},()=>0);for(const e of events){if(circuitId&&e.circuit!==circuitId)continue;counts[Math.min(binCount-1,Math.floor(e.end*binCount))]++}return counts;}
export function formatDate(timestamp,options={}){return new Intl.DateTimeFormat('en-US',{month:'short',day:'numeric',timeZone:'UTC',...options}).format(timestamp);}
export function formatTime(progress){return formatDate(study.start+clamp(progress)*(study.end-study.start),{hour:'2-digit',minute:'2-digit',hour12:false})+' UTC';}
export function csvRows(circuitId){const selected=circuitId?events.filter(e=>e.circuit===circuitId):events;return 'Event ID,Circuit,Anonymous service point,Classification,Started (UTC),Restored (UTC),Duration (hours)\n'+selected.map(e=>[e.id,e.circuitName,e.assetId,e.status,new Date(e.startedAt).toISOString(),new Date(e.restoredAt).toISOString(),e.durationHours.toFixed(4)].join(',')).join('\n');}
