import {createGateway} from './gateway-engine.mjs';
let gateway,generation,times=[];
const state=()=>({...gateway.snapshot(),runtime:{batchP95Ms:[...times].sort((a,b)=>a-b)[Math.max(0,Math.ceil(times.length*.95)-1)]||0,samples:times.length,worker:true}});
self.onmessage=({data})=>{try{
  if(data.type==='configure'){generation=data.generation;gateway=createGateway(data.config);times=[]}
  if(data.generation!==generation)return;
  if(data.type==='action')gateway.action(data.kind,data.value);
  if(data.type==='step'||data.type==='action'){const start=performance.now();gateway.step();times.push(performance.now()-start);if(times.length>120)times.shift()}
  self.postMessage({id:data.id,generation,state:state(),...(data.type==='export'?{exportData:{...gateway.export(),runtime:state().runtime}}:{})});
}catch(error){self.postMessage({id:data.id,generation:data.generation,error:error.message})}};
