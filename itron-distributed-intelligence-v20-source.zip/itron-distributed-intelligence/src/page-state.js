// Page-local UI snapshots complement the study controllers, which remain alive
// across navigation. Results and busy/disabled flags are never restored from DOM.
export function createPageStateStore() {
  const pages = new Map();
  return {get: key => pages.get(key), set(key, value) {pages.set(key, value);return value}, has: key => pages.has(key)};
}
const ignoredControls = new Set(['circuit-picker', 'di-meter', 'di-seek', 'analysis-type', 'network-display', 'thermal-cursor','gateway-network','gateway-limit','gateway-fleet','gateway-response','gateway-reserve','edge-network','edge-scope','edge-window','edge-scenario','edge-report-period','edge-severity','edge-cooldown','edge-report-choice',...['contract','time','coverage','context','anomaly','stuck'].map(id=>'edge-skill-'+id)]);
function elements(root, selector) {return [...root.querySelectorAll(selector)]}
function scrollKeys(items) {const counts=new Map();return items.map((el,index)=>{if(el.id)return `id:${el.id}`;const base=el.className&&typeof el.className==='string'?`${el.tagName}.${el.className}`:`node:${index}`;const nth=counts.get(base)||0;counts.set(base,nth+1);return `${base}:${nth}`})}
function controlKeys(items) {const counts=new Map();return items.map(el=>{if(el.id)return `id:${el.id}`;const form=el.closest?.('form'),base=`${form?.id||form?.name||''}:${el.tagName}:${el.name||''}`;const nth=counts.get(base)||0;counts.set(base,nth+1);return `${base}:${nth}`})}
export function capturePageDOM(root, viewport = globalThis.window) {
  const fields=elements(root,'input,select,textarea'),fieldKeys=controlKeys(fields);const controls=fields.map((el,index)=>({
    key: fieldKeys[index], value: el.value, checked: el.checked,
    selections: el.multiple ? [...el.options].map(o => o.selected) : null,
    skip: ignoredControls.has(el.id) || ['file','button','submit','reset'].includes(el.type),
  })).filter(x => !x.skip);
  const details = elements(root, 'details').map(el => el.open);
  const all=elements(root,'*'),keys=scrollKeys(all);const scroll=all.flatMap((el,index)=>el.scrollTop||el.scrollLeft?[{key:keys[index],top:el.scrollTop,left:el.scrollLeft}]:[]);
  const dialog = root.querySelector('dialog');
  return {controls, details, scroll, x: viewport?.scrollX || 0, y: viewport?.scrollY || 0,
    dialog: dialog?.open ? {title: dialog.querySelector('h2')?.textContent || '', html: dialog.querySelector('.modal-body')?.innerHTML || '', settings: Boolean(dialog.querySelector('#analysis-settings-form,#estimation-form'))} : null};
}
export function restorePageDOM(root, saved) {
  if (!saved) return;
  const controls = new Map(saved.controls.map(c => [c.key,c]));
  const fields=elements(root,'input,select,textarea'),fieldKeys=controlKeys(fields);fields.forEach((el,index)=>{
    const old=controls.get(fieldKeys[index]);if(!old)return;
    if(el.tagName !== 'SELECT' || [...el.options].some(o=>o.value===old.value))el.value=old.value;
    if(typeof old.checked==='boolean')el.checked=old.checked;
    if(old.selections&&el.multiple)[...el.options].forEach((o,i)=>o.selected=Boolean(old.selections[i]));
  });
  elements(root,'details').forEach((el,index)=>{if(index<saved.details.length)el.open=saved.details[index]});
  const all=elements(root,'*'),keys=scrollKeys(all),byKey=new Map(keys.map((key,index)=>[key,all[index]]));for(const s of saved.scroll){const el=byKey.get(s.key);if(el){el.scrollTop=s.top;el.scrollLeft=s.left}}
}
// An iframe must remain connected, even while its page is hidden. Reparenting or
// replacing it reloads its document and destroys its workers and visualizations.
// Three's canvas uses the same portal so camera/controls survive page renders.
export function createPagePortals(doc = document, viewport = window) {
  const entries=new Map();let activePage;
  const position=entry=>{if(entry.page!==activePage||!entry.placeholder?.isConnected)return;const r=entry.placeholder.getBoundingClientRect();Object.assign(entry.host.style,{left:`${r.left+viewport.scrollX}px`,top:`${r.top+viewport.scrollY}px`,width:`${r.width}px`,height:`${r.height}px`})};
  const visibility=entry=>{const active=entry.page===activePage;entry.host.style.position=active?'absolute':'fixed';if(!active){entry.host.style.left='-100000px';entry.host.style.top='0px'}entry.host.style.visibility=active?'visible':'hidden';entry.host.style.pointerEvents=active?'auto':'none';entry.host.inert=!active;entry.host.setAttribute('aria-hidden',String(!active))};
  return {
    activate(page){activePage=page;for(const entry of entries.values()){visibility(entry);position(entry)}},
    mount(key,page,placeholder){
      let entry=entries.get(key);
      if(!entry){const host=doc.createElement('div');host.dataset.pagePortal=key;Object.assign(host.style,{position:'absolute',overflow:'hidden',borderRadius:'7px',zIndex:'0'});doc.body.append(host);entry={host,page};entries.set(key,entry)}
      entry.observer?.disconnect();entry.placeholder=placeholder;
      entry.observer=new ResizeObserver(()=>position(entry));entry.observer.observe(placeholder);
      position(entry);visibility(entry);return entry.host;
    },
    update(){for(const entry of entries.values())position(entry)},
    get:key=>entries.get(key)?.host,
    dispose(){for(const entry of entries.values()){entry.observer?.disconnect();entry.host.remove()}entries.clear()},
  };
}

export function captureAnalysisTable(root) {
  const select=root.querySelector('#analysis-result-table');if(!select)return null;
  const sort=[...root.querySelectorAll('[data-analysis-sort]')].find(el=>/[▴▾]/.test(el.textContent));
  const page=Number(root.querySelector('#analysis-table-rows .pagination span')?.textContent.match(/Page (\d+)/)?.[1]||1)-1;
  return {table:select.value,filter:root.querySelector('#analysis-result-filter')?.value||'',sort:sort?.dataset.analysisSort,descending:sort?.textContent.includes('▾'),page};
}
export function restoreAnalysisTable(root,saved) {
  const select=root.querySelector('#analysis-result-table');if(!saved||!select||![...select.options].some(o=>o.value===saved.table))return;
  select.value=saved.table;select.onchange?.();
  const input=root.querySelector('#analysis-result-filter');input.value=saved.filter;input.oninput?.();
  const sort=()=>[...root.querySelectorAll('[data-analysis-sort]')].find(el=>el.dataset.analysisSort===saved.sort);
  sort()?.click();if(saved.descending)sort()?.click();
  for(let page=0;page<saved.page;page++){const next=root.querySelector('#analysis-next');if(!next||next.disabled)break;next.click()}
}
