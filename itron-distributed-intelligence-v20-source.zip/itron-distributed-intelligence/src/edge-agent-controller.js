import {EDGE_DEFAULTS,validateEdgeConfig} from './edge-quality.mjs';
export function createEdgeController({workerFactory=()=>new Worker(new URL('./edge-agent-worker.js',import.meta.url),{type:'module'}),broadcast=()=>{},clock=()=>performance.now()}={}){
  let worker,timer,busy=false,pendingId=0,runId=0,requestStart=0,state=null,status='idle',error='',scope=null,exportData=null;
  let publishedAlerts=new Set(),publishedReports=new Set(),publishedBatch=0,roundTripMs=0;
  const listeners=new Set(),snapshot=()=>({state,status,error,busy,scope,roundTripMs,exportData,runId}),emit=()=>listeners.forEach(fn=>fn(snapshot()));
  const pause=()=>{clearInterval(timer);timer=null;if(status==='running')status='paused';emit()};
  function send(type,extra={}){if(!worker||busy)return false;busy=true;requestStart=clock();const id=++pendingId;worker.postMessage({id,runId,type,...extra});emit();return true}
  function fail(message){clearInterval(timer);timer=null;busy=false;status='error';error=message;worker?.terminate();worker=null;emit()}
  return {
    configure(meters,config={...EDGE_DEFAULTS},scenario='stress'){
      config=validateEdgeConfig(config);if(!meters.length||meters.length>64)throw Error('Choose 1–64 meters.');
      pause();worker?.terminate();runId++;pendingId=0;busy=false;state=null;exportData=null;error='';scope={meters:meters.map(m=>m.id),circuit:meters[0].circuit,config,scenario};publishedAlerts=new Set();publishedReports=new Set();publishedBatch=0;
      const generation=runId;worker=workerFactory();
      worker.onmessage=({data})=>{
        if(generation!==runId||data.runId!==runId||data.id!==pendingId)return;
        busy=false;roundTripMs=Math.max(0,clock()-requestStart);
        if(data.type==='error'){fail(data.message);return}
        state=data.state;if(data.exportData)exportData=data.exportData;
        if(status==='loading')status='ready';
        if(state.complete){clearInterval(timer);timer=null;status='complete'}
        if(state.index>publishedBatch){publishedBatch=state.index;broadcast({kind:'records',runId,payload:{id:`batch-${state.index}`,source:state.source,records:state.qualifiedBatch}})}
        for(const [items,known,kind] of [[state.alerts,publishedAlerts,'alert'],[state.reports,publishedReports,'report']])for(const item of items)if(!known.has(item.id)){known.add(item.id);broadcast({kind,runId,payload:item});if(known.size>128)known.delete(known.values().next().value)}
        emit();
      };
      worker.onerror=event=>{if(generation===runId)fail(event.message||'The edge worker stopped unexpectedly. Start a new run to retry.')};
      status='loading';send('configure',{meters,config,scenario});
    },
    play(){if(!worker||busy||timer||state?.complete)return;status='running';send('step');timer=setInterval(()=>{if(!busy)send('step')},1000);emit()},
    pause,
    step(){if(!worker||busy||status==='running'||state?.complete)return;send('step')},
    report(){return send('report')},acknowledge(alertId){return send('ack',{alertId})},export(){exportData=null;return send('export')},
    getState:snapshot,subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn)},
    dispose(){pause();worker?.terminate();worker=null;runId++;busy=false;listeners.clear()},
  };
}
let channel;
export const edgeAgent=createEdgeController({broadcast:message=>{
  // Publish only on this origin. There is deliberately no external transport.
  window.dispatchEvent(new CustomEvent('itron:edge-output',{detail:message}));
  try{channel??=new BroadcastChannel('itron-edge-headend-simulator');channel.postMessage(message)}catch{}
}});
if(typeof window!=='undefined')window.addEventListener('pagehide',event=>{if(!event.persisted){edgeAgent.dispose();channel?.close()}});
