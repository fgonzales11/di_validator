import {gatewayConfig} from './gateway-engine.mjs';
export function createGatewayController({workerFactory=()=>new Worker(new URL('./gateway-worker.js',import.meta.url),{type:'module'})}={}){
  let worker,timer,generation=0,id=0,busy=false,state=null,status='idle',error='',exportData=null;const listeners=new Set();
  const snapshot=()=>({state,status,busy,error,exportData}),emit=()=>listeners.forEach(fn=>fn(snapshot()));
  const pause=()=>{clearInterval(timer);timer=null;if(status==='running')status='paused';emit()};
  const send=(type,extra={})=>{if(!worker||busy)return false;busy=true;worker.postMessage({type,id:++id,generation,...extra});emit();return true};
  const fail=message=>{clearInterval(timer);timer=null;worker?.terminate();worker=null;busy=false;status='error';error=message;emit()};
  return {configure(input){const config=gatewayConfig(input);pause();worker?.terminate();generation++;id=0;busy=false;state=null;error='';exportData=null;status='loading';const current=generation;worker=workerFactory();worker.onmessage=({data})=>{if(current!==generation||data.generation!==generation||data.id!==id)return;busy=false;if(data.error){fail(data.error);return}state=data.state;if(data.exportData)exportData=data.exportData;if(status==='loading')status='ready';emit()};worker.onerror=e=>{if(current===generation)fail(e.message||'Gateway worker stopped. Apply settings to restart.')};send('configure',{config:{...input,...config}})},play(){if(!worker||busy||timer)return;status='running';send('step');timer=setInterval(()=>send('step'),250);emit()},pause,step(){return send('step')},action(kind,value){return send('action',{kind,value})},export(){exportData=null;return send('export')},subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn)},getState:snapshot,dispose(){pause();worker?.terminate();worker=null;generation++;listeners.clear()}};
}
export const gatewayAgent=createGatewayController();
if(typeof window!=='undefined')window.addEventListener('pagehide',e=>{if(!e.persisted)gatewayAgent.dispose()});
