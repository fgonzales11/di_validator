// Portable gateway control kernel. No browser, network or cloud dependencies.
export const GATEWAY_VERSION='1.0.0';
export const GATEWAY_DEFAULTS=Object.freeze({fleetSize:24,importLimitKw:300,exportLimitKw:30,responseKw:80,baseLoadKw:180,reservePct:20,wanLatencyMs:1200,reconnectSeconds:10});
export const GATEWAY_LIMITS=Object.freeze({vehicles:128,batteries:8,history:120,events:80,commands:32,uplink:24,pmuFrames:240,snippets:8});
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const finite=x=>typeof x==='number'&&Number.isFinite(x);
const size=x=>new TextEncoder().encode(JSON.stringify(x)).byteLength;
const bounded=(a,v,n)=>{a.push(v);if(a.length>n)a.splice(0,a.length-n)};
const wrap=x=>((x+180)%360+360)%360-180;
export function gatewayConfig(input={}){
  if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Gateway policy must be an object.');
  const c=Object.fromEntries(Object.keys(GATEWAY_DEFAULTS).map(k=>[k,input[k]===undefined?GATEWAY_DEFAULTS[k]:input[k]]));
  for(const [key,lo,hi] of [['fleetSize',1,128],['importLimitKw',0,1000],['exportLimitKw',0,300],['responseKw',0,500],['baseLoadKw',0,800],['reservePct',5,80],['wanLatencyMs',0,10000],['reconnectSeconds',3,60]])if(!finite(c[key])||c[key]<lo||c[key]>hi)throw Error(`Invalid ${key}: use ${lo}–${hi}.`);
  if(!Number.isInteger(c.fleetSize))throw Error('Fleet size must be a whole number.');
  return c;
}
// Weighted max-min sharing redistributes unused headroom until all caps bind.
export function allocatePower(items,budget){
  const result=items.map(()=>0);let remaining=Math.max(0,budget),active=items.map((_,i)=>i).filter(i=>items[i].cap>0);
  for(let round=0;round<=items.length&&active.length&&remaining>1e-9;round++){
    const weight=active.reduce((s,i)=>s+Math.max(.001,items[i].weight||1),0),before=remaining;
    for(const i of active){const amount=Math.min(items[i].cap-result[i],before*Math.max(.001,items[i].weight||1)/weight);result[i]+=amount;remaining-=amount}
    active=active.filter(i=>items[i].cap-result[i]>1e-8);
  }
  return result;
}
export function createPMUMonitor({startTimestamp=null}={}){
  const timestamps=new Float64Array(GATEWAY_LIMITS.pmuFrames),frequency=new Float64Array(timestamps.length),voltage=new Float64Array(timestamps.length),angle=new Float64Array(timestamps.length);
  let cursor=0,count=0,last=null,watermark=-Infinity,observedTimestamp=startTimestamp,received=0,valid=0,rejected=0,missing=0,inputBytes=0,outputBytes=0,bad=0,good=0,active=false,firstBad=null,sequence=0,window=[];const events=[],snippets=[];
  function ingest(frames,expectedEnd){
    if(!Array.isArray(frames)||frames.length>240)throw Error('PMU batch must contain at most 240 frames.');
    const newEvents=[];
    for(const raw of frames){
      const frame={timestamp:raw?.timestamp,frequencyHz:raw?.frequencyHz,voltagePu:raw?.voltagePu,angleDeg:raw?.angleDeg};
      received++;inputBytes+=size(frame);
      // Missing-slot accounting survives bad values; derivative continuity does not.
      if(finite(frame.timestamp)&&frame.timestamp>=(observedTimestamp??-Infinity)){
        if(observedTimestamp!==null)missing+=Math.max(0,Math.round((frame.timestamp-observedTimestamp)*60/1000)-1);
        observedTimestamp=frame.timestamp;
      }
      if(!frame||!['timestamp','frequencyHz','voltagePu','angleDeg'].every(k=>finite(frame[k]))||frame.voltagePu<0||frame.frequencyHz<=0||frame.frequencyHz>120||frame.timestamp<=watermark){rejected++;bad=0;good=0;last=null;continue}
      const delta=last?(frame.timestamp-last.timestamp)/1000:null,contiguous=delta!==null&&Math.abs(delta-1/60)<.004;
      const rocof=contiguous?(frame.frequencyHz-last.frequencyHz)/delta:null,phaseStep=contiguous?wrap(frame.angleDeg-last.angleDeg):null;
      const unusual=Math.abs(frame.frequencyHz-60)>.2||frame.voltagePu<.9||frame.voltagePu>1.1||rocof!==null&&Math.abs(rocof)>1||phaseStep!==null&&Math.abs(phaseStep)>30;
      if(!contiguous){bad=0;good=0;firstBad=null}
      valid++;timestamps[cursor]=frame.timestamp;frequency[cursor]=frame.frequencyHz;voltage[cursor]=frame.voltagePu;angle[cursor]=frame.angleDeg;cursor=(cursor+1)%timestamps.length;count=Math.min(count+1,timestamps.length);
      const sample={...frame,rocofHzS:rocof};bounded(window,sample,60);
      for(const snippet of snippets)if(snippet.samples.length<36&&frame.timestamp>snippet.detectedAt)snippet.samples.push(sample);
      if(unusual){if(bad===0)firstBad=frame.timestamp;bad++;good=0}else{good++;bad=0;firstBad=null}
      if(!active&&bad>=3){
        active=true;const event={id:`PMU-${++sequence}`,kind:'pmu_event',timestamp:frame.timestamp,frequencyHz:frame.frequencyHz,voltagePu:frame.voltagePu,rocofHzS:rocof,detectedAfterMs:frame.timestamp-firstBad,message:'Persistent phasor disturbance detected locally (3 valid consecutive frames).'};
        bounded(events,event,80);bounded(snippets,{id:event.id,detectedAt:frame.timestamp,samples:window.slice(-12)},GATEWAY_LIMITS.snippets);newEvents.push(event);
      }
      if(active&&good>=12){active=false;const event={id:`PMU-${++sequence}`,kind:'pmu_clear',timestamp:frame.timestamp,message:'Phasor measurements returned within the configured screening band.'};bounded(events,event,80);newEvents.push(event)}
      last=frame;watermark=frame.timestamp;
    }
    if(finite(expectedEnd)&&observedTimestamp!==null&&expectedEnd>observedTimestamp){
      const trailing=Math.max(0,Math.floor((expectedEnd-observedTimestamp)*60/1000+1e-7));
      missing+=trailing;observedTimestamp=expectedEnd;if(trailing){bad=0;good=0;last=null;firstBad=null}
    }
    return newEvents;
  }
  function summary(){
    const result={frames:window.length,from:window[0]?.timestamp??null,to:window.at(-1)?.timestamp??null,minVoltagePu:window.length?Math.min(...window.map(x=>x.voltagePu)):null,maxVoltagePu:window.length?Math.max(...window.map(x=>x.voltagePu)):null,meanFrequencyHz:window.length?window.reduce((s,x)=>s+x.frequencyHz,0)/window.length:null,maxAbsRocofHzS:window.some(x=>x.rocofHzS!==null)?Math.max(...window.map(x=>Math.abs(x.rocofHzS||0))):null,disturbance:active,contiguousHealthyFrames:good,missing,rejected};return result;
  }
  return {ingest,summary,completedSnippets(){return snippets.filter(s=>s.samples.length===36&&!s.emitted).map(s=>{s.emitted=true;return {id:s.id,detectedAt:s.detectedAt,samples:[...s.samples]}})},recordOutput(message){outputBytes+=size(message)},snapshot(){return {...summary(),received,valid,rejected,missing,inputBytes,outputBytes,reductionPct:inputBytes?100*(1-outputBytes/inputBytes):0,modelBufferBytes:timestamps.byteLength*4,events:[...events],snippets:snippets.map(s=>({...s,samples:[...s.samples]})),series:Array.from({length:count},(_,i)=>{const j=(cursor-count+i+timestamps.length)%timestamps.length;return {timestamp:timestamps[j],frequencyHz:frequency[j],voltagePu:voltage[j]}})}}};
}
export function createGateway(options={}){
  const config=gatewayConfig(options),scope={id:options.networkId||'AP-DEMO',name:options.networkName||'Local access point'};
  const vehicles=Array.from({length:config.fleetSize},(_,i)=>({id:`EV-${String(i+1).padStart(3,'0')}`,maxKw:i%4===0?22:11,remainingKwh:i<4?.25+i*.12:4+(i%6),initialKwh:i<4?.25+i*.12:4+(i%6),departureSeconds:i<4?150+i*45:1800+(i%6)*300,connected:true,deliveredKwh:0,powerKw:0,missed:false}));
  const batteries=Array.from({length:8},(_,i)=>({id:`BESS-${i+1}`,capacityKwh:60,energyKwh:36+i,maxKw:25,consent:true,connected:true,gridForming:i===0,lastKw:0,powerKw:0}));
  const solar=Array.from({length:8},(_,i)=>({id:`PV-${i+1}`,maxKw:20,connected:true,consent:true,availableKw:0,powerKw:0}));
  const flex=Array.from({length:4},(_,i)=>({id:`FLEX-${i+1}`,maxKw:config.baseLoadKw*.35/4,consent:true,connected:true,powerKw:0}));
  const pmu=createPMUMonitor({startTimestamp:0}),history=[],events=[],commands=[],uplink=[];let seconds=0,cycles=0,mode='grid-connected',dwell=0,seq=0,lastPlan=null,angle=0,pmuUntil=0,peak=false;
  const condition={wanOnline:true,gridAvailable:true,solarFactor:1,syncAngleDeg:2};
  const stats={localCyclesOffline:0,commandsIssued:0,commandsApplied:0,uplinkSent:0,uplinkQueued:0,uplinkDropped:0,uplinkBytes:0,cloudStaleSeconds:0,unservedKwh:0,deadlineMisses:0,evDeliveredKwh:0};
  const log=(kind,message,extra={})=>bounded(events,{id:`GW-${++seq}`,timestamp:seconds,kind,message,...extra},GATEWAY_LIMITS.events);
  const setpoints=(plan)=>[
    ...vehicles.map(v=>({assetId:v.id,type:'ev_charge',kw:v.powerKw})),
    ...batteries.map(b=>({assetId:b.id,type:'battery',kw:b.powerKw})),
    ...solar.map(p=>({assetId:p.id,type:'pv',kw:p.powerKw})),
    ...flex.map(f=>({assetId:f.id,type:'flex_shed',kw:f.powerKw})),
    {assetId:'PCC',type:'pcc',position:plan.pccClosed?'closed':'open'}];
  function action(kind,value){
    if(kind==='wan'){condition.wanOnline=Boolean(value);log('connection',condition.wanOnline?'Headend link restored; queued summaries will synchronize.':'Headend link lost; local dispatch remains active.')}
    else if(kind==='grid'){condition.gridAvailable=Boolean(value);log('grid',condition.gridAvailable?'Upstream supply restored. Reconnection still requires stable synchronization.':'Upstream supply lost. Local island supervision requested.')}
    else if(kind==='pmu'){pmuUntil=seconds+6;log('scenario','Injected a six-second synthetic frequency disturbance.')}
    else if(kind==='solar'){condition.solarFactor=value?1:.15;log('scenario',value?'Solar availability restored.':'Cloud cover reduced simulated solar output.')}
    else if(kind==='peak'){peak=Boolean(value);log('scenario',peak?'Local base load increased by 45%.':'Base load returned to normal.')}
    else if(kind==='der'){const b=batteries.find(b=>b.id===value);if(!b)throw Error('Unknown battery.');b.consent=!b.consent;log('consent',`${b.id} ${b.consent?'rejoined':'withdrew from'} aggregation.`)}
    else if(kind==='sync'){if(!finite(value))throw Error('Invalid phase difference');condition.syncAngleDeg=value}
    else throw Error('Unknown gateway action.');
  }
  function step(telemetry){
    if(arguments.length&&(!telemetry||typeof telemetry!=='object'||Array.isArray(telemetry)))throw Error('Explicit adapter telemetry must be an object.');
    // Adapter input is explicit and complete. Model telemetry is generated only
    // when the caller omits the input, never to fill holes in an external packet.
    if(telemetry){
      if(!finite(telemetry.timestamp)||telemetry.timestamp!==seconds+1||!finite(telemetry.baseLoadKw)||telemetry.baseLoadKw<0||telemetry.baseLoadKw>2000||!finite(telemetry.solarFactor)||telemetry.solarFactor<0||telemetry.solarFactor>1||typeof telemetry.gridAvailable!=='boolean'||typeof telemetry.wanOnline!=='boolean'||!finite(telemetry.syncAngleDeg)||!Array.isArray(telemetry.pmuFrames)||telemetry.pmuFrames.length>240)throw Error('Invalid adapter telemetry: provide the next one-second timestamp, base load, solar fraction, grid/WAN states, synchronization angle and bounded PMU frames.');
      if(telemetry.pmuFrames.some(f=>!finite(f?.timestamp)||f.timestamp<=seconds*1000||f.timestamp>(seconds+1)*1000))throw Error('PMU timestamps must lie inside the current one-second adapter interval.');
      condition.gridAvailable=telemetry.gridAvailable;condition.wanOnline=telemetry.wanOnline;condition.solarFactor=telemetry.solarFactor;condition.syncAngleDeg=telemetry.syncAngleDeg;
    }
    seconds++;cycles++;
    const disturbance=seconds<=pmuUntil,frames=telemetry?telemetry.pmuFrames:Array.from({length:60},(_,i)=>{const time=(seconds-1)+(i+1)/60,f=60+(disturbance?-.6:.008*Math.sin(time*2));angle=wrap(angle+360*(f-60)/60);return {timestamp:time*1000,frequencyHz:f,voltagePu:disturbance?.94:1+.003*Math.sin(time),angleDeg:angle}});
    const pmuEvents=pmu.ingest(frames,seconds*1000);for(const event of pmuEvents)log(event.kind,event.message,{detail:event});
    const measurement=pmu.summary(),syncOk=measurement.frames===60&&measurement.contiguousHealthyFrames>=60&&!measurement.disturbance&&measurement.to>=seconds*1000-20&&measurement.to<=seconds*1000&&measurement.meanFrequencyHz!==null&&Math.abs(measurement.meanFrequencyHz-60)<.1&&measurement.minVoltagePu>=.97&&measurement.maxVoltagePu<=1.03&&Math.abs(wrap(condition.syncAngleDeg))<=5;
    const forming=batteries.some(b=>b.gridForming&&b.connected&&b.consent&&b.energyKwh>b.capacityKwh*config.reservePct/100+.0001);
    const previousMode=mode;
    if(!condition.gridAvailable){dwell=0;mode=previousMode==='grid-connected'?'islanding':forming?'islanded':'deenergized'}
    else if(mode!=='grid-connected'){
      if(syncOk){dwell++;mode=dwell>=config.reconnectSeconds?'grid-connected':'resynchronizing'}else{dwell=0;mode=forming?'islanded':'deenergized'}
    }
    if(previousMode!==mode)log('microgrid',`${previousMode} → ${mode}. ${mode==='grid-connected'?'Synchronization dwell satisfied.':'Point of connection remains open.'}`);
    const pccClosed=mode==='grid-connected',energized=pccClosed||forming;
    const baseLoad=telemetry?telemetry.baseLoadKw:config.baseLoadKw*(peak?1.45:1)*(1+.025*Math.sin(seconds/15)),criticalLoad=baseLoad*.65,flexLoad=baseLoad-criticalLoad;
    for(const p of solar)p.availableKw=energized&&p.connected&&p.consent?p.maxKw*condition.solarFactor*(.8+.03*Math.sin(seconds/20)):0;
    let pvAvailable=solar.reduce((s,p)=>s+p.availableKw,0),pvUsed=pvAvailable;
    const capabilities=batteries.map(b=>({discharge:b.connected&&b.consent?Math.max(0,Math.min(b.maxKw,(b.energyKwh-b.capacityKwh*config.reservePct/100)*3600*.95)):0,charge:b.connected&&b.consent?Math.max(0,Math.min(b.maxKw,(b.capacityKwh-b.energyKwh)*3600/.95)):0}));
    const maxDischarge=capabilities.reduce((s,b)=>s+b.discharge,0),flexCaps=flex.map(f=>f.connected&&f.consent?Math.min(f.maxKw,flexLoad/4):0),maxFlex=flexCaps.reduce((s,v)=>s+v,0);
    let flexShed=energized?Math.min(maxFlex,pccClosed?config.responseKw:Math.max(0,baseLoad-pvAvailable-maxDischarge)):0;
    const targetItems=vehicles.map(v=>{const left=v.departureSeconds-seconds,cap=v.connected&&left>=0?Math.min(v.maxKw,v.remainingKwh*3600/.92):0;return {cap,weight:1+Math.min(20,left>0?v.remainingKwh*3600/(left*v.maxKw*.92):0)}});
    const requestedEv=targetItems.reduce((s,v)=>s+v.cap,0);
    const evBudget=pccClosed?Math.max(0,config.importLimitKw+pvAvailable+maxDischarge-(baseLoad-flexShed)):0;
    const allocation=allocatePower(targetItems,evBudget);vehicles.forEach((v,i)=>v.powerKw=allocation[i]);
    const evKw=allocation.reduce((s,v)=>s+v,0),netBeforeBattery=baseLoad-flexShed+evKw-pvAvailable;
    let batteryTarget=pccClosed?Math.max(netBeforeBattery-config.importLimitKw,config.responseKw-flexShed):netBeforeBattery;
    if(!energized){batteryTarget=0;pvUsed=0}
    if(batteryTarget>0)batteryTarget=Math.max(0,Math.min(maxDischarge,batteryTarget,baseLoad-flexShed+evKw+(pccClosed?config.exportLimitKw:0)));
    // Discharge may require PV curtailment, but never export beyond the limit even with all PV off.
    else batteryTarget=-Math.min(-batteryTarget,capabilities.reduce((s,b)=>s+b.charge,0));
    const batteryAlloc=allocatePower(capabilities.map(c=>({cap:batteryTarget>=0?c.discharge:c.charge,weight:1})),Math.abs(batteryTarget));
    batteries.forEach((b,i)=>{b.powerKw=(batteryTarget>=0?1:-1)*batteryAlloc[i];b.energyKwh=clamp(b.energyKwh-(b.powerKw>=0?b.powerKw/.95:b.powerKw*.95)/3600,0,b.capacityKwh);b.lastKw=b.powerKw});
    const batteryKw=batteries.reduce((s,b)=>s+b.powerKw,0);
    let deficit=energized?Math.max(0,baseLoad-flexShed+evKw-pvUsed-batteryKw-(pccClosed?config.importLimitKw:0)):baseLoad;
    if(deficit>0&&energized){const extraFlex=Math.min(maxFlex-flexShed,deficit);flexShed+=extraFlex;deficit-=extraFlex}
    // Emergency unserved power is explicit; no hidden import while islanded.
    const unservedKw=deficit,servedBase=energized?Math.max(0,baseLoad-flexShed-unservedKw):0;
    let gridKw=servedBase+evKw-pvUsed-batteryKw;
    const exportLimit=pccClosed?config.exportLimitKw:0;
    if(gridKw< -exportLimit){const curtailed=Math.min(pvUsed,-exportLimit-gridKw);pvUsed-=curtailed;gridKw+=curtailed}
    if(Math.abs(gridKw)<1e-7)gridKw=0;
    const curtailment=pvAvailable-pvUsed;solar.forEach(p=>p.powerKw=pvAvailable?p.availableKw*pvUsed/pvAvailable:0);
    const flexAllocation=allocatePower(flexCaps.map(cap=>({cap,weight:1})),flexShed);flex.forEach((f,i)=>f.powerKw=flexAllocation[i]);
    let risk=0;for(const v of vehicles){const delivered=Math.min(v.remainingKwh,v.powerKw*.92/3600);v.remainingKwh-=delivered;v.deliveredKwh+=delivered;stats.evDeliveredKwh+=delivered;if(v.departureSeconds<=seconds&&v.remainingKwh>.001&&!v.missed){v.missed=true;stats.deadlineMisses++;log('ev_deadline',`${v.id} departed with ${v.remainingKwh.toFixed(3)} kWh unmet.`)}if(v.remainingKwh>.001&&(v.departureSeconds-seconds)*v.maxKw*.92/3600<v.remainingKwh)risk++}
    stats.unservedKwh+=unservedKw/3600;
    const achievedResponse=flexShed+batteryKw-curtailment,residualResponse=pccClosed?Math.max(0,config.responseKw-achievedResponse):null;
    lastPlan={timestamp:seconds,mode,pccClosed,energized,syncDwellSeconds:dwell,baseLoadKw:baseLoad,criticalLoadKw:criticalLoad,servedBaseKw:servedBase,flexShedKw:flexShed,unservedKw,criticalUnservedKw:Math.min(criticalLoad,Math.max(0,unservedKw-(flexLoad-flexShed))),requestedEvKw:requestedEv,evKw,evAtRisk:risk,pvAvailableKw:pvAvailable,pvUsedKw:pvUsed,curtailedPvKw:curtailment,batteryKw,gridKw,requestedResponseKw:pccClosed?config.responseKw:null,achievedResponseKw:achievedResponse,responseShortfallKw:residualResponse,balanceResidualKw:gridKw+pvUsed+batteryKw-servedBase-evKw};
    const dispatch={id:`DISPATCH-${cycles}`,timestamp:seconds,validUntil:seconds+2,source:'Local gateway',setpoints:setpoints(lastPlan),application:telemetry?'Adapter commands proposed; acknowledgment required':'Applied to simulation'};
    stats.commandsIssued+=dispatch.setpoints.length;if(!telemetry)stats.commandsApplied+=dispatch.setpoints.length;
    bounded(commands,dispatch,GATEWAY_LIMITS.commands);
    const report={id:`SUMMARY-${cycles}`,timestamp:seconds,pmu:measurement,pmuEvents,eventSnippets:pmu.completedSnippets(),dispatch:{mode,gridKw,evKw,batteryKw,unservedKw},provenance:telemetry?'Adapter telemetry with modeled energy assets':'Synthetic access-point simulation'};
    pmu.recordOutput({summary:report.pmu,events:report.pmuEvents,snippets:report.eventSnippets});
    if(condition.wanOnline){for(const queued of uplink){stats.uplinkSent++;stats.uplinkBytes+=size(queued)}uplink.length=0;stats.uplinkSent++;stats.uplinkBytes+=size(report);stats.cloudStaleSeconds=config.wanLatencyMs/1000}
    else{stats.localCyclesOffline++;stats.cloudStaleSeconds++;if(uplink.length===GATEWAY_LIMITS.uplink){uplink.shift();stats.uplinkDropped++}uplink.push(report);stats.uplinkQueued++}
    bounded(history,{timestamp:seconds,gridKw,evKw,batteryKw,pvKw:pvUsed,mode,frequencyHz:measurement.meanFrequencyHz},GATEWAY_LIMITS.history);
    return snapshot();
  }
  function snapshot(){return {version:GATEWAY_VERSION,scope,config:{...config},seconds,cycles,mode,condition:{...condition,peak},plan:lastPlan,vehicles:vehicles.map(v=>({...v})),batteries:batteries.map(b=>({...b,socPct:100*b.energyKwh/b.capacityKwh})),solar:solar.map(p=>({...p})),flex:flex.map(f=>({...f})),pmu:pmu.snapshot(),stats:{...stats},history:[...history],events:[...events],lastCommand:commands.at(-1)||null,uplink:{pending:uplink.length,limit:GATEWAY_LIMITS.uplink},limits:GATEWAY_LIMITS}}
  return {step,action,snapshot,export(){return {...snapshot(),commands:[...commands],queuedSummaries:[...uplink],provenance:{telemetry:'Synthetic access-point resource models unless adapter telemetry is explicitly provided.',gridScope:'SMARTDS network name provides study context only; no surveyed AP grouping or measured EV/DER inventory.',pmu:'60 frames/s generated phasors, separate from 15-minute AMI profiles.',control:'Supervisory active-power simulation. No protection certification, AC stability model, equipment driver or physical actuation.',bandwidth:'Encoded JSON PMU input compared with summary/event payloads; excludes transport headers.',runtime:'Portable dependency-free JavaScript kernel; browser Worker or Node gateway process.'}}}};
}
