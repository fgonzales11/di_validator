import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,readFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {execFileSync,spawn} from 'node:child_process';
import {createAdapterGateway,validateGatewayInventory} from './gateway-adapter.mjs';
const epoch=1790812800000;
const inventory={pcc:{id:'AP-5/PCC'},vehicles:[{id:'Depot/charger-A',maxKw:11,chargeEfficiency:.92}],batteries:[{id:'Community/BESS',capacityKwh:40,maxChargeKw:20,maxDischargeKw:20,chargeEfficiency:.95,dischargeEfficiency:.95,gridForming:true}],solar:[{id:'Roof/PV',maxKw:20}],flex:[{id:'Building/HVAC',maxKw:15}]};
function frames(end,duration=1000){return Array.from({length:Math.round(duration*60/1000)},(_,i)=>({timestamp:end-duration+(i+1)*1000/60,frequencyHz:60,voltagePu:1,angleDeg:0}))}
function telemetry(at=epoch,sequence=1,extra={}){
  const common={observedAtMs:at,connected:true,consent:true,actualKw:0};
  return {sessionId:'session-test',sequence,observedAtMs:at,baseLoadKw:40,criticalLoadKw:25,gridAvailable:true,wanOnline:true,syncAngleDeg:0,pcc:{observedAtMs:at,position:'closed',powerKw:40,busEnergized:true},interlocks:{canOpen:true,canClose:true,canIsland:true,trip:false},devices:[
    {...common,assetId:'Depot/charger-A',availableKw:11,remainingKwh:10,deliveredKwh:0,departureAtMs:epoch+60000,chargeSessionId:'vehicle-session'},
    {...common,assetId:'Community/BESS',energyKwh:30,availableChargeKw:20,availableDischargeKw:20,gridFormingActive:false},
    {...common,assetId:'Roof/PV',availableKw:12},
    {...common,assetId:'Building/HVAC',availableKw:10},
  ],pmuFrames:frames(at),...extra};
}
function fixture(policy={}){let now=epoch;const g=createAdapterGateway({sessionId:'session-test',inventory,policy:{responseKw:10,...policy},clock:()=>now});return {g,setTime(t){now=t},step(t=epoch,seq=1,extra={}){now=t;return g.step(telemetry(t,seq,extra))}}}
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-6,`${a} != ${b}`);
function ack(s,point,extra={}){return {sessionId:s.scope.sessionId,dispatchId:s.lastCommand.id,assetId:point.assetId,commandType:point.type,status:'applied',atMs:s.lastCommand.issuedAtMs,appliedValue:'kw'in point?point.kw:'position'in point?point.position:point.enabled,...extra}}

test('equipment inventory is validated and owned; empty classes and no synthetic fallback are supported',()=>{
  for(const broken of [{},{...inventory,pcc:{}},{...inventory,solar:[{id:inventory.pcc.id,maxKw:20}]},{...inventory,batteries:[{...inventory.batteries[0],capacityKwh:NaN}]},{...inventory,vehicles:[{id:'X'.repeat(129),maxKw:10}]}])assert.throws(()=>validateGatewayInventory(broken));
  const copy=structuredClone(inventory),g=createAdapterGateway({sessionId:'owned',inventory:copy,clock:()=>epoch});copy.batteries[0].capacityKwh=100;
  const s=g.snapshot();assert.equal(s.inventory.batteries[0].capacityKwh,40);s.inventory.batteries[0].capacityKwh=1;assert.equal(g.snapshot().inventory.batteries[0].capacityKwh,40);
  assert.throws(()=>g.step(),/telemetry/);assert.throws(()=>g.action('grid',false),/Scenario/);
  const empty=createAdapterGateway({sessionId:'session-test',inventory:{pcc:inventory.pcc,vehicles:[],batteries:[],solar:[],flex:[]},clock:()=>epoch});
  assert.equal(empty.step(telemetry(epoch,1,{devices:[]})).inventory.vehicles.length,0);
});

test('dispatch uses measured availability and leaves energy and delivered counters unchanged',()=>{
  const f=fixture({importLimitKw:5}),t=telemetry();t.devices[0].remainingKwh=.001;
  let s=f.g.step(t);assert.ok(s.plan.predicted.feasible);near(s.plan.predicted.balanceResidualKw,0);assert.ok(s.plan.predicted.gridKw<=5+1e-6);
  const ev=s.lastCommand.setpoints.find(x=>x.type==='ev_charge');assert.ok(ev.kw*2*.92/3600<=.001+1e-9);
  assert.equal(s.observed.devices[1].energyKwh,30);assert.equal(s.observed.devices[0].deliveredKwh,0);
  f.g.acknowledge(ack(s,ev));s=f.g.snapshot();assert.equal(s.observed.devices[0].remainingKwh,.001);assert.equal(s.stats.reportedAppliedCommands,1);
  t.devices[1].energyKwh=1;s.observed.devices[1].energyKwh=1;assert.equal(f.g.snapshot().observed.devices[1].energyKwh,30);
  f.setTime(epoch+1000);const next=telemetry(epoch+1000,2);next.devices[1].energyKwh=2;s=f.g.step(next);
  assert.ok(s.lastCommand.setpoints.find(x=>x.type==='battery').kw<=0);assert.equal(s.observed.devices[1].energyKwh,2);
});

test('malformed frames reject atomically; missing, stale, and uncontrolled feedback inhibit dispatch',()=>{
  const f=fixture(),before=f.g.snapshot();
  for(const t of [telemetry(epoch,1,{sessionId:'foreign'}),telemetry(epoch,1,{pmuFrames:[{timestamp:epoch+1}]}),telemetry(epoch,1,{devices:[...telemetry().devices,telemetry().devices[0]]})])assert.throws(()=>f.g.step(t));
  assert.deepEqual(f.g.snapshot(),before);
  let s=f.step(epoch,1,{devices:telemetry().devices.slice(1)});assert.equal(s.mode,'feedback-hold');assert.equal(s.plan.predicted,null);assert.deepEqual(s.lastCommand.setpoints,[]);
  let t=telemetry(epoch+5000,7);t.devices[1].observedAtMs=epoch;s=f.step(epoch+5000,7,t);assert.equal(s.sequence,7);assert.equal(s.plan.controlReady,false);assert.match(s.plan.holdReasons.join(' '),/Stale/);
  t=telemetry(epoch+6000,8);t.devices[2].consent=false;t.devices[2].actualKw=5;s=f.step(epoch+6000,8,t);assert.equal(s.plan.controlReady,false);assert.match(s.plan.holdReasons.join(' '),/Uncontrolled/);
  t=telemetry(epoch+7000,9);t.devices[2].consent=false;s=f.step(epoch+7000,9,t);assert.equal(s.plan.controlReady,true);assert.ok(!s.lastCommand.setpoints.some(x=>x.assetId==='Roof/PV'));
  s=f.step(epoch+8000,10,{pcc:{...telemetry(epoch+8000).pcc,observedAtMs:epoch+6000}});assert.equal(s.mode,'feedback-hold');
});

test('islanding waits for observed opening and grid formation; acknowledgments never overwrite measurements',()=>{
  const f=fixture();let s=f.step(epoch,1,{gridAvailable:false});assert.equal(s.mode,'open-pending');
  assert.ok(!s.lastCommand.setpoints.some(x=>x.type==='grid_forming'&&x.enabled));
  const open=s.lastCommand.setpoints.find(x=>x.type==='pcc');f.g.acknowledge(ack(s,open));assert.equal(f.g.snapshot().observed.pcc.position,'closed');
  s=f.step(epoch+1000,2,{gridAvailable:false});assert.equal(s.mode,'open-pending');
  const t=telemetry(epoch+2000,3,{gridAvailable:false,baseLoadKw:10,criticalLoadKw:5});t.pcc.position='open';t.pcc.powerKw=0;t.pcc.busEnergized=false;
  s=f.step(epoch+2000,3,t);assert.equal(s.mode,'island-starting');assert.equal(s.lastCommand.setpoints.find(x=>x.type==='grid_forming').enabled,true);assert.equal(s.lastCommand.setpoints.find(x=>x.type==='battery').kw,0);
  const formed=telemetry(epoch+3000,4,{gridAvailable:false,baseLoadKw:10,criticalLoadKw:5});formed.pcc.position='open';formed.pcc.powerKw=0;formed.devices[1].gridFormingActive=true;
  s=f.step(epoch+3000,4,formed);assert.equal(s.mode,'islanded');assert.equal(s.plan.predicted.gridKw,0);assert.equal(s.plan.predicted.evKw,0);assert.equal(s.plan.predicted.feasible,true);near(s.plan.predicted.balanceResidualKw,0);
});

test('reconnect dwell uses elapsed measured time, resets across phasor gaps, and waits for observed closure',()=>{
  const f=fixture({reconnectSeconds:3});
  const island=(time,seq,dt,extra={})=>{const t=telemetry(time,seq,{pmuFrames:frames(time,dt),...extra});t.pcc.position='open';t.pcc.powerKw=0;t.devices[1].gridFormingActive=true;return t};
  f.step(epoch,1,island(epoch,1,1000,{gridAvailable:false}));
  let s;for(let i=1;i<=29;i++){s=f.step(epoch+i*100,1+i,island(epoch+i*100,1+i,100));assert.notEqual(s.mode,'close-pending')}
  assert.ok(s.plan.syncDwellSeconds<3);
  s=f.step(epoch+3000,31,island(epoch+3000,31,100));assert.equal(s.mode,'close-pending');
  const close=s.lastCommand.setpoints.find(x=>x.type==='pcc');assert.equal(close.position,'closed');f.g.acknowledge(ack(s,close));assert.equal(f.g.snapshot().observed.pcc.position,'open');
  s=f.step(epoch+4000,32,island(epoch+4000,32,1000));assert.equal(s.mode,'close-pending');
  s=f.step(epoch+5000,33);assert.equal(s.mode,'grid-connected');
  s=f.step(epoch+6000,34,island(epoch+6000,34,1000,{pmuFrames:[]}));assert.equal(s.plan.syncDwellSeconds,0);
  s=f.step(epoch+12000,40,island(epoch+12000,40,1000));assert.equal(s.plan.syncDwellSeconds,0);assert.ok(s.pmu.missing>=360);
});

test('acknowledgments are scoped, value checked, idempotent, and expire without further telemetry',()=>{
  const f=fixture();const s=f.step(),point=s.lastCommand.setpoints.find(x=>x.type==='battery'),receipt=ack(s,point);
  assert.throws(()=>f.g.acknowledge({...receipt,sessionId:'old-session'}),/session/);
  assert.throws(()=>f.g.acknowledge({...receipt,appliedValue:999}),/value/);
  f.g.acknowledge(receipt);f.g.acknowledge(receipt);assert.equal(f.g.snapshot().stats.reportedAppliedCommands,1);
  assert.throws(()=>f.g.acknowledge({...receipt,status:'rejected'}),/Conflicting/);
  const pv=s.lastCommand.setpoints.find(x=>x.type==='pv');f.setTime(epoch+3000);assert.equal(f.g.snapshot().lastCommand.expired,true);
  assert.throws(()=>f.g.acknowledge(ack(s,pv)),/expired/);assert.equal(f.g.snapshot().stats.reportedAppliedCommands,1);
  const next=f.step(epoch+3000,5);assert.throws(()=>f.g.acknowledge(ack(s,pv)),/superseded/);assert.equal(next.observed.devices[1].energyKwh,30);
});

test('wall-clock freshness, bus energization, and coupled leases cannot grant fictitious headroom',()=>{
  const f=fixture();f.setTime(epoch+2000);const old=telemetry(epoch+1000);for(const d of old.devices)d.observedAtMs=epoch;old.pcc.observedAtMs=epoch;
  let s=f.g.step(old);assert.equal(s.plan.controlReady,false);assert.match(s.plan.holdReasons.join(' '),/Stale.*PCC/);
  const dead=telemetry(epoch+2000,2);dead.pcc.busEnergized=false;s=f.g.step(dead);assert.equal(s.plan.controlReady,false);assert.deepEqual(s.lastCommand.setpoints,[]);
  const coupled=fixture({importLimitKw:0,exportLimitKw:0,responseKw:500});const t=telemetry(epoch,1,{baseLoadKw:0,criticalLoadKw:0});t.pcc.powerKw=0;t.devices[2].availableKw=0;t.devices[0].departureAtMs=epoch+500;
  s=coupled.g.step(t);assert.ok(s.plan.predicted.evKw>0);near(s.plan.predicted.evKw,s.plan.predicted.batteryKw);
  assert.equal(s.lastCommand.validUntilMs,epoch+500);assert.ok(s.lastCommand.setpoints.every(p=>p.validUntilMs===epoch+500));
  coupled.setTime(epoch+501);assert.equal(coupled.g.snapshot().lastCommand.expired,true);
  const reserve=fixture();reserve.setTime(epoch+1000);const island=telemetry(epoch+1000,1,{gridAvailable:false});island.pcc.position='open';island.pcc.powerKw=0;island.pcc.busEnergized=false;island.devices[1].energyKwh=8.001;island.devices[1].observedAtMs=epoch;
  s=reserve.g.step(island);assert.equal(s.mode,'deenergized');assert.equal(s.lastCommand.setpoints.find(p=>p.type==='grid_forming').enabled,false);
});

test('infeasible grid and island budgets stay explicit instead of inventing load shedding',()=>{
  const f=fixture({importLimitKw:0,responseKw:500});let s=f.step(epoch,1,{baseLoadKw:1000,criticalLoadKw:1000});
  assert.equal(s.plan.predicted.feasible,false);assert.ok(s.plan.predicted.importViolationKw>900);assert.ok(s.plan.predicted.gridKw>900);assert.equal(s.plan.predicted.flexShedKw,0);
  const t=telemetry(epoch+1000,2,{gridAvailable:false,baseLoadKw:1000,criticalLoadKw:1000});t.pcc.position='open';t.pcc.powerKw=0;t.devices[1].gridFormingActive=true;
  s=f.step(epoch+1000,2,t);assert.equal(s.plan.predicted.feasible,false);assert.equal(s.plan.predicted.gridKw,0);assert.ok(s.plan.predicted.balanceResidualKw< -900);assert.ok(s.plan.predicted.criticalUnservedKw>900);
});

test('deadline gaps are unknown and WAN recovery emits only bounded monitoring summaries',()=>{
  const f=fixture();let t=telemetry();t.devices[0].departureAtMs=epoch+500;f.step(epoch,1,t);
  t=telemetry(epoch+5000,3);t.devices[0].departureAtMs=epoch+500;t.devices[0].remainingKwh=0;let s=f.step(epoch+5000,3,t);assert.equal(s.deadlineOutcomes[0].outcome,'unknown');
  const offline=fixture();for(let i=0;i<40;i++)offline.step(epoch+i*1000,i+1,{wanOnline:false});s=offline.g.snapshot();assert.equal(s.stats.localCyclesOffline,40);assert.equal(s.uplink.pending,24);assert.equal(s.stats.summariesDropped,16);assert.deepEqual(offline.g.drainSummaries(),[]);
  s=offline.step(epoch+40000,41,{wanOnline:true});const summaries=offline.g.drainSummaries();assert.equal(summaries.length,24);assert.ok(summaries.every(x=>!('setpoints'in x)));assert.equal(s.lastCommand.sequence,41);assert.equal(offline.g.snapshot().uplink.pending,0);assert.equal(offline.g.export().commands.length,32);
});

test('packaged adapter runtime accepts real inventory and feedback with session-fenced proposals', {timeout:10000},async()=>{
  const dir=mkdtempSync(join(tmpdir(),'gateway-adapter-test-'));execFileSync('tar',['-xzf',new URL('../public/gateway/gateway-runtime.tar.gz',import.meta.url).pathname,'-C',dir]);
  const child=spawn(process.execPath,[join(dir,'gateway-runner.mjs')],{stdio:['pipe','pipe','pipe']});
  let output='',waiter,stderr='';child.stderr.on('data',c=>stderr+=c);
  child.stdout.on('data',chunk=>{output+=chunk;let index;while((index=output.indexOf('\n'))>=0){const row=JSON.parse(output.slice(0,index));output=output.slice(index+1);if(waiter&&waiter.type===row.type){const w=waiter;waiter=null;clearTimeout(w.timer);w.resolve(row)}}});
  const request=(message,type)=>new Promise((resolve,reject)=>{waiter={type,resolve,timer:setTimeout(()=>reject(Error('Missing '+type+': '+stderr)),3000)};child.stdin.write(JSON.stringify(message)+'\n')});
  try{
    assert.equal(readFileSync(join(dir,'gateway-adapter.mjs'),'utf8'),readFileSync(new URL('./gateway-adapter.mjs',import.meta.url),'utf8'));
    assert.match((await request({type:'configure'},'error')).message,/explicit mode/);
    const configured=await request({type:'configure',mode:'adapter',inventory,config:{responseKw:10}},'configured');assert.equal(configured.mode,'adapter');
    const input=telemetry(Date.now(),1,{sessionId:configured.sessionId});input.devices[0].departureAtMs=Date.now()+60000;
    const reply=await request({type:'telemetry',telemetry:input},'proposed_dispatch');assert.equal(reply.runtimeMode,'adapter');assert.equal(reply.state.observed.devices[1].energyKwh,30);assert.ok(reply.dispatch.id.startsWith(configured.sessionId));
    assert.match((await request({type:'simulation_step'},'error')).message,/cannot run/);
    const result=await request({type:'export'},'export');assert.deepEqual(result.data.inventory,inventory);assert.equal(result.data.observed.devices[1].energyKwh,30);
    const second=await request({type:'configure',mode:'adapter',inventory},'configured');assert.notEqual(second.sessionId,configured.sessionId);
    assert.match((await request({type:'telemetry',telemetry:input},'error')).message,/session/);
  }finally{if(waiter)clearTimeout(waiter.timer);child.kill();rmSync(dir,{recursive:true,force:true})}
});
