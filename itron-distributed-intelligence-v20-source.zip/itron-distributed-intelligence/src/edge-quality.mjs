export const EDGE_SKILLS = [
  {id:'contract',name:'Identity & units',required:true,description:'Understands meter identity, feeder, kW, per-unit voltage and numeric validity.'},
  {id:'time',name:'Time integrity',required:true,description:'Rejects duplicates and checks event order, freshness and the declared cadence.'},
  {id:'coverage',name:'Completeness',description:'Finds absent intervals without inventing zero readings.'},
  {id:'context',name:'Electrical context',required:true,description:'Preserves outages, restorations and no-load operation as valid electrical states.'},
  {id:'anomaly',name:'Adaptive anomalies',description:'Compares changes with a bounded, prior-only median/MAD baseline.'},
  {id:'stuck',name:'Stuck signal review',description:'Flags repeated nonzero load and voltage pairs for inspection, without rewriting them.'},
];
export const EDGE_DEFAULTS = Object.freeze({intervalMs:900000,reportMinutes:60,window:32,alertSeverity:'critical',cooldownMinutes:60,skills:EDGE_SKILLS.map(s=>s.id)});
export const EDGE_LIMITS = Object.freeze({meters:64,reports:24,alerts:80,evidence:80,recent:24,history:48,recordBytes:4096,batchBytes:65536});
export const EDGE_ENGINE_VERSION='1.1.0';
const bytes=value=>new TextEncoder().encode(JSON.stringify(value)).byteLength;
const median=values=>{const s=[...values].sort((a,b)=>a-b);return s.length%2?s[(s.length-1)/2]:(s[s.length/2-1]+s[s.length/2])/2};
const counters=()=>({expected:0,received:0,checked:0,accepted:0,flagged:0,quarantined:0,duplicates:0,missing:0,gridEvents:0,suppressed:0,broadcasts:0});
const bounded=(items,item,max)=>{items.push(item);if(items.length>max)items.splice(0,items.length-max)};
export function validateEdgeConfig(input={}){
  if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Agent policy must be an object.');
  const c=Object.fromEntries(Object.keys(EDGE_DEFAULTS).map(key=>[key,input[key]===undefined?EDGE_DEFAULTS[key]:input[key]]));
  if(![15,60,360,1440].includes(c.reportMinutes))throw Error('Choose a supported reporting interval.');
  if(![16,32,64].includes(c.window))throw Error('Use a 16, 32 or 64 sample memory window.');
  if(!['critical','warning','off'].includes(c.alertSeverity))throw Error('Choose a valid alert policy.');
  if(!Number.isInteger(c.intervalMs)||c.intervalMs<1000)throw Error('A positive sample cadence is required.');
  if(c.reportMinutes*60000%c.intervalMs!==0)throw Error('Sample cadence must divide the reporting interval exactly.');
  if(![15,60,360].includes(c.cooldownMinutes))throw Error('Choose a supported alert cooldown.');
  if(!Array.isArray(c.skills)||c.skills.some(id=>!EDGE_SKILLS.some(s=>s.id===id)))throw Error('Unknown skill.');
  c.skills=[...new Set([...EDGE_SKILLS.filter(s=>s.required).map(s=>s.id),...c.skills])];
  return c;
}

const label=(value,max=128)=>typeof value==='string'&&value.trim().length>0&&value.length<=max&&!/[\u0000-\u001f]/.test(value);
const copy=value=>structuredClone(value);
export function validateEdgeBatch(records){
  if(!Array.isArray(records)||records.length>EDGE_LIMITS.meters*3)throw Error('The batch exceeds the bounded input budget.');
  if(bytes(records)>EDGE_LIMITS.batchBytes||records.some(r=>bytes(r)>EDGE_LIMITS.recordBytes))throw Error('Reading payload exceeds the 4 KiB record / 64 KiB batch budget.');
  return copy(records);
}
export function createQualityAgent({meters,config={},start,provenance={}}){
  const policy=validateEdgeConfig(config);
  if(!Array.isArray(meters)||!meters.length||meters.length>EDGE_LIMITS.meters||meters.some(m=>!m||!label(m.id)||!label(m.circuit))||new Set(meters.map(m=>m.id)).size!==meters.length)throw Error('Select 1–64 distinct meters with nonempty IDs and circuits (128 characters maximum).');
  meters=meters.map(m=>{
    const result={id:m.id,circuit:m.circuit};
    for(const key of ['inputLoadKw','baselineVoltagePu'])if(m[key]!==undefined){if(typeof m[key]!=='number'||!Number.isFinite(m[key])||m[key]<0)throw Error('Meter metadata must contain finite, nonnegative numeric values.');result[key]=m[key]}
    if(m.allowsExport!==undefined){if(typeof m.allowsExport!=='boolean')throw Error('allowsExport must be a boolean.');result.allowsExport=m.allowsExport}
    return result;
  });
  if(!Number.isSafeInteger(start)||start<0||start>8640000000000000-policy.intervalMs)throw Error('An epoch-millisecond start time is required.');
  if(!provenance||typeof provenance!=='object'||Array.isArray(provenance))throw Error('Provenance must be an object.');
  const origin={mode:provenance.mode??'simulation',source:provenance.source??'SMARTDS virtual DI simulation',delivery:provenance.delivery??'Local headend simulator'};
  if(!['simulation','adapter'].includes(origin.mode)||!label(origin.source,160)||!label(origin.delivery,160))throw Error('Supply a valid source and delivery description.');
  const inventory=new Map(meters.map(m=>[m.id,m]));
  const scope={meterIds:meters.map(m=>m.id),circuits:[...new Set(meters.map(m=>m.circuit))]};
  const states=new Map(meters.map(m=>[m.id,{load:new Float64Array(policy.window),voltage:new Float64Array(policy.window),count:0,cursor:0,lastTimestamp:null,last:null,repeat:0,seen:new Map()}]));
  const totals=counters(),reports=[],alerts=[],evidence=[],recent=[],history=[],cooldowns=new Map(),skillCounts=Object.fromEntries(EDGE_SKILLS.map(s=>[s.id,0]));
  let clock=start-policy.intervalMs,nextReport=start+policy.reportMinutes*60000,windowStart=start,windowCounts=counters(),reportId=0,alertId=0;
  const has=id=>policy.skills.includes(id),inc=(key,n=1)=>{totals[key]+=n;windowCounts[key]+=n};
  function issue(record,skill,code,severity,message,decision='flag'){
    skillCounts[skill]++;const item={meterId:record?.meterId||'Unknown',timestamp:clock,skill,code,severity,message,decision,observed:record?{timestamp:record.timestamp,load_kw:record.load_kw,voltage_pu:record.voltage_pu,power:record.power,units:record.units}:null};
    bounded(evidence,item,EDGE_LIMITS.evidence);
    if(policy.alertSeverity==='off'||(policy.alertSeverity==='critical'&&severity!=='critical'))return item;
    const key=`${item.meterId}:${code}`,previous=cooldowns.get(key);
    if(previous!==undefined&&clock-previous<policy.cooldownMinutes*60000){inc('suppressed');return item}
    cooldowns.set(key,clock);if(cooldowns.size>256)cooldowns.delete(cooldowns.keys().next().value);
    inc('broadcasts');bounded(alerts,{...item,id:`AL-${++alertId}`,acknowledged:false,transport:origin.delivery},EDGE_LIMITS.alerts);return item;
  }
  function summary(counts){
    const hard=counts.quarantined,review=counts.flagged;
    return `${counts.checked} records checked. ${counts.accepted} accepted unchanged, ${review} forwarded with review flags, ${hard} held and ${counts.duplicates} duplicate copies suppressed. ${counts.missing} expected readings absent. ${counts.gridEvents} coherent grid-event readings retained. ${hard?'Inspect contract and timestamp evidence before replaying held records.':review?'Review flagged readings alongside neighboring meters; an anomaly can be a real operating change.':'No record-level quality issue identified in this window.'}`;
  }
  function report(reason='manual'){
    if(!windowCounts.expected&&!windowCounts.checked)return null;
    const result={id:`DQ-${++reportId}`,reason,from:windowStart,to:clock+policy.intervalMs,generatedAt:clock,source:origin.source,engineVersion:EDGE_ENGINE_VERSION,scope,counts:{...windowCounts},onTimeCoveragePct:windowCounts.expected?100*windowCounts.received/windowCounts.expected:null,cleanPct:windowCounts.checked?100*windowCounts.accepted/windowCounts.checked:null,summary:summary(windowCounts),skills:[...policy.skills],policy:{...policy},evidence:evidence.filter(e=>e.timestamp>=windowStart).slice(-24),modelBufferBytes:meters.length*policy.window*2*8,delivery:origin.delivery,payloadBytes:0};
    for(let i=0;i<4;i++)result.payloadBytes=bytes(result);bounded(reports,result,EDGE_LIMITS.reports);windowCounts=counters();windowStart=clock+policy.intervalMs;return copy(result);
  }
  function process(records,at){
    if(!Number.isSafeInteger(at)||at>8640000000000000-policy.intervalMs||at!==clock+policy.intervalMs)throw Error('Reading batches must advance monotonically by exactly one interval. Submit empty batches for gaps; start a new run to rewind.');
    // Copy bounded packets before any clock/state mutation. Unknown payload fields
    // remain available as evidence but cannot grow the retained state unboundedly.
    records=validateEdgeBatch(records);
    clock=at;inc('expected',meters.length);const present=new Set(),qualifiedBatch=[];
    for(const record of records){
      inc('checked');const m=inventory.get(record?.meterId),state=states.get(record?.meterId);let decision='accept',eventClass='normal';const reasons=[];
      const mark=(skill,code,severity,message,next='flag')=>{reasons.push(issue(record,skill,code,severity,message,next));if(next==='quarantine'||decision==='accept')decision=next};
      if(m&&record.circuit===m.circuit&&record.timestamp===clock)present.add(record.meterId);
      const valid=record&&m&&record.circuit===m.circuit&&record.units?.load==='kW'&&record.units?.voltage==='pu'&&record.units?.timestamp==='ms'&&[record.timestamp,record.load_kw,record.voltage_pu].every(v=>typeof v==='number'&&Number.isFinite(v))&&record.voltage_pu>=0&&['on','off'].includes(record.power);
      if(!valid)mark('contract','invalid_contract','critical','Invalid identity, units, numeric field or power-state contract. Raw values held; no unit guessing or imputation.','quarantine');
      else {
        const signature=JSON.stringify([record.load_kw,record.voltage_pu,record.power]);
        if(state.seen.has(record.timestamp)){
          const identical=state.seen.get(record.timestamp)===signature;
          mark('time',identical?'duplicate':'conflicting_duplicate',identical?'warning':'critical',identical?'Identical meter/timestamp copy suppressed; original retained.':'Conflicting values for an existing meter/timestamp. Original retained; new copy held.','quarantine');
          if(identical)inc('duplicates');
        }else if(record.timestamp>clock||record.timestamp<clock-policy.intervalMs||((record.timestamp-start)%policy.intervalMs)!==0){
          mark('time','invalid_time','critical','Future, stale or off-cadence record. Reconcile its timestamp before forwarding.','quarantine');
        }else if(state.lastTimestamp!==null&&record.timestamp<=state.lastTimestamp){
          mark('time','out_of_order','warning','Out-of-order record held to avoid contaminating the current baseline.','quarantine');
        }
        if(decision!=='quarantine'){
          if(record.timestamp<clock)mark('time','late','warning','Record arrived one interval late; retained with event time.');
          const outage=record.power==='off'&&Math.abs(record.load_kw)<.001&&record.voltage_pu<.05;
          const conflict=!outage&&((record.power==='off'&&(Math.abs(record.load_kw)>.01||record.voltage_pu>.05))||(record.voltage_pu<.05&&(Math.abs(record.load_kw)>.01||record.power==='on')));
          const restored=!conflict&&state.last?.power==='off'&&record.power==='on'&&record.voltage_pu>.5;
          if(outage||restored){eventClass=outage?'outage':'restoration';inc('gridEvents')}
          else if(!conflict&&(record.voltage_pu<.9||record.voltage_pu>1.1)){eventClass='voltage_excursion';inc('gridEvents')}
          if(conflict)mark('context','state_conflict','warning','Load, voltage and power-state disagree. Investigate sensor/state alignment; retain the reading.');
          if(record.load_kw<0&&!m.allowsExport)mark('context','export_context','warning','Negative power may be legitimate export; export capability is not declared for this meter.');
          state.repeat=record.timestamp===state.lastTimestamp+policy.intervalMs&&record.load_kw!==0&&state.last&&record.load_kw===state.last.load_kw&&record.voltage_pu===state.last.voltage_pu?state.repeat+1:0;
          if(has('stuck')&&state.repeat>=5&&!outage)mark('stuck','repeated_pair','warning','Six or more identical nonzero load/voltage pairs. Possible stuck sensor; steady operation is also possible.');
          if(has('anomaly')&&state.count>=8&&eventClass==='normal'&&decision==='accept'){
            for(const [field,buffer,floor] of [['load_kw',state.load,Math.max(2,Math.abs(m.inputLoadKw||0)*.8)],['voltage_pu',state.voltage,.025]]){
              const values=Array.from(buffer.slice(0,state.count)),center=median(values),mad=median(values.map(x=>Math.abs(x-center))),threshold=Math.max(floor,6*1.4826*mad);
              if(Math.abs(record[field]-center)>threshold)mark('anomaly','unusual_'+field,'warning',`${field}: ${record[field].toFixed(4)} versus prior median ${center.toFixed(4)} (review threshold ±${threshold.toFixed(4)}). Statistical surprise, not proof of bad data.`);
            }
          }
          // Exclude invalid/event samples. Clip reviewed changes so a legitimate
          // sustained shift can be learned without one spike replacing baseline.
          const trustedContext=!reasons.some(r=>r.code==='state_conflict'||r.code==='export_context');
          if(eventClass==='normal'&&trustedContext&&!reasons.some(r=>r.code==='repeated_pair')){
            for(const [field,buffer,floor] of [['load_kw',state.load,Math.max(2,Math.abs(m.inputLoadKw||0)*.8)],['voltage_pu',state.voltage,.025]]){
              const center=state.count?median(Array.from(buffer.slice(0,state.count))):record[field];
              buffer[state.cursor]=decision==='flag'?Math.max(center-floor,Math.min(center+floor,record[field])):record[field];
            }
            state.cursor=(state.cursor+1)%policy.window;state.count=Math.min(policy.window,state.count+1);
          }
          state.lastTimestamp=record.timestamp;if(trustedContext)state.last={load_kw:record.load_kw,voltage_pu:record.voltage_pu,power:record.power};state.seen.set(record.timestamp,signature);if(state.seen.size>policy.window)state.seen.delete(state.seen.keys().next().value);
        }
      }
      if(decision==='accept')inc('accepted');else if(decision==='flag')inc('flagged');else if(!reasons.some(r=>r.code==='duplicate'))inc('quarantined');
      const evaluated={...record,recordId:totals.checked,qualityDecision:decision,disposition:reasons.some(r=>r.code==='duplicate')?'suppressed duplicate':decision,eventClass,reasons:reasons.map(r=>r.message),forwarded:decision!=='quarantine'};
      bounded(recent,evaluated,EDGE_LIMITS.recent);if(evaluated.forwarded)qualifiedBatch.push(evaluated);
    }
    inc('received',present.size);
    const absent=meters.filter(m=>!present.has(m.id));inc('missing',absent.length);
    if(has('coverage'))for(const m of absent)issue({meterId:m.id},'coverage','missing_interval','warning','Expected interval reading absent; no replacement value created.','missing');
    bounded(history,{timestamp:clock,cleanPct:totals.checked?totals.accepted/totals.checked*100:100,missing:totals.missing},EDGE_LIMITS.history);
    if(clock+policy.intervalMs>=nextReport){report('scheduled');nextReport=clock+policy.intervalMs+policy.reportMinutes*60000}
    return {...snapshot(),qualifiedBatch:copy(qualifiedBatch)};
  }
  function snapshot(){return copy({clock,nextReport,totals,reports,alerts,evidence,recent,history,skillCounts,modelBufferBytes:[...states.values()].reduce((n,s)=>n+s.load.byteLength+s.voltage.byteLength,0),learnedMeters:[...states.values()].filter(s=>s.count>=8).length,meterCount:meters.length,policy,provenance:origin,retained:{reports:reports.length,alerts:alerts.length,evidence:evidence.length},summary:summary(totals)})}
  return {process,snapshot,report,acknowledge(id){const a=alerts.find(a=>a.id===id);if(a)a.acknowledged=true},export(){return {...snapshot(),engineVersion:EDGE_ENGINE_VERSION,scope:copy(scope),inventory:copy(meters),skillManifest:copy(EDGE_SKILLS),limits:EDGE_LIMITS,limitations:[origin.mode==='simulation'?'Synthetic telemetry and injected faults, not field validation.':'Supplied readings screened locally; sensor accuracy requires independent calibration.',origin.mode==='simulation'?'A browser worker is not a deployed meter runtime.':'Target-device deployment and headend transport require an integration adapter.','Model buffer bytes exclude JavaScript objects, runtime and UI memory.','Coverage counts records arriving at their expected interval, not subsequent late recovery.','Emitting an output does not prove headend receipt.']}}};
}
