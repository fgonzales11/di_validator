// The public settings describe inputs to the bundled multiconductor studies.
const n=(key,label,value,min,max,step='any')=>({key,label,value,min,max,step,type:'number'});
const choice=(key,label,value,options)=>({key,label,value,options,type:'select'});
const flag=(key,label,value)=>({key,label,value,type:'checkbox'});
const bus=(key,label)=>({key,label,value:'auto',type:'bus'});
const faultFields=()=>[
 bus('fault_bus','Fault bus'),
 choice('fault_type','Fault type','LLL',[['LLL','Three phase'],['LG','Phase to ground'],['LL','Phase to phase'],['LLG','Two phases to ground']]),
 choice('case','Duty case','max',[['max','Maximum'],['min','Minimum']]),
 n('source_r_ohm','Source resistance · Ω',.1,0,100),n('source_x_ohm','Source reactance · Ω',1,.000001,100),
 n('fault_r_ohm','Fault resistance · Ω',0,0,100),n('fault_x_ohm','Fault reactance · Ω',0,0,100),
];
export const ANALYSES=[
 {id:'power_flow',label:'Power Flow',description:'Solve the selected feeder’s supplied injections and topology.',fields:[n('tol_vmag_pu','Voltage magnitude tolerance · pu',1e-6,1e-12,.1),n('tol_vang_rad','Voltage angle tolerance · rad',1e-6,1e-12,.1),n('MaxIter','Maximum iterations',100,1,1000,1),flag('run_control','Enable device controls',true)]},
 {id:'short_circuit',label:'Short Circuit Duty',description:'Calculate fault current and branch duty at a selected bus. The source impedance is an explicit study assumption.',fields:faultFields()},
 {id:'protection',label:'Protection Study',description:'Evaluate a demonstration definite-time overcurrent relay against a short-circuit result. Relay settings are assumptions; trips do not change topology.',fields:[...faultFields(),{key:'relay_line',label:'Relay line',value:'auto',type:'line'},n('pickup_ratio','Pickup / calculated fault current',.5,.001,2),n('instantaneous_ratio','Instantaneous pickup / fault current',.9,.001,5),n('delay_s','Definite-time delay · s',.2,0,120),n('instantaneous_delay_s','Instantaneous delay · s',.02,0,120)]},
 {id:'contingency',label:'Contingency',description:'Run a deterministic set of N−1 line outages. Each case reports convergence and islanding separately.',fields:[n('case_start','First case · 1-based',1,1,10000,1),n('case_count','Number of line outages',1,1,20,1),n('MaxIter','Maximum power-flow iterations',100,1,1000,1)]},
 {id:'optimal_power_flow',label:'Optimal Power Flow',description:'Run the tutorial’s fixed-dispatch feasibility OPF with an illustrative linear generator cost. Dispatch limits remain fixed at the supplied operating point.',fields:[n('cost_per_mw','Linear generation cost · currency/MW',25,0,100000),n('min_vm_pu','Minimum phase voltage · pu',.95,.5,1),n('max_vm_pu','Maximum phase voltage · pu',1.05,1,1.5),n('max_loading_percent','Maximum equipment loading · %',100,1,300)]},
 {id:'grid_equivalent',label:'Grid Equivalent',description:'Reduce all non-boundary nodes to a local multiport equivalent. Validation compares the reduced response at the solved operating point.',fields:[bus('boundary_bus','Boundary bus'),n('voltage_scale','Boundary voltage multiplier',1,.98,1.02),n('mismatch_tolerance','Current mismatch tolerance · pu',1e-6,1e-8,1e-6)]},
 {id:'load_allocation',label:'Load Allocation',description:'Adjust downstream loads to a feeder-head active-power target. A baseline multiplier is a demonstration target; use a measured MW target for an independent allocation.',fields:[choice('target_mode','Target source','baseline',[['baseline','Solved baseline × multiplier'],['absolute','Independent target · MW']]),n('target_scale','Baseline multiplier',1,.01,5),n('target_mw','Independent feeder-head target · MW',10,.0001,1000),n('tolerance','Target tolerance · %',.5,.001,10),n('max_iter','Maximum allocation iterations',4,1,30,1),flag('ignore_generators','Ignore generation during allocation',false)]},
 {id:'hosting_capacity',label:'Hosting Capacity',description:'Screen additional balanced generation at one bus using repeated power flows. Capacity is bounded by the scan and supplied voltage and equipment limits.',fields:[bus('connection_bus','Generation connection bus'),n('maximum_mw','Maximum added generation · MW',2,.001,100),n('steps','Scan intervals',10,2,40,1),n('min_vm_pu','Minimum phase voltage · pu',.95,.5,1),n('max_vm_pu','Maximum phase voltage · pu',1.05,1,1.5),n('max_loading_percent','Maximum equipment loading · %',100,1,300)]},
];
export const analysisDefinition=id=>ANALYSES.find(a=>a.id===id);
export const defaultAnalysisParameters=id=>Object.fromEntries(analysisDefinition(id).fields.map(f=>[f.key,f.value]));
export function validateAnalysisParameters(id,values){
 const definition=analysisDefinition(id);if(!definition)throw Error('Select a supported analysis type.');
 const result={};for(const f of definition.fields){const v=values[f.key];if(f.type==='number'){if(!Number.isFinite(v)||v<f.min||v>f.max||(f.step===1&&!Number.isInteger(v)))throw Error(`${f.label} must be ${f.step===1?'an integer ':''}between ${f.min} and ${f.max}.`)}else if(f.type==='checkbox'){if(typeof v!=='boolean')throw Error(`${f.label} must be on or off.`)}else if(f.type==='select'){if(!f.options.some(([key])=>key===v))throw Error(`Choose ${f.label.toLowerCase()}.`)}else if(v!=='auto'&&!((typeof v==='number'&&Number.isSafeInteger(v)&&v>=0)||(typeof v==='string'&&/^(0|[1-9][0-9]*)$/.test(v)&&Number.isSafeInteger(Number(v)))))throw Error(`Choose a valid ${f.label.toLowerCase()}.`);result[f.key]=v;}
 if(['hosting_capacity','optimal_power_flow'].includes(id)&&result.min_vm_pu>=result.max_vm_pu)throw Error('Maximum voltage must exceed minimum voltage.');
 if(id==='protection'&&result.instantaneous_ratio<result.pickup_ratio)throw Error('Instantaneous pickup must be at least the timed pickup.');
 return result;
}
