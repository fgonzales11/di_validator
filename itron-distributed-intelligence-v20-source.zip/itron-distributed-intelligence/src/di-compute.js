export function createBrowserTask(createWorker) {
  let worker, id=0, state={status:'idle',message:'Ready',result:null},listener=()=>{};
  const update=next=>{state={...state,...next};listener(state)};
  return {
    subscribe(fn){listener=fn;return()=>{if(listener===fn)listener=()=>{}}},
    getState:()=>state,
    run(payload){if(state.status==='running')return;const current=++id;update({status:'running',message:'Starting analysis…',result:null,error:null,payload});
      worker??=createWorker();const active=worker;
      worker.onmessage=({data})=>{if(active!==worker||data.id!==current)return;if(data.type==='status')update({message:data.message});else if(data.type==='result')update({status:'success',message:'Analysis complete',result:data.result});else if(data.type==='error')update({status:'error',error:data.message,message:data.message})};
      worker.onerror=e=>{if(active!==worker)return;worker.terminate();worker=null;update({status:'error',error:e.message||'The analysis worker could not start. Retry.',message:'Analysis unavailable'})};
      worker.postMessage({id:current,...payload});
    },
    cancel(){id++;worker?.terminate();worker=null;update({status:'cancelled',message:'Run cancelled',result:null})},
    clear(){if(state.status==='running')this.cancel();update({status:'idle',message:'Ready',result:null,error:null})},
  };
}
export const faultTask=createBrowserTask(()=>new Worker(`${import.meta.env.BASE_URL}fault-detection/worker.mjs`,{type:'module'}));
export const forecastTask=createBrowserTask(()=>new Worker(new URL('./forecast-worker.js',import.meta.url),{type:'module'}));
