/**
 * Chronological forecasting evaluation shared by browser and Python/WASM models.
 * Built-in baselines run without dependencies. Tree models use an injected
 * provider receiving only the training prefix and future timestamps.
 * Timestamp numbers are epoch milliseconds; strings must declare a timezone.
 * Source values retain their declared unit. Gaps/missing values are rejected.
 */
export const MODEL_NAMES = Object.freeze({
  seasonal_naive: 'Seasonal naive',
  ridge_autoregression: 'Ridge autoregression',
  random_forest: 'Random forest',
  skforecast_boosting: 'skforecast · Gradient boosting',
});

export const DEFAULT_CONFIG = Object.freeze({
  horizon: 24,
  validationWindows: 3,
  contextLength: 256,
  maxHistory: 10000,
  seasonLength: 24,
  lags: 24,
  ridge: 0.01,
  trees: 80,
  maxDepth: 8,
  minLeaf: 3,
  seed: 42,
  models: ['seasonal_naive', 'ridge_autoregression'],
});

export class ForecastError extends Error {
  constructor(message) { super(message); this.name = 'ForecastError'; }
}
export class ForecastCancelledError extends Error {
  constructor() { super('Forecast cancelled.'); this.name = 'AbortError'; }
}
const fail = message => { throw new ForecastError(message); };
const mean = values => values.reduce((sum, value) => sum + value / values.length, 0);

function validateConfig(input) {
  for (const key of Object.keys(input)) if (!(key in DEFAULT_CONFIG)) fail(`Unknown forecast setting: ${key}.`);
  const c = { ...DEFAULT_CONFIG, ...input };
  for (const [key, min, max] of [
    ['horizon', 1, 512], ['validationWindows', 2, 8],
    ['contextLength', 32, 10000], ['maxHistory', 100, 200000],
    ['seasonLength', 1, 5000], ['lags', 1, 64],
    ['trees', 20, 200], ['maxDepth', 2, 16], ['minLeaf', 1, 32], ['seed', 0, 2147483647],
  ]) {
    if (!Number.isInteger(c[key]) || c[key] < min || c[key] > max)
      fail(`${key} must be an integer from ${min} to ${max}.`);
  }
  if (!Number.isFinite(c.ridge) || c.ridge < 1e-8 || c.ridge > 1e6)
    fail('ridge must be finite and between 0.00000001 and 1000000.');
  if (c.maxHistory < c.contextLength) fail('Maximum history must be at least the training context.');
  if (c.contextLength < Math.max(32, c.lags + 11, c.seasonLength * 2))
    fail('Training context must contain two seasons, at least 32 samples, and at least lags + 11 samples.');
  if (!Array.isArray(c.models) || !c.models.length || new Set(c.models).size !== c.models.length ||
      c.models.some(model => !Object.hasOwn(MODEL_NAMES, model)))
    fail(`Choose unique supported models: ${Object.keys(MODEL_NAMES).join(', ')}.`);
  c.models = [...c.models];
  return c;
}

function timestamp(value, index) {
  if (typeof value === 'string' && !/(Z|[+-]\d{2}:?\d{2})$/i.test(value))
    fail(`Timestamp ${index + 1} must declare its timezone or use epoch milliseconds.`);
  const result = typeof value === 'number' ? value : typeof value === 'string' ? Date.parse(value) : NaN;
  if (!Number.isFinite(result) || Math.abs(result) > 8.64e15)
    fail(`Timestamp ${index + 1} is invalid.`);
  return result;
}

function prepareSeries(series, c) {
  if (!series || !Array.isArray(series.timestamps) || !Array.isArray(series.values) ||
      series.timestamps.length !== series.values.length || series.values.length < 2)
    fail('Provide aligned timestamp and value arrays with at least two observations.');
  // Validate the supplied series before truncation; do not hide a source defect.
  const times = series.timestamps.map(timestamp);
  const values = series.values.map((value, i) => {
    if (typeof value !== 'number' || !Number.isFinite(value))
      fail(`Reading ${i + 1} is missing or nonfinite. Supply a contiguous observed series.`);
    // A conservative numerical bound keeps squared errors and normal equations finite.
    if (Math.abs(value) > 1e100) fail(`Reading ${i + 1} exceeds the supported numerical range.`);
    return value;
  });
  const step = times[1] - times[0];
  if (!(step > 0)) fail('Timestamps must be strictly increasing and unique.');
  for (let i = 1; i < times.length; i++) {
    const delta = times[i] - times[i - 1];
    if (!(delta > 0)) fail('Timestamps must be strictly increasing and unique.');
    if (Math.abs(delta - step) > Math.max(1e-6, step * 1e-9))
      fail('Irregular sampling or a timestamp gap was found. Explicitly prepare a regular series first.');
  }
  const start = Math.max(0, values.length - c.maxHistory);
  const y = values.slice(start), t = times.slice(start), minTrain = Math.max(32, c.lags + 11, c.seasonLength * 2);
  if (y.length - c.horizon * (c.validationWindows + 1) < minTrain)
    fail(`Insufficient history: need at least ${minTrain + c.horizon * (c.validationWindows + 1)} observations for these windows, lags, and seasons.`);
  if (t.at(-1) + c.horizon * step > 8.64e15) fail('Future timestamps exceed the supported date range.');
  return { values: y, timestamps: t, step, sourceStartIndex: start,
    metadata: { channel: series.channel ?? '', unit: series.unit ?? 'unverified',
      source: series.source ?? '', synthetic: series.synthetic ?? null } };
}

function lifecycle(hooks) {
  let work = 0;
  const check = () => { if (hooks.signal?.aborted || hooks.isCancelled?.()) throw new ForecastCancelledError(); };
  const yieldControl = hooks.yieldControl ?? (() => new Promise(resolve => setTimeout(resolve, 0)));
  return {
    check,
    async checkpoint(force = false) {
      check();
      if (force || ++work % 128 === 0) { await yieldControl(); check(); }
    },
    async progress(value) { check(); hooks.onProgress?.(value); await this.checkpoint(true); },
  };
}

function calendar(ms) {
  const date = new Date(ms), hour = date.getUTCHours() + date.getUTCMinutes() / 60 + date.getUTCSeconds() / 3600;
  // Python's dayofweek is Monday=0, unlike JavaScript's Sunday=0.
  const day = (date.getUTCDay() + 6) % 7;
  return [Math.sin(2 * Math.PI * hour / 24), Math.cos(2 * Math.PI * hour / 24),
    Math.sin(2 * Math.PI * day / 7), Math.cos(2 * Math.PI * day / 7)];
}

function features(history, stop, time, lags, center, scale) {
  const row = new Float64Array(lags + 5); row[0] = 1;
  for (let i = 0; i < lags; i++) row[i + 1] = (history[stop - i - 1] - center) / scale;
  row.set(calendar(time), lags + 1);
  return row;
}

function choleskySolve(matrix, rhs, size) {
  const lower = new Float64Array(size * size), z = new Float64Array(size), result = new Float64Array(size);
  for (let i = 0; i < size; i++) {
    for (let j = 0; j <= i; j++) {
      let v = matrix[i * size + j];
      for (let k = 0; k < j; k++) v -= lower[i * size + k] * lower[j * size + k];
      if (i === j) {
        if (!(v > 1e-14) || !Number.isFinite(v)) fail('Ridge system is numerically ill-conditioned. Increase regularization or shorten the lag window.');
        lower[i * size + j] = Math.sqrt(v);
      } else lower[i * size + j] = v / lower[j * size + j];
    }
  }
  for (let i = 0; i < size; i++) {
    let v = rhs[i]; for (let k = 0; k < i; k++) v -= lower[i * size + k] * z[k];
    z[i] = v / lower[i * size + i];
  }
  for (let i = size - 1; i >= 0; i--) {
    let v = z[i]; for (let k = i + 1; k < size; k++) v -= lower[k * size + i] * result[k];
    result[i] = v / lower[i * size + i];
  }
  if (!result.every(Number.isFinite)) fail('Ridge fitting produced a nonfinite coefficient.');
  return result;
}

async function fitPredict(model, values, times, future, c, life, provider) {
  await life.checkpoint(true);
  if (model === 'seasonal_naive') {
    const season = values.slice(-c.seasonLength);
    return { prediction: future.map((_, i) => season[i % season.length]),
      artifact: { model, season, trainedThrough: times.at(-1), version: 1 } };
  }
  if (model !== 'ridge_autoregression') {
    if (!provider) fail('The Python forecasting runtime is unavailable.');
    const result = await provider({ model, values: [...values], times: [...times], future: [...future], config: c });
    life.check();
    if (!Array.isArray(result?.prediction) || result.prediction.length !== future.length ||
        !result.prediction.every(v => Number.isFinite(v) && Math.abs(v) <= 1e100))
      fail('The forecasting model returned invalid predictions.');
    return result;
  }
  const center = mean(values);
  const variance = mean(values.map(value => (value - center) ** 2));
  const scale = Math.sqrt(variance) || 1;
  const size = c.lags + 5, count = values.length - c.lags;
  const matrix = new Float64Array(size * size), rhs = new Float64Array(size);
  for (let i = c.lags; i < values.length; i++) {
    const row = features(values, i, times[i], c.lags, center, scale), target = (values[i] - center) / scale;
    for (let j = 0; j < size; j++) {
      rhs[j] += row[j] * target / count;
      for (let k = 0; k <= j; k++) matrix[j * size + k] += row[j] * row[k] / count;
    }
    await life.checkpoint();
  }
  for (let j = 0; j < size; j++) {
    // Normalize squared-error loss by training rows; intercept remains unpenalized.
    if (j) matrix[j * size + j] += c.ridge;
    for (let k = 0; k < j; k++) matrix[k * size + j] = matrix[j * size + k];
  }
  const coefficients = choleskySolve(matrix, rhs, size), history = [...values], prediction = [];
  for (const time of future) {
    const row = features(history, history.length, time, c.lags, center, scale);
    let normalized = 0;
    for (let j = 0; j < size; j++) normalized += row[j] * coefficients[j];
    const value = center + scale * normalized;
    if (!Number.isFinite(value) || Math.abs(value) > 1e100)
      fail('Recursive autoregression diverged. Increase regularization or shorten the horizon.');
    prediction.push(value); history.push(value);
    await life.checkpoint();
  }
  return { prediction, artifact: { model, version: 1, lags: c.lags, ridge: c.ridge,
    center, scale, coefficients: [...coefficients], trainedThrough: times.at(-1),
    features: ['intercept', ...Array.from({ length: c.lags }, (_, i) => `lag_${i + 1}`),
      'utc_hour_sin', 'utc_hour_cos', 'utc_weekday_sin', 'utc_weekday_cos'] } };
}

export function scoreForecast(actual, prediction, training, seasonLength) {
  if (actual.length !== prediction.length || !actual.length ||
      !actual.every(Number.isFinite) || !prediction.every(Number.isFinite))
    fail('Scoring needs equally sized finite observed and predicted arrays.');
  const errors = actual.map((v, i) => Math.abs(v - prediction[i]));
  const denominator = actual.reduce((sum, v) => sum + Math.abs(v), 0);
  const differences = training.slice(seasonLength).map((v, i) => Math.abs(v - training[i]));
  const seasonalScale = differences.length ? mean(differences) : NaN;
  return {
    n: actual.length,
    mae: mean(errors),
    rmse: Math.sqrt(mean(errors.map(v => v * v))),
    smape: mean(errors.map((e, i) => { const d = Math.abs(actual[i]) + Math.abs(prediction[i]); return d ? 200 * e / d : 0; })),
    wape: denominator ? 100 * errors.reduce((sum, e) => sum + e, 0) / denominator : null,
    mase: Number.isFinite(seasonalScale) && seasonalScale > 0 ? mean(errors) / seasonalScale : null,
  };
}

export function residualBandRadius(actual, prediction) {
  if (!actual.length || actual.length !== prediction.length) fail('Residual bands need aligned validation samples.');
  const errors = actual.map((v, i) => Math.abs(v - prediction[i])).sort((a, b) => a - b);
  if (!errors.every(Number.isFinite)) fail('Residual bands need finite validation samples.');
  // Matches NumPy quantile(..., method="higher") used by DI Validator.
  const quantile = Math.min(1, Math.ceil((errors.length + 1) * 0.9) / errors.length);
  return errors[Math.ceil(quantile * (errors.length - 1))];
}

function windowRecord(times, actual, prediction, radius, extra = {}) {
  return { ...extra, timestamps: times, actual, prediction,
    ...(radius === undefined ? {} : { lower: prediction.map(v => v - radius), upper: prediction.map(v => v + radius) }) };
}

/**
 * @param {{timestamps:(number|string)[],values:number[],channel?:string,unit?:string,source?:string,synthetic?:boolean}} series
 * @param {object} configuration Camel-case settings from DEFAULT_CONFIG.
 * @param {{signal?:AbortSignal,isCancelled?:()=>boolean,onProgress?:(event:object)=>void,yieldControl?:()=>Promise<void>}} hooks
 * Worker integration: run this async function; a message listener can set a
 * cancellation flag read by isCancelled. Default macrotask yields let it run.
 */
export async function runForecast(series, configuration = {}, hooks = {}) {
  const life = lifecycle(hooks); life.check();
  const config = validateConfig(configuration), source = prepareSeries(series, config);
  const { values, timestamps, step } = source, n = values.length, h = config.horizon;
  const origins = Array.from({ length: config.validationWindows }, (_, i) => n - h * (config.validationWindows + 1 - i));
  const holdoutOrigin = n - h;
  const train = stop => ({ start: Math.max(0, stop - config.contextLength), values: values.slice(Math.max(0, stop - config.contextLength), stop), times: timestamps.slice(Math.max(0, stop - config.contextLength), stop) });
  const splits = [...origins, holdoutOrigin].map((stop, i) => ({
    phase: i < origins.length ? 'validation' : 'holdout', window: i < origins.length ? i : 0,
    trainStartIndex: train(stop).start, trainEndIndexExclusive: stop,
    testStartIndex: stop, testEndIndexExclusive: stop + h,
    trainStart: timestamps[train(stop).start], trainEnd: timestamps[stop - 1],
    testStart: timestamps[stop], testEnd: timestamps[stop + h - 1],
  }));
  const models = [];
  for (const model of config.models) {
    const windows = [];
    try {
      for (let i = 0; i < origins.length; i++) {
        await life.progress({ phase: 'validation', model, window: i, message: `Validating ${MODEL_NAMES[model]} · window ${i + 1}/${origins.length}` });
        const stop = origins[i], prefix = train(stop), testTimes = timestamps.slice(stop, stop + h);
        const { prediction } = await fitPredict(model, prefix.values, prefix.times, testTimes, config, life, hooks.fitPredict);
        windows.push(windowRecord(testTimes, values.slice(stop, stop + h), prediction, undefined, { window: i }));
      }
      const actual = windows.flatMap(w => w.actual), predicted = windows.flatMap(w => w.prediction);
      models.push({ model, name: MODEL_NAMES[model], status: 'completed',
        validation: scoreForecast(actual, predicted, train(origins[0]).values, config.seasonLength),
        intervalRadius: residualBandRadius(actual, predicted),
        intervalMethod: '90% empirical validation residual band; coverage not guaranteed',
        predictions: { validation: windows } });
    } catch (error) {
      if (error.name === 'AbortError') throw error;
      models.push({ model, name: MODEL_NAMES[model], status: 'failed', error: error.message });
    }
  }
  const successful = models.filter(m => m.status === 'completed');
  if (!successful.length) fail('All forecasting models failed: ' + models.map(m => m.error).join('; '));
  // Selection is fixed BEFORE any holdout target is evaluated. Do not change it
  // if a subsequent fit fails; the entire run must fail instead.
  const selected = [...successful].sort((a, b) => a.validation.mae - b.validation.mae || (a.model < b.model ? -1 : a.model > b.model ? 1 : 0))[0];
  await life.progress({ phase: 'selection', model: selected.model, message: `Selected ${selected.name} using validation MAE` });
  const futureTimes = Array.from({ length: h }, (_, i) => timestamps.at(-1) + (i + 1) * step);
  for (const result of successful) {
    await life.progress({ phase: 'holdout', model: result.model, message: `Evaluating ${result.name} on the final holdout` });
    const prefix = train(holdoutOrigin), holdoutTimes = timestamps.slice(holdoutOrigin);
    const holdout = await fitPredict(result.model, prefix.values, prefix.times, holdoutTimes, config, life, hooks.fitPredict);
    result.holdout = scoreForecast(values.slice(holdoutOrigin), holdout.prediction, prefix.values, config.seasonLength);
    result.predictions.holdout = windowRecord(holdoutTimes, values.slice(holdoutOrigin), holdout.prediction, result.intervalRadius);
    await life.progress({ phase: 'future', model: result.model, message: `Refitting ${result.name} through the final observation` });
    const full = train(n), future = await fitPredict(result.model, full.values, full.times, futureTimes, config, life, hooks.fitPredict);
    result.predictions.future = windowRecord(futureTimes, Array(h).fill(null), future.prediction, result.intervalRadius);
    result.artifact = future.artifact; result.selected = result.model === selected.model;
  }
  await life.progress({ phase: 'completed', model: selected.model, message: 'Forecast benchmark completed' });
  return { version: 1, config, selectedModel: selected.model, models, splits,
    selectionPolicy: 'Lowest chronological validation MAE; final holdout is never used for selection.',
    source: { ...source.metadata, observations: n, originalObservations: series.values.length,
      sourceStartIndex: source.sourceStartIndex, resolutionMs: step,
      start: timestamps[0], end: timestamps.at(-1), calendarBasis: 'UTC', missingPolicy: 'reject' },
    sourceWindow: { timestamps, values } };
}
