import {defineConfig, loadEnv} from 'vite';
import {streetViewAPI} from './server/street-view.mjs';
import {mapsConfigAPI} from './server/maps-config.mjs';
export default defineConfig(({mode})=>({
  base:'/',
  plugins:[{name:'street-view-preview',configureServer(server){
    const env={...loadEnv(mode,process.cwd(),''),...process.env};
    server.middlewares.use(async(req,res,next)=>{
      const request=new Request(new URL(req.url,'http://localhost'),{method:req.method});
      const response=streetViewAPI(request,env)||mapsConfigAPI(request,env);
      if(!response)return next();
      res.statusCode=response.status;
      for(const [key,value] of response.headers)res.setHeader(key,value);
      res.end(await response.text());
    });
  }}],
  build:{outDir:'dist/client',target:'es2022',rollupOptions:{input:{main:'index.html',outage:'outage-analyzer/index.html',transformer:'transformer-analyzer/index.html'}},chunkSizeWarningLimit:900},
  server:{host:'127.0.0.1'}
}));
