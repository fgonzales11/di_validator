# iTron Grid Intelligence

A static browser demonstration of distributed intelligence using the supplied SMARTDS models and DI Validator examples. Built with Vite, vanilla JavaScript and Three.js. Light mode is the default; dark mode is available across all pages. The sidebar starts collapsed and uses arrow-only expansion controls.

## Capabilities

- Overview, feeder, transformer and modeled-meter monitoring use the eleven supplied SMARTDS SFO P3R snapshots.
- A shared virtual DI agent creates reproducible 15-minute load and voltage profiles for 6,091 modeled load groups. Its 159 paired PON/PRN scenarios drive both profile interruptions and Outage Analyzer. Replay, pause, reset, timeline seeking and JSON export are available in Meter Monitoring, Fault Detection and Forecasting.
- Fault Detection replays all 99 calibrated RTDS COMTRADE records from `di_validator/fault-distance/data/data_test`. The maintained DI Validator inception, Fortescue classification and reactance-distance functions execute in Pyodide WebAssembly with NumPy and pandas, without the DI agent SDK. Users select recordings and line parameters; results include phase waveforms, sequence magnitudes, onset, fault loop, per-cycle distances and quality/provenance. Out-of-range locations remain unavailable.
- Forecasting compares seasonal naive, ridge autoregression, scikit-learn Random Forest, and skforecast recursive histogram gradient boosting on the selected virtual load or voltage channel. Users choose candidate models, tune tree count/depth/leaf size, and inspect any completed model without changing the validation winner. Chronological validation chooses the model before the independent final holdout. Successful models then refit through the final observation for future prediction. The UI shows MAE/RMSE/sMAPE/WAPE/MASE and nominal 90% empirical validation-residual bands. Export includes predictions, split boundaries, baseline coefficients, tree estimator settings, package versions, random seeds, feature importances (Random Forest), configuration and source/algorithm hashes. Missing data is rejected.
- Power Flow offers eight analysis types: Power Flow, Short Circuit Duty, Protection Study, Contingency, Optimal Power Flow, Grid Equivalent, Load Allocation and Hosting Capacity. Each has validated settings saved by feeder and type, a cancellable browser worker and result export. The adapters use the supplied multiconductor tutorial/run-book APIs. Outage Analyzer retains its power-flow solver. All eleven supplied models converge. State Estimation uses the real multiconductor state estimator with explicit synthetic or imported measurement modes. Result cards and tables are below the State Estimation view; old `#results` links redirect there.
- Transformer Analyzer retains assumed thermal and EV charging studies, excluding three modeled regulators. Regional EV adoption data is unavailable for the new models and is labeled accordingly. Ductbank Modeling retains the supplied thermal calculations.

Page selections, inputs, results, table filters and sorting, scroll positions and map views are retained while switching pages in the current browser session. Embedded analyzers stay connected so their runtime and camera state survive navigation. Background study computations continue; virtual-agent and thermal playback pause off-page and resume on return.

## Analysis scope

- Short-circuit duty requires explicit source-impedance assumptions. The protection example evaluates one illustrative definite-time relay without applying trips; no field coordination or breaker ratings are inferred.
- Contingency runs independent N−1 line outages and distinguishes islanding, unsupplied demand and solve failure.
- OPF follows the tutorial’s fixed-dispatch feasibility case. The SMARTDS snapshots have load capability-rating exceedances, so the page reports infeasibility and affected rows without altering supplied ratings or claiming optimized dispatch.
- Grid Equivalent uses a validated whole-network local multiport reduction, retains conjugate admittance and reports boundary-port response. The source-only tutorial partition does not validate for these feeders.
- Load Allocation adjusts reachable downstream load rows and independently checks the final feeder-head target error. Hosting Capacity performs a balanced-generation power-flow sweep at one bus, stopping at the first failed point; a feasible scan maximum is only a tested lower bound.

## Data boundaries

The SMARTDS files are user-supplied modified synthetic snapshots with modeled rating/equipment changes, not an as-built utility inventory. There are 8,549 buses, 6,452 physical lines, 368 switches, 1,717 distribution transformers, three regulators and 288 generation models. Load-to-transformer links use active electrical topology. Zero-load model records remain zero in virtual profiles. Original and repackaged model SHA-256 hashes are retained separately; published pickle copies add only the `CIRCUIT_ID` alias required by the existing solver exporter.

The supplied files do not contain field AMI profiles or PON/PRN histories. The September 1–14, 2026 clock is a simulated demonstration window. RTDS recordings retain native sample timing and CFG calibration, and have no verified relationship to SMARTDS assets or clocks. Virtual waveform assignment is explicitly labeled. Fault-distance line parameters are examples, and no verified fault-distance labels were supplied. The algorithm is offline, using post-fault samples; no live detection-latency claim is made.

Synthetic mode on the State Estimation page reports numerical-rank errors for models `p3rhs0_1247--p3rdt656` and `p3rhs0_1247--p3rdt836` under the default noisy measurement recipe. It preserves the error rather than presenting an unstable branch-current solution. This does not affect power-flow availability for these models. Imported measurement sets are neither replaced nor silently filtered.

## Development and verification

```sh
npm install
npm run dev -- --port 5174
npm test
npm run build
```

Numerical parity checks require Python with NumPy/pandas; state-estimation tests additionally require pandapower/scipy/networkx and the bundled multiconductor archive:

```sh
python3 scripts/test_fault_detection.py
MULTICONDUCTOR_DISABLE_NUMBA=1 python3 scripts/test_state_estimation.py
MULTICONDUCTOR_DISABLE_NUMBA=1 python3 scripts/test_analysis.py
```

Rebuild model-derived assets from the trusted local PKLs (never from untrusted uploaded pickles):

```sh
python3 scripts/export_smartds.py --source /path/to/di_validator/pkls --output public
```

Browser workers download the pinned Pyodide runtime and numerical packages on first use. All analysis then runs locally in the browser. No DI agent SDK or analysis server is used. `.openai/hosting.json` binds this checkout to its existing Sites project.


### Street View

Both analyzers reuse the GridScope Street View panel. Outage Analyzer selects
bus coordinates or the nearest point on a clicked line/switch centerline;
Transformer Analyzer prefers its own geographic coordinates, then the connected SMARTDS bus latitude/longitude, then the projected model location. Bus IDs remain scoped to their circuit.
The published topology retains all 8,549 source bus locations. Projected SMARTDS coordinates are inverted with the exporter's 111320 meters/degree
constant and the active dataset origin. Imagery is nearby context, not a
verified photograph of the synthetic model asset.

Configure `MAPS_EMBED_KEY` as a Sites runtime secret (`GOOGLE_MAPS_EMBED_API_KEY` is also supported). Enable Maps
Embed API and Maps JavaScript API, and restrict the browser key to those APIs and these HTTP referrers:

- `https://di.n2wm787gnp.chatgpt.site/*`
- `https://ppgui.com/*`

Redeploy after changing runtime configuration. Google receives the key and
selected coordinates only when the user opens Street View. Embed keys are
browser-visible by design; never use an unrestricted general-purpose key.
Without configuration, the panel retains its Google Maps panorama link.
For local development, use the same variable in an ignored `.env.local` with
an appropriately restricted development key. The production build emits the
existing client under `dist/client` and the runtime route under `dist/server`.

The shared 3D camera supports equipment-scale inspection (about a 10 m vertical span on large networks) and a wider regional zoom-out. Keyboard pan and selection tolerance scale with zoom.

### Forecasting runtime

Tree models use real scikit-learn 1.7.0 in Pyodide 0.28.3. The vendored, unchanged skforecast 0.22.0 wheel is verified by SHA-256 before installation and retains its BSD license inside the wheel. `ForecasterRecursive` wraps `HistGradientBoostingRegressor`; the standalone Random Forest uses `RandomForestRegressor`. Both use recent lags, the configured seasonal lag, and UTC hour/weekday features. Each validation origin, final holdout, and future forecast fits a fresh estimator on only its bounded training prefix. Recursion consumes prior predictions, never future observations. Early stopping is disabled for boosting so no random internal validation split is introduced.

Numba JIT is unavailable in the browser. A narrowly scoped `njit` decorator adapter executes the pinned skforecast NumPy functions unchanged as ordinary Python; this compatibility mode is declared in the UI and exports. It does not provide the rest of Numba or claim support for all skforecast APIs. The runtime loads lazily, reuses libraries across runs, and is terminated on cancellation. Network failures remain explicit failed-model rows; available models may complete the benchmark. A selected model failing later fails the run rather than silently selecting another model from holdout performance.

References: [RandomForestRegressor](https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestRegressor.html), [skforecast recursive forecasting](https://skforecast.org/0.22.0/user_guides/autoregresive-forecaster.html), [Pyodide packages](https://pyodide.org/en/0.28.3/usage/packages-in-pyodide.html).

Optional real-WASM forecasting regression suite (Node 22+; installs test runtime outside the checkout):

```sh
npm install --prefix /tmp/itron-forecast-test pyodide@0.28.3
node scripts/test_forecast_wasm.mjs /tmp/itron-forecast-test/node_modules/pyodide/pyodide.mjs
```

This runs all four models and checks repeatability, validation/holdout isolation, interval calibration, refitting, zero-series behavior, feature metadata and library versions. The standard `npm test` also covers provider boundaries and failure handling without network access.

### Transformer Analyzer · Google 3D evaluation

The default visualization uses the real Google Maps JavaScript `Map3DElement` (`maps3d`, weekly channel). The Map selector also offers the existing Network 3D renderer for comparison. The server’s read-only, uncached `/transformer-analyzer/api/maps-config` route provides the same browser key used by Street View; no key is embedded in source or build artifacts. Maps JavaScript API must be enabled with billing and the key must allow that API and the site’s HTTP referrers.

The selected feeder’s line geometry, transformer markers, and connected modeled meters overlay Google imagery. Transformer positions use exact connected SMARTDS bus coordinates; line endpoints use exact bus positions and intermediate vertices preserve the model projection. Cameras target terrain-relative altitude because the source has no surveyed equipment elevations. Clicking equipment selects its study; the table centers the selected transformer, 2D/3D toggles tilt, and Fit network frames the feeder. Page navigation retains the iframe and map state. Imagery retains natural colors in both interface themes, and Google attribution remains unobscured.

These are synthetic SMARTDS model locations on real imagery, not surveyed utility assets. No Google imagery is stored or exported. Maps loading/authorization failures remain visible and users can choose Network 3D.

### Google 3D network geometry

The Google map hosts native `Model3DElement` pole/crossarm/insulator GLBs, interactive neutral transformer T models, and `Polyline3DElement` conductors. Overhead circuits retain the source phase count (one, two or three displayed phase wires); nearby spans use 10.5 m nominal attachment height, up to 55 m support spacing and up to 1.8 m sag. These are illustrative display assumptions, not measured clearances or a pole inventory. All transformer mounting values in the supplied dataset are unknown, so T symbols do not imply pole- or pad-mounted enclosures. Ground traces distinguish underground (purple), unspecified construction (gray) and switch connections (gold); open switches retain visible central gaps.

Details are limited to the nearest 100 spans, 160 supports and 32 transformer symbols when the camera range is at most 2,400 m; regional route overlays remain visible at every range. Debounced camera updates reuse existing elements and GLB URLs. Plan view and the 3D equipment toggle remove detailed models. New +/− controls complement Google's native camera gestures. Source positions and layer state survive page navigation and network changes.

First-party low-poly assets use core glTF PBR without extensions or textures. Regenerate them with `node scripts/build-network-models.mjs`; they are served from the same origin under `/models/`. Authoring geometry is Z-up with a ground-level origin for Google Maps orientation. Model geometry is deliberately independent of Google's imagery.

### Edge Agent · local data-quality expert

`#edge-agent` evaluates SMARTDS virtual meter packets in a dedicated Web Worker. The compact, portable JavaScript engine combines six specialist skills: identity/units, time integrity, completeness, electrical context, adaptive median/MAD anomalies, and stuck-signal review. Required contract, time and context skills cannot be disabled. The adaptive detector learns from prior normal samples, excludes contradictory electrical states and grid events, and clips reviewed statistical changes. This is an autonomous local expert-system prototype, not a generative language model or a deployed Itron device agent.

Accepted readings pass unchanged, contextual/statistical concerns pass with explicit review flags, invalid contracts/timestamps are held, and identical duplicates are suppressed. Coherent outages, restorations, voltage excursions and zero-load operation remain valid observations. Absence is recorded separately from invalidity; on-time coverage does not count later recovery. No value is imputed or silently repaired. The stress scenario injects declared incidents into otherwise deterministic profiles; the original-profile and coherent-outage scenarios support comparison.

Reports are scheduled every 15 minutes, 1 hour, 6 hours or 24 hours of replay time, with manual reports available. One real-time tick processes one simulated 15-minute interval. Critical/warning alert policies, per-meter incident cooldowns and acknowledgment controls limit repeats. Switching pages preserves the worker, policy, clock and retained history. Pausing freezes the replay clock. Closing/reloading ends the run; background browser throttling can slow it.

Memory is bounded: up to 64 meters with 16/32/64 samples per channel, 24 reports, 80 alerts/evidence items, 24 recent records and 48 chart points. At the default 16 meters × 32 samples × two Float64 channels, numeric model buffers total 8 KiB; this excludes JavaScript metadata, report history, browser and UI overhead. Batch p95 and round-trip timings are measured locally, not asserted hardware benchmarks. The agent downloads no model weights and makes no cloud inference calls.

Qualified batches, reports and alerts are emitted via a local `itron:edge-output` CustomEvent and same-origin `itron-edge-headend-simulator` BroadcastChannel, with run and message IDs. There is no physical AMI, MQTT or external HTTP destination. JSON export includes the complete scoped meter metadata, deterministic seeds, engine version, source clock, scenario, applied policy, counters and bounded retained evidence; it is not a full packet archive. A production deployment still needs a target-device runtime, authenticated headend transport, device-specific resource profiling and field-data validation.

### Gateway Agent · AMI access-point coordination

`#gateway-agent` adds four cooperating capabilities to one portable local controller: urgency-weighted EV fleet charging; microgrid island supervision and load balance; 60-frame/s PMU screening; and consent-aware behind-the-meter battery, solar and flexible-load aggregation. All four share the same active-power budget. Import/export limits, charger ratings, remaining EV energy, storage energy and reserve constraints are reconciled before emitting setpoints. Unmet deadlines, response shortfall and unserved load remain explicit.

The browser runs the kernel in a Worker with configurable 24/64/128-vehicle fleets and a four-times-speed scenario clock. Scenario controls independently interrupt WAN/grid supply, inject PMU disturbances, reduce solar, add load and withdraw DER participation. WAN loss never triggers islanding; local control continues and monitoring summaries queue within a fixed bound. Restoring WAN sends summaries, not stale controls. The page retains state across navigation and supports both existing themes.

The SMARTDS feeder name supplies study context only; access-point membership, controllable resources and PMU data are synthetic. Measured Worker compute time is separate from modeled WAN delay. PMU payload reduction counts encoded JSON frames versus summaries, events and snippets, without transport headers. High-frequency phasors are generated independently of 15-minute AMI profiles. Microgrid logic is supervisory, not a protection relay or stability model.

`gateway/` documents the portable Node 22+ runtime. `node scripts/package-gateway.mjs` packages the exact same dependency-free kernel and local JSONL runner at `public/gateway/gateway-runtime.tar.gz`; the build regenerates this download. The runner works without cloud connectivity and accepts a bounded local adapter interface. External telemetry produces proposed commands with expiry; physical execution/acknowledgment is not claimed. The supplied battery/EV state remains modeled, so field inventory ingestion, device drivers, interlocks, resource profiling and deployment to the user's specific AMI platform remain integration work. No hardware endpoint or device credentials have been configured.

The gateway regression suite checks electrical accounting under constrained fleets, export limits and high reserves; no energy creation; offline control and queue limits; islanding/grid-forming withdrawal/reconnection dwell; phasor monotonicity, gap handling and future-data rejection; consent withdrawal; and the actual downloadable runtime in an offline child process.
