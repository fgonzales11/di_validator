import {loadPyodide} from 'https://cdn.jsdelivr.net/pyodide/v0.28.3/full/pyodide.mjs';

const base=new URL('./',import.meta.url),solverBase=new URL('../powerflow/',base);
let runtime,catalog,busy=false;
const sha256=async bytes=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(b=>b.toString(16).padStart(2,'0')).join('');
const status=(id,message)=>self.postMessage({type:'status',id,message});
async function bytesAt(url){const response=await fetch(url);if(!response.ok)throw Error(`Study asset unavailable (${response.status}).`);return response.arrayBuffer()}
async function initialize(id){
 status(id,'Loading the browser solver and numerical libraries…');
 const py=await loadPyodide({indexURL:'https://cdn.jsdelivr.net/pyodide/v0.28.3/full/'});
 await py.loadPackage(['numpy','scipy','pandas','networkx','micropip','pydantic']);
 status(id,'Preparing multiconductor analysis…');
 await py.runPythonAsync(`import micropip
await micropip.install('packaging==25.0', reinstall=True)
await micropip.install(['pandapower==3.4.0', 'dotted-dict==2.0.0'])`);
 const solver=await bytesAt(new URL('multiconductor.zip',solverBase));
 if(await sha256(solver)!==catalog.solver_sha256)throw Error('Solver package integrity check failed. Reload and retry.');
 py.unpackArchive(solver,'zip',{extractDir:'/home/pyodide'});
 py.FS.mkdirTree('/home/pyodide/grid_analysis');
 py.FS.writeFile('/home/pyodide/grid_analysis/__init__.py','');
 for(const name of ['runner.py','settings.json'])py.FS.writeFile(`/home/pyodide/grid_analysis/${name}`,new Uint8Array(await bytesAt(new URL(name,base))));
 await py.runPythonAsync('from grid_analysis.runner import run_analysis');
 return py;
}
self.onmessage=async({data})=>{
 if(busy)return;busy=true;const id=data.id;
 try{
  catalog??=JSON.parse(new TextDecoder().decode(await bytesAt(new URL('manifest.json',solverBase))));
  const network=catalog.networks.find(n=>n.circuit===String(data.circuit));
  if(!network)throw Error('No electrical model is available for this feeder.');
  const py=await(runtime??=initialize(id).catch(error=>{runtime=undefined;throw error}));
  status(id,`Loading ${network.name}…`);
  const url=new URL(network.url,solverBase);if(url.origin!==base.origin)throw Error('The model must come from this site.');
  const compressed=await bytesAt(url);
  const bytes=await new Response(new Blob([compressed]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer();
  if(bytes.byteLength!==network.bytes||await sha256(bytes)!==network.sha256)throw Error('Network model integrity check failed. Reload and retry.');
  py.globals.set('_analysis_pickle',new Uint8Array(bytes));
  py.globals.set('_analysis_kind',data.analysis);
  py.globals.set('_analysis_parameters',JSON.stringify(data.parameters));
  py.globals.set('_analysis_progress',message=>status(id,String(message)));
  status(id,`Running ${String(data.analysis).replaceAll('_',' ')} · ${network.name}…`);
  try{
   const value=await py.runPythonAsync(`import json
_analysis_result = run_analysis(bytes(_analysis_pickle.to_py()), _analysis_kind, json.loads(_analysis_parameters), _analysis_progress)
json.dumps(_analysis_result, allow_nan=False)`);
   self.postMessage({type:'result',id,circuit:network.circuit,modelSha256:network.sha256,solverSha256:catalog.solver_sha256,result:JSON.parse(value)});
  }finally{
   for(const key of ['_analysis_pickle','_analysis_kind','_analysis_parameters','_analysis_progress','_analysis_result'])py.globals.delete(key);
   await py.runPythonAsync('import gc; gc.collect()');
  }
 }catch(error){
  const detail=(error.message||'Analysis failed.').trim().split('\n').filter(Boolean).at(-1);
  self.postMessage({type:'error',id,circuit:data.circuit,analysis:data.analysis,message:detail});
 }finally{busy=false}
};
