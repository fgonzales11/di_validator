"""Browser/native adapters for the supplied multiconductor run-book studies.

Only trusted catalog pickle bytes enter here. Every invocation unpickles a fresh
study copy; device settings and topology edits never affect another analysis.
"""
import json
import math
import pickle
import time
import warnings
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
import numpy as np
import pandas as pd
import multiconductor as mc
from multiconductor.addons.tools.browser_runtime import run_snapshot

DEFINITIONS = {x['id']: x for x in json.loads(Path(__file__).with_name('settings.json').read_text())}


def validate(analysis, parameters):
    if analysis not in DEFINITIONS:
        raise ValueError('Unknown analysis type')
    fields = DEFINITIONS[analysis]['fields']
    if set(parameters) != {f['key'] for f in fields}:
        raise ValueError('The study settings do not match the selected analysis')
    values = dict(parameters)
    for field in fields:
        key, value = field['key'], values[field['key']]
        if field['type'] == 'number':
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not field['min'] <= value <= field['max']:
                raise ValueError(f"{field['label']} is outside its supported range")
            if field['step'] == 1 and int(value) != value:
                raise ValueError(f"{field['label']} must be an integer")
        elif field['type'] == 'checkbox':
            if not isinstance(value, bool):
                raise ValueError(f'{key} must be true or false')
        elif field['type'] == 'select':
            if value not in [x[0] for x in field['options']]:
                raise ValueError(f'Unsupported {key}')
        elif value != 'auto':
            if str(value) != str(int(value)) or int(value) < 0:
                raise ValueError(f'Invalid {key}')
            values[key] = int(value)
    if analysis in ('hosting_capacity', 'optimal_power_flow') and values['min_vm_pu'] >= values['max_vm_pu']:
        raise ValueError('Maximum voltage must exceed minimum voltage')
    if analysis == 'protection' and values['instantaneous_ratio'] < values['pickup_ratio']:
        raise ValueError('Instantaneous pickup must be at least timed pickup')
    return values


def records(frame):
    if frame is None or not len(frame):
        return []
    frame = frame.copy()
    # Named native indices preserve bus, phase, conductor and case identity.
    for name in frame.index.names:
        if name is not None and name in frame.columns:
            frame = frame.drop(columns=[name])
    frame = frame.reset_index()
    for col in frame.columns:
        if frame[col].dtype == object:
            frame[col] = frame[col].map(lambda x: str(x) if isinstance(x, complex) else x)
    return json.loads(frame.to_json(orient='records', double_precision=12))


def finite(value):
    return float(value) if value is not None and np.isfinite(value) else None


def metric(label, value, unit='', note=''):
    return dict(label=label, value=value, unit=unit, note=note)


def study_points(net):
    sources = net.ext_grid_sequence
    rows = sources.loc[sources.in_service.fillna(True).astype(bool) & pd.to_numeric(sources.vm_pu, errors='coerce').fillna(0).ne(0)]
    if rows.empty:
        raise ValueError('No energized external source is available')
    source = int(rows.iloc[0].bus)
    connected = net.line.loc[net.line.in_service.fillna(True).astype(bool) & (net.line.from_bus.eq(source) | net.line.to_bus.eq(source))]
    if connected.empty:
        raise ValueError('The source has no in-service feeder-head line')
    line_id = int(connected.index.get_level_values(0)[0])
    line = connected.iloc[0]
    head = int(line.to_bus if int(line.from_bus) == source else line.from_bus)
    switches = net.switch
    downstream = switches.loc[switches.closed.fillna(False).astype(bool) & switches.et.astype(str).str.lower().eq('b') & (switches.bus.eq(head) | switches.element.eq(head))]
    fault = head if downstream.empty else int(downstream.iloc[0].element if int(downstream.iloc[0].bus) == head else downstream.iloc[0].bus)
    return dict(source_bus=source, source_id=int(rows.index.get_level_values(0)[0]), feeder_bus=head, fault_bus=fault, source_line_id=line_id)


def selected_bus(net, value, fallback, required=None):
    bus = fallback if value == 'auto' else int(value)
    if bus not in net.bus.index.get_level_values(0):
        raise ValueError(f'Bus {bus} is absent from this feeder')
    phases = sorted({int(x) for x in net.bus.xs(bus, level=0).index if int(x) > 0})
    if required and not set(required).issubset(phases):
        raise ValueError(f'Bus {bus} does not have phases {required}; select a compatible bus')
    return bus, phases


def short_circuit(net, p, protection=False):
    from multiconductor.shortcircuit import FaultSpec, calc_sc
    phases = {'LLL': (1, 2, 3), 'LG': (1,), 'LL': (1, 2), 'LLG': (1, 2)}[p['fault_type']]
    bus, _ = selected_bus(net, p['fault_bus'], study_points(net)['fault_bus'], phases)
    original = records(net.ext_grid_sequence)
    net.ext_grid_sequence.loc[:, 'r_ohm'] = p['source_r_ohm']
    net.ext_grid_sequence.loc[:, 'x_ohm'] = p['source_x_ohm']
    fault = FaultSpec(p['fault_type'], bus=bus, phases=phases, case=p['case'], r_fault_ohm=p['fault_r_ohm'], x_fault_ohm=p['fault_x_ohm'])
    calc_sc(net, fault_spec=fault, branch_results=True)
    duty = net.res_bus_sc.loc[net.res_bus_sc.faulted.fillna(False)]
    values = pd.to_numeric(duty.ikss_ka, errors='coerce').dropna().abs()
    output = dict(converged=True, message='Short-circuit duty calculated.',
                  notes=[f"Source impedance is a study assumption: {p['source_r_ohm']} + j{p['source_x_ohm']} Ω. Native phase convention: A=1, B=2, C=3; LG uses A, LL/LLG use A–B.", 'Duty is calculated current. Breaker interrupting ratings and coordination data were not supplied.'],
                  metrics=[metric('Fault bus', bus), metric('Maximum fault duty', finite(values.max()), 'kA'), metric('Fault type', p['fault_type']), metric('Duty case', p['case'])],
                  tables={'fault_duty': records(duty), 'line_duty': records(net.res_line_sc), 'transformer_duty': records(net.get('res_trafo_sc')), 'original_sources': original},
                  chart={'label': 'Faulted terminal duty', 'unit': 'kA', 'points': [dict(x=f"Phase {row['phase']}", value=row['ikss_ka']) for row in records(duty) if row.get('ikss_ka') is not None]})
    if not protection:
        return output
    from multiconductor.protection import create_dtoc, run_protection
    currents = pd.to_numeric(net.res_line_sc.ikss_ka, errors='coerce').dropna().abs()
    line_id = int(currents.idxmax()[0]) if p['relay_line'] == 'auto' else int(p['relay_line'])
    if line_id not in net.line.index.get_level_values(0) or line_id not in currents.index.get_level_values(0):
        raise ValueError('The relay line has no short-circuit result')
    current = float(currents.xs(line_id, level=0).max())
    if not np.isfinite(current) or current <= 0:
        raise ValueError('The selected relay line has no positive fault current')
    line = net.line.xs(line_id, level=0)
    relay_phases = tuple(sorted(set(pd.to_numeric(line.from_phase).astype(int)) - {0}))
    switch = int(mc.create_switch(net, bus=int(line.iloc[0].from_bus), phase=relay_phases, element=line_id, et='l', closed=True, name='Illustrative study relay'))
    net.pop('res_switch_sc', None)
    settings = dict(pickup_ka=p['pickup_ratio']*current, delay_s=p['delay_s'], instantaneous_ka=p['instantaneous_ratio']*current, instantaneous_delay_s=p['instantaneous_delay_s'])
    create_dtoc(net, switch, **settings)
    before = net.switch.closed.copy()
    timing = run_protection(net, scenario='sc', apply_trips=False, ordered=True)
    if not net.switch.closed.equals(before):
        raise RuntimeError('Protection analysis unexpectedly changed switch states')
    times = pd.to_numeric(timing.trip_time_s, errors='coerce').replace([np.inf, -np.inf], np.nan).dropna()
    output.update(message='Protection timing calculated.', metrics=[metric('Relay line', line_id), metric('Fault current', current, 'kA'), metric('Timed pickup', settings['pickup_ka'], 'kA'), metric('First trip', finite(times.min()), 's', 'No topology changes')])
    output['tables'] = {'relay_timing': records(timing), 'relay_settings': [dict(line=line_id, **settings)], 'coordination': records(net.get('res_protection_coordination')), **output['tables']}
    output['notes'].append('One demonstration DTOC relay uses pickup ratios derived from this calculated fault. This demonstrates timing; it is not an engineered coordination design.')
    return output


def contingency(net, p, progress):
    from multiconductor.contingency import generate_nminus1_cases, run_contingency
    cases = generate_nminus1_cases(net, element_types=('line',))
    active = set(net.line.loc[net.line.in_service.fillna(True).astype(bool)].index.get_level_values(0))
    cases = [case for case in cases if int(case.case_id.split(':')[-1]) in active]
    start = p['case_start']-1
    if start >= len(cases):
        raise ValueError(f'Only {len(cases)} in-service line contingencies are available')
    selected = cases[start:start+p['case_count']]
    frames = {key: [] for key in ('cases', 'buses', 'lines', 'transformers')}
    for i, case in enumerate(selected):
        progress(f'Contingency {i+1} of {len(selected)} · {case.case_id}')
        result = run_contingency(net, cases=[case], continue_on_failure=True, write_to_net=True, run_control=False, min_vm_pu=.95, max_vm_pu=1.05, max_loading_percent=100, pf_options={'MaxIter': p['MaxIter']})
        for key, frame in zip(frames, (result.case_table, result.bus_table, result.line_table, result.trafo_table)):
            frames[key].extend(records(frame))
    for row in frames['cases']:
        if not row.get('converged'):
            for key in ('voltage_violation_count', 'line_violation_count', 'trafo_violation_count'):
                row[key] = None
    rows = frames['cases']
    unsupplied = [r.get('unsupplied_p_mw') for r in rows if r.get('unsupplied_p_mw') is not None]
    return dict(converged=all(bool(r.get('converged')) for r in rows), message='Contingency cases completed.', metrics=[metric('Cases evaluated', len(rows)), metric('Islanded cases', sum(r.get('status') == 'islanded' for r in rows)), metric('Failed solves', sum(not r.get('converged') for r in rows)), metric('Maximum unsupplied load', max(unsupplied, default=None), 'MW')], tables=frames, notes=['N−1 line outages are independent study copies. A converged islanded case still has unsupplied load.', 'Screening limits: 0.95–1.05 pu and 100% equipment loading. Failed solves have unavailable violation counts.'], chart=dict(label='Unsupplied load by contingency', unit='MW', points=[dict(x=r.get('case_id', ''), value=r.get('unsupplied_p_mw')) for r in rows]))


def optimal_power_flow(net, p):
    from multiconductor.opf import create_poly_cost, run_opf, OPFNotConverged
    if net.asymmetric_sgen.empty:
        raise ValueError('This feeder has no generator for the tutorial cost model')
    for table in ('asymmetric_sgen', 'asymmetric_gen', 'asymmetric_load'):
        if table in net:
            net[table]['controllable'] = False
    net.bus.loc[net.bus.index.get_level_values('phase') != 0, 'min_vm_pu'] = p['min_vm_pu']
    net.bus.loc[net.bus.index.get_level_values('phase') != 0, 'max_vm_pu'] = p['max_vm_pu']
    net.line['max_loading_percent'] = p['max_loading_percent']
    net.trafo1ph['max_loading_percent'] = p['max_loading_percent']
    bad = []
    for table in ('asymmetric_load', 'asymmetric_sgen', 'asymmetric_gen'):
        if table not in net:
            continue
        for index, row in net[table].iterrows():
            rating = row.get('sn_mva')
            apparent = math.hypot(float(row.get('p_mw', 0)), float(row.get('q_mvar', 0)))
            if row.get('in_service', True) and pd.notna(rating) and rating > 0 and apparent > rating + 1e-9:
                bad.append(dict(element_type=table, element=int(index[0]), circuit=int(index[1]), apparent_mva=apparent, rating_mva=float(rating), exceedance_mva=apparent-rating))
    index, row = net.asymmetric_sgen.index[0], net.asymmetric_sgen.iloc[0]
    create_poly_cost(net, int(index[0]), 'asymmetric_sgen', phase=int(row.from_phase), circuit=int(index[1]), cp1_eur_per_mw=p['cost_per_mw'])
    try:
        result = run_opf(net)
    except OPFNotConverged as error:
        return dict(converged=False, message='Fixed-dispatch OPF is infeasible for these settings.', metrics=[metric('Dispatch mode', 'Fixed'), metric('Capability exceedances', len(bad)), metric('Objective', None), metric('Feasibility', 'Failed')], notes=[str(error), 'The supplied device ratings and dispatch are preserved. Positive sn_mva ratings apply to loads as well as generators; correct the underlying model before accepting OPF.'], tables={'capability_exceedances': bad})
    return dict(converged=bool(result.converged), message='Fixed-dispatch OPF is AC-feasible.', metrics=[metric('Objective', finite(result.objective)), metric('Dispatch mode', 'Fixed'), metric('Constraint rows', len(result.constraints)), metric('Iterations', int(result.iterations))], tables={'constraints': records(result.constraints), **{key: records(value) for key, value in net.items() if key.startswith('res_') and key in ('res_bus', 'res_line', 'res_trafo', 'res_cost')}}, notes=['Tutorial fixed-dispatch feasibility case. No device dispatch was optimized; cost is illustrative.'])


def grid_equivalent(net, p):
    from multiconductor.grid_equivalents import get_equivalent, solve_equivalent
    from multiconductor.studies import TerminalRef
    bus, phases = selected_bus(net, p['boundary_bus'], study_points(net)['feeder_bus'])
    if not phases:
        raise ValueError('The boundary has no phase terminals')
    net.pop('bus_geodata', None)
    equivalent = get_equivalent(net, 'multiport', boundary_buses=[TerminalRef(bus, phase) for phase in phases], validate=False)
    model = equivalent.model
    validation = asdict(model.validation)
    mismatch = float(validation['current_mismatch_max'])
    passed = bool(validation['passed']) and mismatch <= p['mismatch_tolerance']
    matrix = np.asarray(model.y_eq)
    conjugate = np.asarray(getattr(model.y_eq, 'conjugate_matrix', np.zeros_like(matrix)))
    result = solve_equivalent(equivalent, {'voltage': np.asarray(model.base_voltage)*p['voltage_scale']}) if passed else None
    terminals = [f'{terminal.bus}:{terminal.phase}' for terminal in model.boundary_terminals]
    matrix_rows = [dict(row=terminals[i], column=terminals[j], y_real=float(matrix[i,j].real), y_imag=float(matrix[i,j].imag), conjugate_real=float(conjugate[i,j].real), conjugate_imag=float(conjugate[i,j].imag)) for i in range(len(matrix)) for j in range(len(matrix))]
    return dict(converged=passed, message='Grid equivalent validated.' if passed else 'Grid equivalent did not pass validation; boundary results withheld.', metrics=[metric('Boundary bus', bus), metric('Boundary phases', len(terminals)), metric('Maximum current mismatch', finite(mismatch), 'pu'), metric('Validation', 'Passed' if passed else 'Failed')], tables={'boundary_solution': records(result.boundary_table) if result else [], 'validation': [validation], 'admittance': matrix_rows, 'current_offset': [dict(terminal=terminals[i], real=float(v.real), imag=float(v.imag)) for i,v in enumerate(model.i_offset)]}, notes=['Whole-network local multiport equivalent: all non-boundary nodes are eliminated. The source-only tutorial reduction does not validate on these SMARTDS models.', 'The conjugate admittance and current offsets are included. Boundary P/Q describes the driven port response to the voltage multiplier, not feeder demand. The equivalent is local to this operating point.'])


def load_allocation(net, p):
    from multiconductor.load_allocation.load_allocation import build_measurement_graph, get_simulated_measurement_value, run_load_allocation, get_downstream_load_indices
    point = study_points(net)
    if p['ignore_generators']:
        for key in ('asymmetric_sgen', 'asymmetric_gen'):
            if key in net:
                net[key]['in_service'] = False
    mc.run_pf(net, run_control=False)
    mid = mc.create_measurement(net, measurement_type='p', element_type='ext_grid', element=point['source_id'], value=0., std_dev=.01, side='from', name='Power Flow page target')
    baseline = float(get_simulated_measurement_value(net, net.measurement.loc[mid]))
    target = baseline*p['target_scale'] if p['target_mode'] == 'baseline' else p['target_mw']
    if target <= 0 or not np.isfinite(target):
        raise ValueError('Load allocation requires a finite positive feeder-head MW target')
    net.measurement.at[mid, 'value'] = target
    before = net.asymmetric_load[['p_mw', 'q_mvar']].copy()
    # Graph builder has no switch-state filter. Supply a topology-only copy with
    # active lines and closed bus switches so disconnected paths are not used.
    graph_net = deepcopy(net)
    graph_net.line = graph_net.line.loc[graph_net.line.in_service.fillna(True).astype(bool)]
    graph_net.switch = graph_net.switch.loc[graph_net.switch.closed.fillna(False).astype(bool) & graph_net.switch.et.astype(str).str.lower().eq('b')]
    graph = build_measurement_graph(graph_net)
    allocated = get_downstream_load_indices(net, graph, mid)
    run_load_allocation(net, graph, measurement_indices=[mid], tolerance=p['tolerance'], max_iter=p['max_iter'], ignore_generators=False, verbose=False)
    mc.run_pf(net, run_control=False)
    actual = float(get_simulated_measurement_value(net, net.measurement.loc[mid]))
    error = 100*(actual-target)/target
    after = net.asymmetric_load[['p_mw', 'q_mvar']].copy()
    after.columns = ['allocated_p_mw', 'allocated_q_mvar']
    after['original_p_mw'], after['original_q_mvar'] = before.p_mw, before.q_mvar
    after['eligible'] = after.index.isin(allocated)
    after['changed'] = (after.allocated_p_mw.sub(before.p_mw).abs() > 1e-10) | (after.allocated_q_mvar.sub(before.q_mvar).abs() > 1e-10)
    return dict(converged=abs(error)<=p['tolerance'], message='Load allocation met the target tolerance.' if abs(error)<=p['tolerance'] else 'Load allocation did not meet the target tolerance.', metrics=[metric('Head-power target', target, 'MW'), metric('Solved head power', actual, 'MW'), metric('Target error', error, '%'), metric('Loads adjusted', int(after.changed.sum()), note=f'{len(allocated)} eligible / {len(before)} model load rows')], tables={'allocated_loads': records(after), 'head_target': [dict(baseline_mw=baseline, target_mw=target, actual_mw=actual, error_percent=error)], 'bus_results': records(net.res_bus)}, notes=[('Demonstration target derived from solved baseline.' if p['target_mode']=='baseline' else 'Independent user-entered feeder-head target.'), 'Allocation adjusts only reachable downstream load rows and can change both P and Q. The table identifies adjusted rows.', 'Generation was disabled for both allocation and verification.' if p['ignore_generators'] else 'Generation remains in service as supplied.'])


def hosting_required_terminals(net):
    required = set()

    def add(bus, phase):
        if pd.notna(bus) and pd.notna(phase) and int(phase) in (1, 2, 3):
            required.add((int(bus), int(phase)))

    # Covers loads, generators, shunts, sources, and any similarly represented
    # one-bus device. Exclude metadata/results and explicitly open devices.
    for key, frame in net.items():
        if key == 'switch' or str(key).startswith('res_') or not isinstance(frame, pd.DataFrame):
            continue
        if not {'bus', 'from_phase', 'to_phase'}.issubset(frame.columns):
            continue
        for _, row in frame.iterrows():
            if not bool(row.get('in_service', True)) or not bool(row.get('closed', True)):
                continue
            add(row.bus, row.from_phase)
            add(row.bus, row.to_phase)

    for _, row in net.line.iterrows():
        if bool(row.get('in_service', True)):
            add(row.from_bus, row.from_phase)
            add(row.to_bus, row.to_phase)
    for index, row in net.trafo1ph.iterrows():
        if bool(row.get('in_service', True)):
            bus = index[net.trafo1ph.index.names.index('bus')]
            add(bus, row.from_phase)
            add(bus, row.to_phase)
    for _, row in net.switch.iterrows():
        if bool(row.get('in_service', True)) and bool(row.closed):
            add(row.bus, row.phase)
            if str(row.et).lower() == 'b':
                add(row.element, row.phase)
    return required


def hosting_voltage_rows(net):
    phases = net.res_bus.loc[net.res_bus.index.get_level_values('phase') != 0]
    required = hosting_required_terminals(net)
    lookup = np.asarray(net.model.terminal_to_y_lookup).reshape(-1)
    skipped = []
    keep = []
    for bus, phase in phases.index:
        key = (int(bus), int(phase))
        pos = key[0] * 4 + key[1]
        unmapped = 0 <= pos < len(lookup) and lookup[pos] < 0
        omit = unmapped and key not in required
        keep.append(not omit)
        if omit:
            skipped.append(dict(bus=key[0], phase=key[1], reason='Unmapped terminal with no active electrical attachment'))
    return phases.loc[keep], skipped


def hosting_capacity(net, p, progress):
    from multiconductor.contingency import _case_line_results
    bus, phases = selected_bus(net, p['connection_bus'], study_points(net)['fault_bus'], (1,2,3))
    rows, best, failed = [], None, None
    unused_terminals = []
    for step in range(p['steps']+1):
        mw = p['maximum_mw']*step/p['steps']
        progress(f'Hosting capacity · step {step+1}/{p["steps"]+1} · {mw:.3f} MW')
        trial = deepcopy(net)
        if mw:
            for phase in (1,2,3):
                mc.create_asymmetric_sgen(trial, bus=bus, from_phase=phase, to_phase=0, p_mw=mw/3, q_mvar=0., sn_mva=mw/3, name='Hosting study added generation')
        row = dict(added_mw=mw, bus=bus, converged=False, feasible=False, voltage_min_pu=None, voltage_max_pu=None, max_line_loading_percent=None, max_transformer_loading_percent=None, missing_rating_rows=None, reason='')
        try:
            mc.run_pf(trial, run_control=False, MaxIter=100)
            if not trial.model.solved:
                raise RuntimeError('Power flow did not converge')
            phase_rows, unused_terminals = hosting_voltage_rows(trial)
            volts = pd.to_numeric(phase_rows.vm_pu, errors='coerce')
            line = _case_line_results(trial, max_loading_percent=p['max_loading_percent'])
            line_load = pd.to_numeric(line.loading_percent, errors='coerce')
            trafo_load = pd.to_numeric(trial.res_trafo.loading_percent, errors='coerce')
            missing = int((~np.isfinite(line_load)).sum()+(~np.isfinite(trafo_load)).sum())
            low, high = finite(volts.min()), finite(volts.max())
            maximum_line, maximum_trafo = finite(line_load.max()), finite(trafo_load.max())
            reasons = []
            if not np.isfinite(volts).all() or (volts <= 0).any(): reasons.append('Unenergized / unavailable phase voltage')
            if low is not None and low < p['min_vm_pu']: reasons.append('Low voltage')
            if high is not None and high > p['max_vm_pu']: reasons.append('High voltage')
            if maximum_line is not None and maximum_line > p['max_loading_percent']: reasons.append('Line loading')
            if maximum_trafo is not None and maximum_trafo > p['max_loading_percent']: reasons.append('Transformer loading')
            if missing: reasons.append('Missing equipment ratings')
            row.update(converged=True, feasible=not reasons, voltage_min_pu=low, voltage_max_pu=high, max_line_loading_percent=maximum_line, max_transformer_loading_percent=maximum_trafo, missing_rating_rows=missing, excluded_unused_terminals=len(unused_terminals), reason='; '.join(reasons) or 'Within selected limits')
        except Exception as error:
            row['reason'] = str(error)
        rows.append(row)
        if row['feasible']:
            best = mw
        else:
            failed = mw
            break
    capped = failed is None and best is not None
    message = 'No tested hosting headroom: the baseline fails the screen.' if best is None else 'The scan maximum is feasible; capacity is at least this tested level.' if capped else 'Hosting scan reached a limiting interval.'
    return dict(converged=all(r['converged'] for r in rows), message=message, metrics=[metric('Tested feasible addition', best, 'MW', 'Lower bound · scan maximum' if capped else 'Last feasible scan point'), metric('First failing addition', failed, 'MW'), metric('Connection bus', bus), metric('Cases solved', sum(r['converged'] for r in rows), note=f'{len(rows)} evaluated')], tables={'capacity_scan': rows, 'excluded_unused_terminals': unused_terminals}, chart=dict(label='Maximum phase voltage by added generation', unit='pu', points=[dict(x=f'{r["added_mw"]:.3f} MW', value=r['voltage_max_pu']) for r in rows]), notes=['Single-snapshot, balanced three-phase generation at unity power factor. Existing electrical dispatch and ratings are retained.', 'This is a native multiconductor power-flow sweep, not the separate OpenDSS hosting wrapper. It stops at the first failed candidate; the interval between tested points is unresolved.', 'Unused, unmapped terminals with no active electrical attachments are excluded and listed separately. Missing ratings or required unenergized terminals prevent a candidate from passing. A feasible scan maximum is a lower bound, not a proven ultimate capacity.'])


def run_analysis(pickle_bytes, analysis, parameters, progress=lambda message: None):
    parameters = validate(analysis, parameters)
    started = time.perf_counter()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        if analysis == 'power_flow':
            result = run_snapshot(pickle_bytes, parameters)
            result.update(converged=True, message='Power flow converged.')
        else:
            net = pickle.loads(pickle_bytes)
            if analysis in ('short_circuit', 'protection'):
                result = short_circuit(net, parameters, analysis == 'protection')
            elif analysis == 'contingency': result = contingency(net, parameters, progress)
            elif analysis == 'optimal_power_flow': result = optimal_power_flow(net, parameters)
            elif analysis == 'grid_equivalent': result = grid_equivalent(net, parameters)
            elif analysis == 'load_allocation': result = load_allocation(net, parameters)
            else: result = hosting_capacity(net, parameters, progress)
    result.update(analysis=analysis, completed=True, parameters=parameters, seconds=time.perf_counter()-started, method='multiconductor browser run-book adapter')
    result['warnings'] = sorted({str(w.message) for w in caught if not issubclass(w.category, FutureWarning)})[:30]
    json.dumps(result, allow_nan=False)
    return result
