import { loadPyodide } from 'https://cdn.jsdelivr.net/pyodide/v0.28.3/full/pyodide.mjs';

const base = new URL('../powerflow/', import.meta.url);
let runtime, catalog, busy = false, phase = 'Reading model catalog';
const status = (id, message) => { phase=message; self.postMessage({ type: 'status', id, message }); };
const sha256 = async bytes => [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(b => b.toString(16).padStart(2, '0')).join('');

async function initialize(id) {
  status(id, 'Loading the WASM state estimator and numerical libraries…');
  const py = await loadPyodide({ indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.28.3/full/' });
  status(id, 'Loading numerical packages…');
  await py.loadPackage(['numpy', 'scipy', 'pandas', 'networkx', 'micropip', 'pydantic']);
  status(id, 'Preparing multiconductor…');
  await py.runPythonAsync(`
import micropip
await micropip.install('packaging==25.0', reinstall=True)
await micropip.install(['pandapower==3.4.0', 'dotted-dict==2.0.0'])
`);
  const response = await fetch(new URL('multiconductor.zip', base));
  if (!response.ok) throw new Error(`Solver package unavailable (${response.status}).`);
  const bytes = await response.arrayBuffer();
  if (await sha256(bytes) !== catalog.solver_sha256) throw new Error('Solver package integrity check failed. Reload and retry.');
  py.unpackArchive(bytes, 'zip', { extractDir: '/home/pyodide' });
  const adapter = await fetch(new URL('./runner.py', import.meta.url));
  if (!adapter.ok) throw new Error('The state-estimation adapter is unavailable.');
  await py.runPythonAsync(await adapter.text());
  return py;
}

self.onmessage = async ({ data }) => {
  if (busy) return;
  busy = true;
  const id = data.id;
  try {
    if (!catalog) {
      const response = await fetch(new URL('manifest.json', base));
      if (!response.ok) throw new Error('The network model catalog is unavailable.');
      catalog = await response.json();
    }
    const network = catalog.networks.find(n => n.circuit === String(data.circuit));
    if (!network) throw new Error('No electrical model is available for this circuit.');
    const py = await (runtime ??= initialize(id).catch(error => { runtime = undefined; throw error; }));
    status(id, `Loading ${network.name}…`);
    const url = new URL(network.url, new URL('manifest.json', base));
    if (url.origin !== base.origin) throw new Error('The model must come from this site.');
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Network model unavailable (${response.status}). Please retry shortly.`);
    const compressed = await response.arrayBuffer();
    const bytes = await new Response(new Blob([compressed]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer();
    if (bytes.byteLength !== network.bytes || await sha256(bytes) !== network.sha256) throw new Error('Network model integrity check failed. Reload and retry.');
    py.globals.set('_network_pickle', new Uint8Array(bytes));
    py.globals.set('_estimation_options', JSON.stringify(data.parameters));
    py.globals.set('_imported_measurements', JSON.stringify(data.measurements ?? null));
    status(id, `Estimating network state · ${network.name}…`);
    try {
      const value = await py.runPythonAsync(`
import json
result = run_estimation(bytes(_network_pickle.to_py()), json.loads(_estimation_options), json.loads(_imported_measurements))
json.dumps(result, allow_nan=False)
`);
      const result = JSON.parse(value);
      if (result.analysis !== 'state_estimation') throw new Error('Unexpected estimator response.');
      self.postMessage({ type: 'result', id, circuit: network.circuit, modelSha256: network.sha256, result });
    } finally {
      py.globals.delete('_network_pickle'); py.globals.delete('_estimation_options'); py.globals.delete('_imported_measurements');
    }
  } catch (error) {
    const detail = String(error.message || 'State estimation failed.').trim().split('\n').filter(Boolean).at(-1).replace(/^[\w.]+(?:Error|Exception):\s*/, '').slice(0, 1200);
    self.postMessage({ type: 'error', id, circuit: data.circuit, message: detail });
  } finally { busy = false; }
};
