"""Browser adapter for the bundled multiconductor state estimator.

Only the worker's integrity-checked catalog models are unpickled. Measurement
imports are JSON records, never Python or pickle input.
"""
import json
import math
import pickle
import time
import numpy as np
import pandas as pd
import multiconductor as mc
from multiconductor.pycci.state_estimator import (
    estimate, measurements_from_dataframe, measurements_from_power_flow,
    UnobservableNetworkError,
)


def finite(value):
    return float(value) if np.isfinite(value) else None


def records(frame):
    return json.loads(frame.to_json(orient="records", double_precision=12))


def validate_options(options):
    if options.get("source") not in ("model", "import", "synthetic"):
        raise ValueError("Choose model, imported, or synthetic measurements.")
    for key, low, high in (("tol", 1e-12, .01), ("objective_tol", 1e-14, .01),
                            ("bad_data_threshold", 1, 100), ("sigma", 1e-6, .1), ("sigma_power", 1e-6, .1)):
        value = options.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not low <= value <= high:
            raise ValueError(f"{key} must be between {low} and {high}.")
    for key, low, high in (("max_iter", 1, 100), ("max_bad_data", 0, 10), ("seed", 0, 2147483647)):
        value = options.get(key)
        if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
            raise ValueError(f"{key} must be an integer between {low} and {high}.")
    if not isinstance(options.get("noise"), bool):
        raise ValueError("Noise must be true or false.")
    return options


def initialize_from_measured_phasors(net, measurements):
    """Seed variable states from precision-weighted observed phasor pairs only.

    Values are already converted by the library into pu and radians. Unpaired
    readings leave native E0 unchanged; source and ground nodes are untouched.
    """
    from multiconductor.pycci.state_estimator import extract_se_matrices
    model = extract_se_matrices(net)
    initial = model.initial_voltage.copy()
    variable = set(int(n) for n in model.variable_nodes)
    weighted = {}
    for item in measurements.ordered_measurements():
        if item.kind not in {'v_real','v_imag','vm','va'} or item.index not in variable:
            continue
        weight = 1.0 / item.measurement.sigma ** 2
        value = item.measurement.value
        # Circular averaging prevents +179/-179 degrees averaging to zero.
        if item.kind == 'va': value = np.exp(1j*value)
        key=(item.index,item.kind)
        old_sum, old_weight = weighted.get(key,(0,0))
        weighted[key]=(old_sum+weight*value,old_weight+weight)
    means={key:value_sum/weight for key,(value_sum,weight) in weighted.items()}
    initialized=[]
    for node in model.variable_nodes:
        node=int(node)
        if (node,'v_real') in means and (node,'v_imag') in means:
            initial[node]=means[(node,'v_real')]+1j*means[(node,'v_imag')]
        elif (node,'vm') in means and (node,'va') in means and abs(means[(node,'va')])>1e-12:
            initial[node]=means[(node,'vm')]*np.exp(1j*np.angle(means[(node,'va')]))
        else: continue
        initialized.append(node)
    net.model.E0=initial.reshape(-1,1)
    return initialized


def run_estimation(pickle_bytes, options, imported=None):
    options = validate_options(options)
    net = pickle.loads(pickle_bytes)
    source = options["source"]
    started = time.perf_counter()
    if source == "synthetic":
        # Explicit validation/demo mode only; the subsequent WLS estimate is
        # computed by the library, not copied from these power-flow results.
        mc.run_pf(net, tol_vmag_pu=1e-7, tol_vang_rad=1e-7, MaxIter=100, run_control=False)
        measurements = measurements_from_power_flow(
            net, sigma_p=options["sigma_power"], sigma_q=options["sigma_power"],
            sigma_vm=options["sigma"], sigma_vpmu=options["sigma"],
            noise=options["noise"], seed=options["seed"],
        )
        input_count = len(measurements.ordered_measurements())
        excluded_count = 0
    else:
        if source == "import":
            if not isinstance(imported, list) or not 1 <= len(imported) <= 100000:
                raise ValueError("Import between 1 and 100,000 measurement rows.")
            frame = pd.DataFrame(imported)
        else:
            frame = net.get("measurement")
        if frame is None or frame.empty:
            raise ValueError("This model has no measurement rows. Import electrical measurements or explicitly select the synthetic demonstration.")
        required = {"measurement_type", "element_type", "element", "value", "std_dev"}
        if not required.issubset(frame.columns):
            raise ValueError("Measurement rows require measurement_type, element_type, element, value and std_dev.")
        input_count = len(frame)
        if "status" in frame:
            frame = frame[~frame.status.astype(str).str.lower().isin(["disabled", "inactive", "out_of_service", "rejected"])]
        excluded_count = input_count - len(frame)
        if frame.empty:
            raise ValueError("No enabled measurement rows remain.")
        units = {"p":"mw", "q":"mvar", "i":"ka", "im":"ka", "ia":"degree", "va":"degree", "v":"pu", "vm":"pu", "vr":"pu", "vi":"pu"}
        if "units" in frame:
            for _, row in frame.iterrows():
                unit = row.get("units")
                if pd.notna(unit) and str(unit).lower() != units.get(str(row.measurement_type).lower()):
                    raise ValueError("Measurement units must use MW, MVAr, kA, degree or pu as appropriate; convert value and std_dev before import.")
        measurements = measurements_from_dataframe(net, frame)
    initialized_nodes = initialize_from_measured_phasors(net, measurements)
    # The library result formatter expects E even on a fresh imported model.
    # Initialize its scratch voltage array without running power flow.
    if not hasattr(net.model, "E"):
        net.model.E = np.asarray(net.model.E0).reshape(-1, 1).copy()
    result = estimate(
        net, measurements, tol=options["tol"], max_iter=options["max_iter"],
        objective_tol=options["objective_tol"],
        bad_data_threshold=options["bad_data_threshold"] if options["max_bad_data"] else None,
        max_bad_data=options["max_bad_data"],
    )
    phases = result.res_bus.loc[result.res_bus.index.get_level_values("phase").isin([1, 2, 3])]
    energized = phases.vm_pu[np.isfinite(phases.vm_pu) & (phases.vm_pu > 0)]
    report = result.observability
    measurements_out = records(result.measurement_results)
    return {
        "analysis": "state_estimation", "solved": bool(result.converged),
        "converged": bool(result.converged), "measurement_source": source,
        "iterations": int(result.iterations), "seconds": time.perf_counter() - started,
        "voltage_min": finite(energized.min()), "voltage_max": finite(energized.max()),
        "voltage_violations": int(((energized < .95) | (energized > 1.05)).sum()),
        "unenergized_phase_terminals": int(len(phases) - len(energized)),
        "state_count": int(result.state_count), "initialized_from_measurements": len(initialized_nodes),
        "measurement_count": len(measurements.ordered_measurements()),
        "accepted_measurement_count": int(result.measurement_count),
        "input_measurement_count": input_count, "excluded_measurement_count": excluded_count,
        "rejected_measurement_count": len(result.bad_measurement_positions),
        "observable": bool(report.structural_rank >= report.state_count and (report.numeric_rank is None or report.numeric_rank >= report.state_count)),
        "observability_rank": int(report.structural_rank),
        "numeric_rank": None if report.numeric_rank is None else int(report.numeric_rank),
        "max_state_step": finite(result.error), "objective": finite(result.objective),
        "chi_square": finite(result.chi_square), "degrees_of_freedom": int(result.degrees_of_freedom),
        "p_value": finite(result.p_value),
        "max_standardized_residual": finite(np.max(np.abs(result.standardized_residuals))) if len(result.standardized_residuals) else None,
        "tables": {"res_bus": records(result.res_bus.reset_index()),
                   "res_line": records(result.res_line.reset_index()),
                   "res_trafo": records(result.res_trafo.reset_index()),
                   "res_measurement": measurements_out},
    }
