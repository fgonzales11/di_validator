"""Browser-safe adapter for DI Validator's unchanged offline fault functions.

Runtime dependencies: NumPy and pandas only. Inputs are calibrated waveform
JSON, never pickle or executable user content. See manifest.json for hashes.
"""
from dataclasses import dataclass
import math
import numpy as np
import pandas as pd

PHASES = ("IA", "IB", "IC", "UA", "UB", "UC")
PARAMETER_DEFAULTS = {
    "start": 0.0, "end": None, "manual_onset": None,
    "eta_i": 0.5, "eta_u": 0.85, "pre_seconds": 0.05, "post_seconds": 0.15,
    "fault_loop": "AUTO", "line_length_km": 50.0, "nominal_voltage_kv": 110.0,
    "base_power_mva": 100.0, "r1_ohm_km": 0.1, "x1_ohm_km": 0.4,
    "r0_ohm_km": None, "x0_ohm_km": None, "line_parameters_verified": False,
    "settle_cycles": 1.0, "average_cycles": 3, "min_current_ka": 0.001,
    "fault_current_fraction": 0.8, "max_cycle_spread": 0.5, "known_distance_km": None,
}
PARAMETER_OPTIONS = {
    "fault_loop": ["AUTO", "AG", "BG", "CG", "AB", "BC", "CA", "POS"],
    "units": {"start":"s", "end":"s", "manual_onset":"s", "pre_seconds":"s",
      "post_seconds":"s", "line_length_km":"km", "nominal_voltage_kv":"kV line-line",
      "base_power_mva":"MVA", "r1_ohm_km":"ohm/km", "x1_ohm_km":"ohm/km",
      "r0_ohm_km":"ohm/km", "x0_ohm_km":"ohm/km", "settle_cycles":"cycles",
      "average_cycles":"cycles", "min_current_ka":"kA", "known_distance_km":"km"},
    "ground_compensation":"Supply both r0_ohm_km and x0_ohm_km, or neither.",
    "limits":{"max_native_samples":200001,"max_analysis_intervals":200000,
              "max_feature_samples":200000,"max_samples_per_cycle":10000,
              "min_samples_per_cycle":4,"average_cycles":[1,50],"settle_cycles":[0,20],
              "pre_seconds_max":2,"post_seconds_max":2},
}

@dataclass
class Config:
    """Validated values used by the preserved source analyze_segment function."""
    values: dict
    def __getattr__(self, name):
        if name == 'channel_map': return {p:p for p in PHASES}
        try:return self.values[name]
        except KeyError:raise AttributeError(name) from None
    def line_params(self):
        return {"L_km":self.line_length_km,"Unom_kv":self.nominal_voltage_kv,
          "r1_ohm_km":self.r1_ohm_km,"x1_ohm_km":self.x1_ohm_km,
          "r0_ohm_km":self.r0_ohm_km,"x0_ohm_km":self.x0_ohm_km}


def _number(value, name, minimum=None, maximum=None, exclusive_min=False, exclusive_max=False):
    if isinstance(value,bool) or not isinstance(value,(int,float,np.number)) or not math.isfinite(value):
        raise ValueError(f'{name} must be a finite number.')
    value=float(value)
    if minimum is not None and (value<minimum or exclusive_min and value==minimum):
        raise ValueError(f'{name} is below its supported minimum.')
    if maximum is not None and (value>maximum or exclusive_max and value==maximum):
        raise ValueError(f'{name} is above its supported maximum.')
    return value


def validate_parameters(parameters=None):
    if parameters is None:parameters={}
    if not isinstance(parameters,dict):raise ValueError('parameters must be an object.')
    unknown=set(parameters)-set(PARAMETER_DEFAULTS)
    if unknown:raise ValueError('Unknown fault parameter(s): '+', '.join(sorted(unknown)))
    values={**PARAMETER_DEFAULTS,**parameters}
    positive=['eta_i','line_length_km','nominal_voltage_kv','base_power_mva','x1_ohm_km','min_current_ka','max_cycle_spread']
    for key in positive:values[key]=_number(values[key],key,0,exclusive_min=True)
    for key in ['start','r1_ohm_km']:values[key]=_number(values[key],key,0)
    values['eta_u']=_number(values['eta_u'],'eta_u',0,1,True,True)
    values['fault_current_fraction']=_number(values['fault_current_fraction'],'fault_current_fraction',0,1,exclusive_max=True)
    values['settle_cycles']=_number(values['settle_cycles'],'settle_cycles',0,20)
    for key in ['pre_seconds','post_seconds']:values[key]=_number(values[key],key,0,2,exclusive_min=True)
    cycles=values['average_cycles']
    if isinstance(cycles,bool) or not isinstance(cycles,(int,np.integer)) or not 1<=cycles<=50:
        raise ValueError('average_cycles must be a whole number from 1 to 50.')
    values['average_cycles']=int(cycles)
    for key in ['end','manual_onset','r0_ohm_km','x0_ohm_km','known_distance_km']:
        if values[key] is not None:values[key]=_number(values[key],key,0,exclusive_min=key in ['end','x0_ohm_km'])
    if values['fault_loop'] not in PARAMETER_OPTIONS['fault_loop']:raise ValueError('Select a supported fault loop.')
    if not isinstance(values['line_parameters_verified'],bool):raise ValueError('line_parameters_verified must be boolean.')
    if (values['r0_ohm_km'] is None)!=(values['x0_ohm_km'] is None):raise ValueError('Ground compensation requires both r0 and x0, or neither.')
    if values['end'] is not None and values['end']<=values['start']:raise ValueError('Analysis end must follow start.')
    if values['known_distance_km'] is not None and values['known_distance_km']>values['line_length_km']:raise ValueError('Known distance must lie within the configured line.')
    return Config(values)


def _plain(value):
    if isinstance(value,np.ndarray):return _plain(value.tolist())
    if isinstance(value,np.generic):return _plain(value.item())
    if isinstance(value,float):return value if math.isfinite(value) else None
    if isinstance(value,dict):return {str(k):_plain(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [_plain(v) for v in value]
    return value


def analyze_fault(payload):
    """Analyze {'record': waveformJSON, 'parameters': {...}, 'include_arrays': True}.

    Waveform keys: id, fs_hz, frequency_hz, time_seconds, channels containing
    IA/IB/IC in A and UA/UB/UC in V, units={'current':'A','voltage':'V'}.
    Missing values split segments. No timestamps or missing samples are invented.
    """
    from pipeline_core import analyze_segment
    if not isinstance(payload,dict) or not isinstance(payload.get('record'),dict):raise ValueError('Supply a record object.')
    record=payload['record'];cfg=validate_parameters(payload.get('parameters'))
    if record.get('units')!={'current':'A','voltage':'V'}:raise ValueError('Calibrated waveform inputs must declare current A and voltage V.')
    fs=_number(record.get('fs_hz'),'fs_hz',0,exclusive_min=True)
    f0=_number(record.get('frequency_hz'),'frequency_hz',0,exclusive_min=True)
    if not 4<=fs/f0<=10000:raise ValueError('Require 4 to 10,000 samples per electrical cycle.')
    times=np.asarray(record.get('time_seconds'),dtype=float)
    if times.ndim!=1 or not 1<=len(times)<=200001 or not np.isfinite(times).all() or np.any(times<0) or np.any(np.diff(times)<=0):raise ValueError('Provide 1–200,001 finite, ordered, nonnegative native sample times.')
    channels=record.get('channels')
    if not isinstance(channels,dict) or set(channels)!=set(PHASES):raise ValueError('Provide exactly IA, IB, IC, UA, UB, UC waveform channels.')
    arrays={p:np.asarray(channels[p],dtype=float) for p in PHASES}
    if any(x.ndim!=1 or len(x)!=len(times) for x in arrays.values()):raise ValueError('All waveform channels must match the sample times.')
    if np.any(np.abs(np.diff(times)*fs-np.rint(np.diff(times)*fs))>.01):raise ValueError('Sample timestamps must lie on the declared sample grid; no interpolation is performed.')
    if (cfg.pre_seconds+cfg.post_seconds)*fs>200000:raise ValueError('Requested feature window exceeds 200,000 samples.')
    end=min(cfg.end if cfg.end is not None else float(times[-1]),float(times[-1]))
    if end<=cfg.start or (end-cfg.start)*fs>200000:raise ValueError('Select a nonempty analysis window of at most 200,000 sample intervals.')
    if cfg.manual_onset is not None and not cfg.start<=cfg.manual_onset<=end:raise ValueError('Manual onset must lie inside the selected analysis window.')
    frame=pd.DataFrame({'offset':times,**arrays});frame=frame[(frame.offset>=cfg.start)&(frame.offset<=end)]
    if frame.empty:raise ValueError('The selected window contains no native samples.')
    times=frame.offset.to_numpy();finite=np.isfinite(frame[list(PHASES)].to_numpy()).all(axis=1)
    breaks=np.flatnonzero(np.diff(times)>1.5/fs)+1
    cuts=sorted(set([0,len(frame),*breaks.tolist(),*np.flatnonzero(~finite).tolist(),*(np.flatnonzero(~finite)+1).tolist()]))
    gaps=[(float(times[i-1]+1/fs),float(times[i])) for i in breaks]
    gaps += [(float(times[i]),float(times[i]+1/fs)) for i in np.flatnonzero(~finite)]
    if cfg.manual_onset is not None and (any(a<=cfg.manual_onset<b for a,b in gaps) or not times[0]<=cfg.manual_onset<=times[-1]):raise ValueError('Manual onset falls in a data gap or outside observed samples.')
    include_arrays=payload.get('include_arrays',True)
    if not isinstance(include_arrays,bool):raise ValueError('include_arrays must be boolean.')
    segments=[]
    for a,b in zip(cuts[:-1],cuts[1:]):
        if a==b or not finite[a]:continue
        info,diagnostics=analyze_segment(frame.iloc[a:b],{'sample_rate':fs,'config':{'nominal_frequency':f0}},cfg,len(segments))
        if include_arrays and diagnostics is not None:info['diagnostics']=diagnostics
        segments.append(info)
    return _plain({'format':'di-fault-result-v1','analysis':'fault_detection','source_record':str(record.get('id',record.get('source_record','uploaded waveform'))),'source_kind':record.get('source_kind','user-supplied waveform'),'source_pair_sha256':record.get('source_pair_sha256'),'fs_hz':fs,'frequency_hz':f0,'native_samples':len(frame),'parameters':cfg.values,'segments':segments,'gap_intervals':gaps,'detected_count':sum(x.get('inception_source')=='detected' for x in segments),'estimated_distance_count':sum(x.get('distance',{}).get('status')=='estimated' for x in segments),'provenance':{'method':'DI Validator offline inception, sequence features and single-ended simple reactance','decision_mode':'offline; full segment available','clock_verified':False,'line_parameters_verified':cfg.line_parameters_verified,'known_distance_supplied':cfg.known_distance_km is not None,'asset_association':'No verified association to SMARTDS assets.'}})
