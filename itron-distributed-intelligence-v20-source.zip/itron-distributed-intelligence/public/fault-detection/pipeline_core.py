"""Unchanged analyze_segment from DI Validator, with local numerical imports.

The browser adapter supplies only COMTRADE datasets. Wavewin network branches
in the preserved function are unreachable; no network-model module is needed.
"""
import numpy as np
from numerics import (LOW_RATE_SAMPLES_PER_CYCLE, classify_fault_type,
    detect_fault_inception, estimate_impedance_distance, estimate_peak_distance,
    extract_window, remove_dc_period, sliding_fortescue_magnitudes)
PHASES = ("IA", "IB", "IC", "UA", "UB", "UC")
TENSOR_CHANNELS = [*PHASES, "I1", "I2", "I0", "U1", "U2", "U0"]

def analyze_segment(frame, dataset, cfg, segment_number=0):
    """Process one finite, regularly spaced segment; no sample interpolation."""
    fs = dataset["sample_rate"]
    f0 = dataset["config"]["nominal_frequency"]
    period = int(round(fs / f0))
    info = dict(
        segment=segment_number,
        start=float(frame.offset.iloc[0]),
        end=float(frame.offset.iloc[-1]),
        measured_samples=len(frame),
        status="no_fault",
        reason="No fault inception met the combined RMS criterion",
    )
    if len(frame) < 2 * period:
        return {
            **info,
            "status": "insufficient_data",
            "reason": "Need at least two contiguous electrical cycles",
        }, None
    values = frame[[cfg.channel_map[p] for p in PHASES]].to_numpy(dtype=float).T / 1000
    centered = values - values[:, :period].mean(axis=1, keepdims=True)
    filtered = remove_dc_period(centered, fs, f0)
    detected, i_ratio, u_ratio = detect_fault_inception(
        *filtered, fs, f0, cfg.base_power_mva / (np.sqrt(3) * cfg.nominal_voltage_kv), cfg.eta_i, cfg.eta_u
    )
    manual = cfg.manual_onset is not None and info["start"] <= cfg.manual_onset <= info["end"]
    if cfg.manual_onset is not None and not manual:
        return {
            **info,
            "status": "outside_manual_selection",
            "reason": "Manual onset belongs to another segment",
        }, None
    if detected is None and not manual:
        if dataset.get("wavewin"):
            from .network_model import network_location

            info["network_location"] = network_location(
                dataset, values[:3], values[3:], fs, f0, 0, len(frame), cfg.fault_loop, cfg
            )
        return info, None
    center = int(np.argmin(np.abs(frame.offset.to_numpy() - cfg.manual_onset))) if manual else int(detected)
    npre, npost = round(cfg.pre_seconds * fs), round(cfg.post_seconds * fs)
    if min(npre, npost) < 1:
        raise ValueError("Pre/post windows must each contain at least one sample")
    windows = np.stack([extract_window(row, center, npre, npost) for row in filtered])
    sequences = np.vstack(
        [
            sliding_fortescue_magnitudes(filtered[:3], fs, f0),
            sliding_fortescue_magnitudes(filtered[3:], fs, f0),
        ]
    )
    seq_windows = np.stack([extract_window(row, center, npre, npost) for row in sequences])
    stop = min(npre + npost, npre + len(frame) - center)
    i0, i1, i2 = np.sqrt(np.mean(seq_windows[:3, npre:stop] ** 2, axis=1) / 2)
    kind, _, ratios = classify_fault_type(i1, i2, i0)
    loop = cfg.fault_loop
    phase_rms = np.sqrt(np.mean(windows[:3, npre:stop] ** 2, axis=1))
    if loop == "AUTO":
        if kind == "1ph-G":
            loop = "ABC"[int(np.argmax(phase_rms))] + "G"
        elif kind in {"2ph", "2ph-G"}:
            pair = frozenset(np.argsort(phase_rms)[-2:].tolist())
            loop = {frozenset([0, 1]): "AB", frozenset([1, 2]): "BC", frozenset([0, 2]): "CA"}[pair]
        elif kind == "3ph":
            loop = "POS"
    try:
        if loop == "AUTO":
            raise ValueError("Fault type is uncertain; select the fault loop explicitly")
        if period == LOW_RATE_SAMPLES_PER_CYCLE:
            # Relay reports at 4 samples/cycle: onset detection lags the fault, so
            # measure at the fault-current peak of the whole raw segment instead.
            distance = estimate_peak_distance(
                values[:3], values[3:], fs, center, cfg.line_params(), loop, cfg.min_current_ka
            )
        else:
            distance = estimate_impedance_distance(
                windows[:3],
                windows[3:],
                fs,
                f0,
                npre,
                stop,
                cfg.line_params(),
                loop,
                cfg.settle_cycles,
                cfg.average_cycles,
                cfg.min_current_ka,
                cfg.fault_current_fraction,
                cfg.max_cycle_spread,
            )
        if distance["status"] == "estimated" and cfg.known_distance_km is not None:
            distance["absolute_error_km"] = abs(distance["estimated_distance_km"] - cfg.known_distance_km)
    except ValueError as error:
        distance = dict(status="unavailable", reason=str(error))
    network = {}
    if dataset.get("wavewin"):
        from .network_model import network_location

        network = dict(
            network_location=network_location(dataset, values[:3], values[3:], fs, f0, center, len(frame), loop, cfg)
        )
    base_i = cfg.base_power_mva / (np.sqrt(3) * cfg.nominal_voltage_kv)
    base_u = cfg.nominal_voltage_kv / np.sqrt(3)
    tensor = np.vstack(
        [
            windows[:3] / base_i,
            windows[3:] / base_u,
            seq_windows[[1, 2, 0]] / base_i,
            seq_windows[[4, 5, 3]] / base_u,
        ]
    ).astype(np.float32)
    info.update(
        status="analyzed",
        reason=None,
        onset=float(frame.offset.iloc[center]),
        inception_source="manual" if manual else "detected",
        detected_sample=int(detected) if detected is not None else None,
        center_sample=center,
        fault_type_heuristic=kind,
        sequence_ratios=dict(negative_positive=float(ratios[0]), zero_positive=float(ratios[1])),
        loop_selection="heuristic" if cfg.fault_loop == "AUTO" else "manual",
        distance=distance,
        **network,
        padding_left_samples=max(0, npre - center),
        padding_right_samples=max(0, center + npost - len(frame)),
        pre_window_samples=npre,
        post_window_samples=npost,
        tensor_channels=TENSOR_CHANNELS,
        emitted_at=info["end"] + 1 / fs,
        decision_mode="offline; full segment available",
        tensor_shape=list(tensor.shape),
    )
    return info, dict(
        X=tensor,
        y=np.nan if cfg.known_distance_km is None else cfg.known_distance_km / cfg.line_length_km,
        time_seconds=frame.offset.to_numpy(),
        filtered_ka_kv=filtered,
        sequence_peak_ka_kv=sequences,
        current_ratio=i_ratio,
        voltage_ratio=u_ratio,
        window_time_ms=np.arange(-npre, npost) / fs * 1000,
    )
