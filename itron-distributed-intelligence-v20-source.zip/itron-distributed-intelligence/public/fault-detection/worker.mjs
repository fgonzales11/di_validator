import {loadPyodide} from 'https://cdn.jsdelivr.net/pyodide/v0.28.3/full/pyodide.mjs';
let runtime,manifest,busy=false;
const sha256=async bytes=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
const status=(id,message)=>self.postMessage({type:'status',id,message});
async function initialize(id){
 status(id,'Loading fault analysis in WebAssembly…');
 const py=await loadPyodide({indexURL:'https://cdn.jsdelivr.net/pyodide/v0.28.3/full/'});
 await py.loadPackage(['numpy','pandas']);
 const response=await fetch(new URL('manifest.json',import.meta.url));if(!response.ok)throw Error('Fault catalog unavailable.');manifest=await response.json();
 for(const name of ['numerics.py','pipeline_core.py','runner.py']){
  const r=await fetch(new URL(name,import.meta.url));if(!r.ok)throw Error('Fault analysis module unavailable.');const bytes=await r.arrayBuffer();if(await sha256(bytes)!==manifest.runtime_files[name])throw Error('Fault module integrity check failed.');py.FS.writeFile('/home/pyodide/'+name,new Uint8Array(bytes));
 }
 await py.runPythonAsync('from runner import analyze_fault\nimport json');return py;
}
self.onmessage=async({data})=>{if(busy)return;busy=true;const id=data.id;try{
 const py=await(runtime??=initialize(id).catch(e=>{runtime=null;throw e}));status(id,'Detecting inception, fitting phasors and estimating apparent distance…');
 py.globals.set('_fault_payload',JSON.stringify({record:data.record,parameters:data.parameters,include_arrays:true}));
 const result=JSON.parse(await py.runPythonAsync('json.dumps(analyze_fault(json.loads(_fault_payload)), allow_nan=False)'));py.globals.delete('_fault_payload');
 result.algorithmHashes=manifest.runtime_files;result.sourceAlgorithmHashes=manifest.source_files;result.recordingSha256=manifest.records.find(x=>x.id===data.record.id)?.sha256;result.virtualAssignment=data.assignment;result.runtime='Pyodide 0.28.3 / WebAssembly';self.postMessage({type:'result',id,result});
 }catch(e){self.postMessage({type:'error',id,message:String(e.message).trim().split('\n').filter(Boolean).at(-1)})}finally{busy=false}};
