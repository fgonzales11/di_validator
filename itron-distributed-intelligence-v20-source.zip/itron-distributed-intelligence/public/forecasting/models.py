"""Real sklearn and skforecast estimators, fitted to one training prefix only."""
import json
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor


def calendar(times):
    dates = pd.to_datetime(times, unit="ms", utc=True)
    hour = dates.hour + dates.minute / 60 + dates.second / 3600
    day = dates.dayofweek
    return np.column_stack((np.sin(2 * np.pi * hour / 24),
                            np.cos(2 * np.pi * hour / 24),
                            np.sin(2 * np.pi * day / 7),
                            np.cos(2 * np.pi * day / 7)))


def forecast_fit(payload):
    model, c = payload["model"], payload["config"]
    y = np.asarray(payload["values"], dtype=float)
    times, future = payload["times"], payload["future"]
    # The seasonal lag adds yesterday's same interval without using future data.
    lags = sorted(set(range(1, c["lags"] + 1)) | {c["seasonLength"]})
    names = [f"lag_{lag}" for lag in lags] + [
        "utc_hour_sin", "utc_hour_cos", "utc_weekday_sin", "utc_weekday_cos"]
    maximum = max(lags)
    exog = calendar(times)
    future_exog = calendar(future)
    if len(y) <= maximum:
        raise ValueError("Not enough training history for tree model lags.")
    if model == "random_forest":
        estimator = RandomForestRegressor(
            n_estimators=c["trees"], max_depth=c["maxDepth"],
            min_samples_leaf=c["minLeaf"], max_features=0.8,
            random_state=c["seed"], n_jobs=1)
        x = np.column_stack([y[maximum-lag:len(y)-lag] for lag in lags] +
                            [exog[maximum:, i] for i in range(4)])
        estimator.fit(x, y[maximum:])
        history, prediction = y.tolist(), []
        for row in future_exog:
            features = [history[-lag] for lag in lags] + row.tolist()
            value = float(estimator.predict(np.asarray([features]))[0])
            prediction.append(value)
            history.append(value)
        provider = "scikit-learn"
        provider_version = sklearn.__version__
        importance = dict(zip(names, estimator.feature_importances_.tolist()))
    elif model == "skforecast_boosting":
        import skforecast
        from skforecast.recursive import ForecasterRecursive
        estimator = HistGradientBoostingRegressor(
            max_iter=c["trees"], max_depth=c["maxDepth"],
            min_samples_leaf=c["minLeaf"], learning_rate=0.05,
            early_stopping=False, random_state=c["seed"])
        forecaster = ForecasterRecursive(estimator=estimator, lags=lags)
        columns = names[-4:]
        forecaster.fit(y=pd.Series(y), exog=pd.DataFrame(exog, columns=columns),
                       store_in_sample_residuals=False)
        predicted = forecaster.predict(steps=len(future), exog=pd.DataFrame(
            future_exog, columns=columns, index=pd.RangeIndex(len(y), len(y) + len(future))))
        prediction = predicted.to_numpy().tolist()
        provider, provider_version = "skforecast", skforecast.__version__
        importance = None
    else:
        raise ValueError("Unsupported Python forecasting model.")
    return {"prediction": prediction, "artifact": {
        "model": model, "version": 1, "provider": provider,
        "providerVersion": provider_version, "sklearnVersion": sklearn.__version__,
        "estimator": type(estimator).__name__, "estimatorModule": type(estimator).__module__, "strategy": "recursive",
        "parameters": estimator.get_params(), "lags": lags, "features": names,
        "featureImportances": importance, "trainingRows": len(y) - maximum,
        "trainedFrom": times[0], "trainedThrough": times[-1],
        "calendarBasis": "UTC", "seed": c["seed"]}}


def forecast_json(payload):
    return json.dumps(forecast_fit(json.loads(payload)), allow_nan=False)
