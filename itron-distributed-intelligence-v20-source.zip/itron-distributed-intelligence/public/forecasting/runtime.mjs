import {loadPyodide} from 'https://cdn.jsdelivr.net/pyodide/v0.28.3/full/pyodide.mjs';

const indexURL='https://cdn.jsdelivr.net/pyodide/v0.28.3/full/';
const wheel='skforecast-0.22.0-py3-none-any.whl';
const wheelHash='75cb96b926d10d57a24b3cf86345d71e86e638cfb2aeb55005d054ecb6d41a31';
let runtime,skforecastReady;
const sha256=async bytes=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
async function getRuntime(status){
  return runtime??= (async()=>{
    status('Loading Python and scikit-learn in WebAssembly…');
    const py=await loadPyodide({indexURL});
    await py.loadPackage(['numpy','pandas','scikit-learn']);
    const response=await fetch(new URL('models.py',import.meta.url));
    if(!response.ok)throw Error('Forecast model module could not be loaded. Retry the forecast.');
    const bytes=await response.arrayBuffer();
    py.FS.writeFile('/home/pyodide/forecast_models.py',new Uint8Array(bytes));
    await py.runPythonAsync('from forecast_models import forecast_json');
    return {py,sourceHash:await sha256(bytes)};
  })().catch(error=>{runtime=null;throw error});
}
async function loadSkforecast(py,status){
  return skforecastReady??= (async()=>{
    status('Loading skforecast and its forecasting dependencies…');
    await py.loadPackage(['micropip','tqdm','rich']);
    const response=await fetch(new URL(wheel,import.meta.url));
    if(!response.ok)throw Error('skforecast could not be downloaded. Retry the forecast.');
    const bytes=await response.arrayBuffer();
    if(await sha256(bytes)!==wheelHash)throw Error('skforecast package integrity check failed.');
    py.FS.writeFile('/home/pyodide/'+wheel,new Uint8Array(bytes));
    await py.runPythonAsync(`
import micropip
await micropip.install('emfs:/home/pyodide/${wheel}', deps=False)
await micropip.install(['packaging==25.0', 'optuna==4.5.0', 'alembic==1.20.0', 'Mako==1.4.3', 'colorlog==6.12.0'])
# WebAssembly does not support Numba JIT. Keep skforecast's original NumPy
# functions intact and execute them as ordinary Python. Only njit is needed
# by the pinned recursive forecaster; this is not a general Numba replacement.
import sys, types, importlib.machinery
_nojit = types.ModuleType('numba')
_nojit.__spec__ = importlib.machinery.ModuleSpec('numba', loader=None)
def _njit(*args, **kwargs):
    if len(args) == 1 and callable(args[0]):
        return args[0]
    return lambda function: function
_nojit.njit = _njit
sys.modules['numba'] = _nojit
from skforecast.recursive import ForecasterRecursive
`);
  })().catch(error=>{skforecastReady=null;throw error});
}
export async function fitPythonForecast(payload,status){
  const {py,sourceHash}=await getRuntime(status);
  if(payload.model==='skforecast_boosting')await loadSkforecast(py,status);
  py.globals.set('_forecast_payload',JSON.stringify(payload));
  try {
    const result=JSON.parse(await py.runPythonAsync('forecast_json(_forecast_payload)'));
    result.artifact.runtime='Pyodide 0.28.3 / WebAssembly';
    result.artifact.sourceSha256=sourceHash;
    if(payload.model==='skforecast_boosting'){
      result.artifact.packageSha256=wheelHash;
      result.artifact.jit='Disabled: skforecast NumPy functions run without Numba JIT';
    }
    return result;
  } finally { py.globals.delete('_forecast_payload'); }
}
