import {once} from 'node:events';
import {randomUUID} from 'node:crypto';
import {createQualityAgent,validateEdgeBatch,validateEdgeConfig,EDGE_ENGINE_VERSION} from './edge-quality.mjs';

// Transport-neutral: stdin is a collector adapter, stdout is a headend adapter.
// No network listeners, credentials, dependency installs or generated telemetry.
const live=process.argv.includes('--live');
let agent,runId,intervalMs,nextAt,buffer=[],times=[],timer,clockFault=false;
let reportIds=new Set(),alertIds=new Set(),pending=Promise.resolve(),ticking=false;
const serial=task=>{const result=pending.then(task);pending=result.catch(()=>{});return result};
async function emit(type,data={}){
  const line=JSON.stringify({type,runId,...data})+'\n';
  if(!process.stdout.write(line))await once(process.stdout,'drain');
}
function metrics(){
  const sorted=[...times].sort((a,b)=>a-b);
  return {batchP95Ms:sorted[Math.max(0,Math.ceil(sorted.length*.95)-1)]??0,batchesMeasured:times.length,processRssBytes:process.memoryUsage().rss};
}
async function outputs(state){
  for(const [kind,items,known] of [['alert',state.alerts,alertIds],['report',state.reports,reportIds]]){
    for(const item of items)if(!known.has(item.id)){
      await emit(kind,{delivery:'Emitted to stdout; headend receipt unconfirmed',payload:item});
      known.add(item.id);if(known.size>128)known.delete(known.values().next().value);
    }
  }
}
async function processBatch(records,at){
  const t=performance.now(),state=agent.process(records,at);
  times.push(performance.now()-t);if(times.length>64)times.shift();
  nextAt=at+intervalMs;
  await emit('qualified_records',{at,records:state.qualifiedBatch,totals:state.totals,modelBufferBytes:state.modelBufferBytes,metrics:metrics(),delivery:'Emitted to stdout; headend receipt unconfirmed'});
  await outputs(state);
}
async function advanceLive(){
  if(!live||!agent||clockFault)return;
  const now=Date.now(),due=Math.max(0,Math.floor((now-nextAt)/intervalMs));
  if(due>64){clockFault=true;await emit('error',{message:'More than 64 intervals elapsed. Live processing paused; configure a new run and reconcile the gap in the headend.'});return}
  for(let i=0;i<due;i++){
    const records=buffer;buffer=[];
    await processBatch(records,nextAt);
  }
}
async function handle(message){
  if(!message||typeof message!=='object'||Array.isArray(message))throw Error('Expected a JSON command object.');
  if(message.type==='configure'){
    const config=validateEdgeConfig(message.config);
    if(typeof message.source!=='string'||!message.source.trim())throw Error('Name the supplied reading source.');
    const start=live?Math.floor(Date.now()/config.intervalMs)*config.intervalMs:message.start;
    if(live&&message.start!==undefined)throw Error('Live mode uses the local clock; omit start.');
    const next=createQualityAgent({meters:message.meters,config,start,provenance:{mode:'adapter',source:message.source,delivery:'Local stdout adapter; headend receipt unconfirmed'}});
    agent=next;runId=randomUUID();intervalMs=config.intervalMs;nextAt=start;buffer=[];times=[];reportIds=new Set();alertIds=new Set();clockFault=false;
    await emit('configured',{clock:live?'wall':'manual',start,nextIntervalEnd:start+intervalMs,engineVersion:EDGE_ENGINE_VERSION,scope:agent.export().scope,policy:config});return;
  }
  if(!agent)throw Error('Configure the agent before supplying readings.');
  await advanceLive();
  if(clockFault&&!['export','snapshot'].includes(message.type))throw Error('Live clock fault; configure a new run before processing.');
  if(message.type==='batch'){
    if(live)throw Error('Use readings in live mode; its clock closes each interval.');
    await processBatch(message.records,message.at);return;
  }
  if(message.type==='readings'){
    if(!live)throw Error('Use batch with an explicit interval timestamp in manual mode.');
    validateEdgeBatch(message.records);
    buffer=validateEdgeBatch([...buffer,...message.records]);
    await emit('buffered',{count:buffer.length,intervalStart:nextAt,intervalEnd:nextAt+intervalMs});return;
  }
  if(message.type==='report'){agent.report();await outputs(agent.snapshot());return}
  if(message.type==='acknowledge'){
    if(typeof message.alertId!=='string'||!agent.snapshot().alerts.some(a=>a.id===message.alertId))throw Error('Unknown retained alert ID.');
    agent.acknowledge(message.alertId);await emit('acknowledged',{alertId:message.alertId,meaning:'Operator reviewed alert; not a delivery acknowledgment'});return;
  }
  if(message.type==='snapshot'){await emit('snapshot',{state:agent.snapshot(),metrics:metrics(),buffered:buffer.length,clockFault});return}
  if(message.type==='export'){await emit('export',{payload:agent.export(),metrics:metrics(),buffered:buffer.length,clockFault});return}
  throw Error('Unknown command. Use configure, batch/readings, report, acknowledge, snapshot or export.');
}
async function consume(line){
  if(!line.trim())return;
  try{await handle(JSON.parse(line))}catch(error){await emit('error',{message:error.message})}
}
if(live)timer=setInterval(()=>{
  if(ticking)return;ticking=true;
  serial(advanceLive).catch(error=>emit('error',{message:error.message})).finally(()=>{ticking=false});
},Math.min(1000,250));
process.stdout.on('error',error=>{if(error.code==='EPIPE')process.exit(0);throw error});

// Limit frames before JSON parsing and await every output, including drain.
const maxLineBytes=65536;
let chunks=[],length=0,discard=false;
try{
  for await(const chunk of process.stdin){
    let offset=0;
    while(offset<chunk.length){
      const end=chunk.indexOf(10,offset),part=chunk.subarray(offset,end<0?chunk.length:end);
      if(!discard){
        length+=part.length;
        if(length>maxLineBytes){chunks=[];discard=true;await serial(()=>emit('error',{message:'Input frame exceeds 64 KiB; discarded.'}))}
        else chunks.push(part);
      }
      if(end<0)break;
      if(!discard){const line=Buffer.concat(chunks,length).toString('utf8');await serial(()=>consume(line))}
      chunks=[];length=0;discard=false;offset=end+1;
    }
  }
  if(length&&!discard){const line=Buffer.concat(chunks,length).toString('utf8');await serial(()=>consume(line))}
  await pending;
}finally{clearInterval(timer)}
