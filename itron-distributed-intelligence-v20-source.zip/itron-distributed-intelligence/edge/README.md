# iTron Edge Agent runtime

A compact data-quality expert for a collector-side adapter. The same dependency-free
JavaScript kernel powers the app's Edge Agent page. It combines electrical rules,
data contracts and an adaptive median/MAD baseline; no language model, cloud
inference or model download is required. It never invents replacement readings.

## Run locally

Requires Node.js 22 or newer. Extract the archive and run:

```sh
node edge-runner.mjs < example.ndjson
```

The example supplies labeled fixture readings, including a contract failure and a
missing interval. The runtime itself never generates readings. Commands are JSON
objects, one per stdin line; responses, qualified readings, alerts and reports are
JSON objects on stdout. A transport adapter supplies actual collector readings and
forwards outputs to the headend over the site's authenticated transport. This
package has no network listener, MQTT client, remote destination or credentials.

## Manual interval clock

Configure an inventory and interval start in epoch milliseconds:

```json
{"type":"configure","source":"Collector AP-01","start":1790812800000,"meters":[{"id":"M-1","circuit":"F-1","inputLoadKw":10,"allowsExport":true}],"config":{"intervalMs":900000,"reportMinutes":60,"window":32,"alertSeverity":"warning","cooldownMinutes":60}}
```

Submit each completed interval, starting at `start`, then advancing exactly by
`intervalMs`. Submit an empty array for a missing interval:

```json
{"type":"batch","at":1790812800000,"records":[{"meterId":"M-1","circuit":"F-1","timestamp":1790812800000,"load_kw":4.2,"voltage_pu":1.01,"power":"on","units":{"load":"kW","voltage":"pu","timestamp":"ms"}}]}
{"type":"batch","at":1790813700000,"records":[]}
{"type":"report"}
{"type":"export"}
```

The source label is required and preserved in reports. Meter and circuit IDs are
nonempty strings of at most 128 characters. Optional `inputLoadKw` and
`baselineVoltagePu` must be finite and nonnegative. `allowsExport: true` declares
bidirectional metering; otherwise negative readings receive a context review flag.
The timestamp is the interval's start, not its arrival time. Convert units and
interval labels in the collector adapter; the agent never guesses them.

## Live interval clock

```sh
node edge-runner.mjs --live
```

Keep stdin open. Send `configure` as above, but omit `start`. The runtime chooses
the current UTC interval from the local system clock. Send packets using
`{"type":"readings","records":[...]}`; use the returned `intervalStart` timestamp.
When an interval ends, the clock screens its buffered records even during input
silence. Missing-reading findings and scheduled reports therefore continue while
the process and output consumer remain available. `batch` is disabled in live mode.
The first interval may be partial if the process starts mid-interval.

Live polling runs every 250 ms and catches up at most 64 intervals after a stall.
A longer gap pauses live processing with an explicit error; export the run,
reconcile the gap at the headend and configure again. Synchronize the device clock.
Process shutdown loses in-memory state; durable buffering/restart recovery belong
to the device integration. Backpressure pauses processing instead of accumulating
unbounded output. A stalled consumer must be monitored by the device supervisor.

## Policies and skills

- Required: identity/units, time integrity, electrical context.
- Optional skill IDs: `coverage`, `anomaly`, `stuck`. Omit `skills` to enable all.
- `window`: 16, 32 or 64 samples; anomaly detection warms up after eight samples.
- `reportMinutes`: 15, 60, 360 or 1440. Scheduled by completed input intervals.
- `intervalMs`: an integer of at least 1000 that divides the report interval.
- `alertSeverity`: `critical`, `warning` (includes critical), or `off`.
- `cooldownMinutes`: 15, 60 or 360, per meter and finding code.

Coherent outages and restorations remain valid observations. An anomaly is a
review flag, not proof of bad data. Duplicates are suppressed, conflicting copies
are held, and held records never reach `qualified_records`. Forwarded values stay
unchanged. Noisy changes cannot replace the baseline in one step. Import/export
context and electrical thresholds must be validated for the installed meters.

`report` emits an on-demand report for the current nonempty window. `snapshot`
returns retained state. `export` includes inventory, policy, skill manifest,
provenance and retained evidence. `{"type":"acknowledge","alertId":"AL-1"}`
records an operator review; it does not acknowledge headend delivery.

## Delivery and resource budget

Each output carries a UUID `runId`; deduplicate alerts/reports downstream using
`runId` plus payload ID. Emission to stdout does **not** confirm headend receipt.
Use an authenticated, durable delivery adapter with receipts/retries as needed.
No external messages are sent by this runtime.

Limits: 64 meters, 192 records per batch, 4 KiB per record, 64 KiB per input frame,
24 reports, 80 alerts, 80 evidence entries, 24 recent readings and 48 history points.
Two Float64 rolling buffers per meter consume at most **64 KiB** (64 meters ×
64 samples × 2 channels × 8 bytes). Total process memory is larger: objects,
retained reports and the Node runtime are excluded from this buffer figure.
Outputs include measured batch p95 compute and process RSS. The archive's manifest
reports compressed download and JavaScript source bytes, not installed RAM.

This is portable software, not a verified deployment on a specific AMI device.
Confirm the target OS/runtime, memory/CPU budget, acquisition and delivery adapters,
clock discipline, watchdog and persistence before field operation. Sensor accuracy,
CT/PT wiring, calibration and revenue-meter certification cannot be proven from
the supplied load/voltage/status channels alone.
