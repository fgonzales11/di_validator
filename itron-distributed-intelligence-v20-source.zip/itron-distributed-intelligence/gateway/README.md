# iTron Gateway Agent runtime

A dependency-free local controller for EV charging, microgrid supervision, PMU
screening and behind-the-meter DER aggregation. Requires Node.js 22 or newer.
The web page demonstrates synthetic resources; the downloadable adapter mode
uses supplied equipment inventories and measured device feedback. Both share
the weighted allocation and phasor-monitoring primitives. No cloud inference,
model download or network access is needed to compute proposals.

This package is not installed on a physical AMI collector by the website. The
collector platform, device drivers, protection interlocks and headend transport
must be connected and validated on the target. These are supervisory active-power
proposals, not certified protection, switching or AC stability controls.

## Start the runtime

```sh
node gateway-runner.mjs
```

Supply newline-delimited JSON on stdin and consume JSON responses on stdout.
There is no HTTP listener or external connection. The parser limits each frame
to 64 KiB and honors stdout backpressure. Launch the process under the collector's
supervisor; it must enforce command expiry even if this process stalls or stops.

Configuration requires an explicit `mode`: `adapter` or `simulation`. A rejected
configuration leaves the previous run intact. Successful configuration starts a
new session and clears in-memory history. Restart persistence belongs to the
collector integration.

## Configure measured-device mode

```json
{"type":"configure","mode":"adapter","networkId":"AP-5","config":{"importLimitKw":50,"exportLimitKw":0,"responseKw":10,"reservePct":20,"reconnectSeconds":10},"inventory":{"pcc":{"id":"AP-5/PCC"},"vehicles":[{"id":"Depot/charger-A","maxKw":11,"chargeEfficiency":0.92}],"batteries":[{"id":"Community/BESS","capacityKwh":40,"maxChargeKw":20,"maxDischargeKw":20,"chargeEfficiency":0.95,"dischargeEfficiency":0.95,"gridForming":true}],"solar":[{"id":"Roof/PV","maxKw":20}],"flex":[{"id":"Building/HVAC","maxKw":15}]}}
```

The response supplies a newly generated `sessionId`. Include this exact ID in
all telemetry and acknowledgment packets. A prior session cannot acknowledge
commands in a new run. All IDs are nonempty, globally unique strings, limited to
128 characters. Classes may be empty. Limits are 128 chargers, eight batteries,
32 PV resources and 32 flexible loads. Declared efficiencies must be 0.1–1;
validate these values for the installed devices. Fleet size in the demo policy
does not create assets in adapter mode.

## Supply complete telemetry

Send `{"type":"telemetry","telemetry":{...}}`. Required envelope fields:

| Field | Meaning |
| --- | --- |
| `sessionId` | ID returned by configure |
| `sequence` | Increasing positive integer; sequence gaps are allowed |
| `observedAtMs` | Current observation time in epoch milliseconds |
| `baseLoadKw` | Non-EV demand estimate before flexible-load reduction; excludes PV/storage power |
| `criticalLoadKw` | Portion of baseline demand that flexible shedding cannot reduce |
| `gridAvailable`, `wanOnline` | Independent booleans; WAN loss does not request islanding |
| `syncAngleDeg` | Measured local-to-upstream phase difference |
| `pcc` | `{observedAtMs, position, powerKw, busEnergized}`; position is `open`, `closed` or `unknown` |
| `interlocks` | `{canOpen, canClose, canIsland, trip}` booleans from the local protection/device supervisor |
| `devices` | Feedback records described below |
| `pmuFrames` | Zero to 240 measured phasors; no synthetic fallback |

The envelope must be at most one second old and newer than the prior accepted
observation. Each device and PCC observation is checked against the gateway's
current clock, not only against the envelope. Future timestamps are rejected.
The PCC import sign is positive. An open PCC with more than 0.1 kW measured
interchange, or an available grid/closed PCC with a deenergized bus, inhibits
normal dispatch. Thresholds must be commissioned for the actual instruments.

Each device record contains `assetId`, `observedAtMs`, `connected`, `consent` and
`actualKw`, plus these fields:

| Inventory class | Required feedback |
| --- | --- |
| `vehicles` | `availableKw`, `remainingKwh`, `deliveredKwh`, `departureAtMs`, `chargeSessionId` |
| `batteries` | `energyKwh`, `availableChargeKw`, `availableDischargeKw`, `gridFormingActive` |
| `solar` | `availableKw` |
| `flex` | `availableKw` (total permitted reduction, including any current reduction) |

`actualKw` is measured charger demand, signed battery output (positive discharge),
PV generation, or flexible-load reduction. Availability may not exceed the
inventory rating. EV energy counters are authoritative per charging session.
Counter resets are reported; proposed charging is never credited as delivered.
A departure crossed during missing feedback has an `unknown` outcome.

Supply a fresh record for every configured asset. Missing/stale feedback puts
normal dispatch on hold. No setpoint is issued for a disconnected or nonconsenting
resource. If such a resource still reports nonzero power or active grid formation,
the controller also holds dispatch: the supervisor must reconcile uncontrolled
power and the demand baseline before replanning. It never treats missing or
uncontrolled generation/load as zero to manufacture grid headroom.

A PMU frame has `timestamp` (epoch milliseconds), `frequencyHz`, `voltagePu` and
`angleDeg`. The monitor assumes 60 frames/s. The first frame batch covers the
preceding second; subsequent batches cover times after the prior observation
through the current observation. Send only observed frames; gaps and invalid
phasors remain explicit. When a collector cycle is skipped, the next fresh
packet may jump forward in both time and sequence. Reconnection dwell accumulates
verified elapsed time and resets across measurement discontinuities; fast packet
arrival cannot accelerate it.

## Dispatch and acknowledgment

`proposed_dispatch` includes observed state, a separate conditional prediction,
constraints/hold reasons, and a dispatch with a session-qualified ID. Setpoints
use types `ev_charge`, `battery`, `pv`, `flex_shed`, `grid_forming`, and `pcc`.
Numerical setpoints use `kw`; grid-forming commands use `enabled`, and PCC
commands use `position`. These are desired values, never measurements.

All coupled commands share one epoch-millisecond expiry. The lease is at most
two seconds and is shortened to the earliest actively charging EV departure.
The adapter must expire the entire dispatch together; retaining battery output
after an EV command expires can violate the shared grid constraint. Do not
replay obsolete commands after reconnecting the WAN. Energy caps allow for the
lease and conservative nameplate operation since the latest measurement.

The physical adapter validates and executes proposals under its local interlocks.
Report a device result with this command shape:

```json
{"type":"acknowledge","acknowledgment":{"sessionId":"FROM-CONFIGURE","dispatchId":"FROM-DISPATCH","assetId":"Depot/charger-A","commandType":"ev_charge","status":"applied","atMs":1790812800000,"appliedValue":5}}
```

Use actual IDs, event time and the issued value. Supported statuses are `applied`
or `rejected`; rejected commands omit `appliedValue`. Applied values must match
the issued command (numeric tolerance 0.000001). Partial acknowledgments remain
visible. Repeated identical acknowledgments are idempotent; conflicting, unknown,
expired, superseded and foreign-session acknowledgments are rejected. The runtime
counts **adapter-reported** application separately from measurements. An
acknowledgment never updates battery energy, EV delivery, PCC position, or an
observed grid-forming mode.

## Microgrid and feasibility behavior

Grid loss or a trip requests PCC opening only with a fresh open permissive.
Grid-forming enable is proposed only after fresh feedback confirms an open PCC.
The controller selects one eligible grid former, preferring one already active.
Power balancing in an island requires confirmed grid formation and an energized
bus. The adapter must implement device-specific transition sequencing and local
protection independently of these supervisory proposals.

Reconnection needs healthy contiguous PMU evidence, phase alignment, the configured
elapsed dwell and a close permissive. A close command leaves the controller
`close-pending`; only fresh feedback confirming a closed PCC establishes
`grid-connected`. A successful acknowledgment alone does not do this.

Import/export violations and island power deficits remain explicit. The prediction
sets `feasible: false` when available controls cannot meet demand. It does not
invent additional load shedding to make an infeasible grid constraint look met.
Observed PCC power is always retained separately from the proposed power balance.
The software does not prove protection coordination, transient stability or
physical sensor accuracy.

## Monitoring and bounded state

`snapshot` returns current observations and proposals. `export` includes policy,
inventory, retained commands/acknowledgments, PMU evidence and queued summaries.
When WAN is reported online, `headend_summaries` emits retained monitoring summaries
to stdout for the headend adapter. This means emitted locally, not delivered to a
headend. No actuator command is in that recovery queue. Authenticate, durably queue,
retry and confirm delivery in the transport adapter as required by the target.

The PMU ring retains 240 frames in 7,680 numeric-buffer bytes, up to eight event
snippets, and bounded event history. Adapter histories retain 32 dispatches, 80
local decisions and 24 monitoring summaries, dropping oldest summaries on overflow.
JSON frame size, resource counts and history lengths are bounded. Process RSS and
compute duration are measured in runtime responses. These values need profiling
on the actual collector; numeric-buffer size is not total runtime memory.

## Explicit simulation mode

```sh
node gateway-runner.mjs --demo
```

This generates synthetic resources/phasors and executes one modeled second per
real second. Stop with Ctrl-C. For stepwise JSONL testing configure with
`{"type":"configure","mode":"simulation","config":{"fleetSize":24}}`, then use
`simulation_step` or `simulation_action`. Scenario commands are rejected in adapter
mode, and measured telemetry is rejected in simulation mode. The website uses
this explicitly labeled simulation and does not connect to field devices.
