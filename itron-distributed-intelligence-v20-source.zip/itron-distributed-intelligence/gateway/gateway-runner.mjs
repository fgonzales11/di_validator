#!/usr/bin/env node
// Runs beside the control kernel on an AMI collector that supports Node 22+.
import {once} from 'node:events';
import {setTimeout as delay} from 'node:timers/promises';
import {randomUUID} from 'node:crypto';
import {createGateway} from './gateway-engine.mjs';
import {createAdapterGateway} from './gateway-adapter.mjs';
const demo=process.argv.includes('--demo');
let gateway=demo?createGateway():null,configured=false,sequence=0,runtimeMode=demo?'simulation':null;
const emit=async data=>{if(!process.stdout.write(JSON.stringify(data)+'\n'))await once(process.stdout,'drain')};
const reply=async(type,start)=>{const s=gateway.snapshot();await emit({type,runtimeMode,sequence:++sequence,computeMs:performance.now()-start,processRssBytes:process.memoryUsage().rss,state:{seconds:s.seconds,mode:s.mode,plan:s.plan,observed:s.observed,deadlineOutcomes:s.deadlineOutcomes,pmu:{valid:s.pmu.valid,rejected:s.pmu.rejected,missing:s.pmu.missing,meanFrequencyHz:s.pmu.meanFrequencyHz,disturbance:s.pmu.disturbance},stats:s.stats,uplink:s.uplink},dispatch:s.lastCommand})};
if(demo){
  process.on('SIGINT',()=>process.exit(0));
  while(true){const start=performance.now();gateway.step();await reply('simulation',start);await delay(Math.max(0,1000-(performance.now()-start)))}
}else{
  // JSONL uses only local stdin/stdout. Await output backpressure before reading
  // another packet; discard oversized frames without an unbounded line buffer.
  const consume=async line=>{try{
    if(Buffer.byteLength(line)>65536)throw Error('Message exceeds the 64 KiB adapter limit.');
    const message=JSON.parse(line),start=performance.now();
    if(!message||typeof message!=='object'||Array.isArray(message))throw Error('Expected a command object.');
    if(message.type==='configure'){
      if(!['simulation','adapter'].includes(message.mode))throw Error('Choose explicit mode: adapter or simulation.');
      const next=message.mode==='adapter'?createAdapterGateway({sessionId:randomUUID(),inventory:message.inventory,policy:message.config,networkId:message.networkId}):createGateway(message.config);
      gateway=next;runtimeMode=message.mode;configured=true;const s=gateway.snapshot();await emit({type:'configured',mode:runtimeMode,sessionId:s.scope.sessionId,version:s.version,limits:s.limits});return;
    }
    if(!configured)throw Error('Send configure before telemetry.');
    if(message.type==='telemetry'){
      if(runtimeMode!=='adapter')throw Error('Measured telemetry requires adapter mode.');
      gateway.step(message.telemetry);await reply('proposed_dispatch',start);
      const summaries=gateway.drainSummaries();if(summaries.length)await emit({type:'headend_summaries',delivery:'Emitted to local adapter; headend receipt unconfirmed',summaries});
    }
    else if(message.type==='acknowledge'){if(runtimeMode!=='adapter')throw Error('Device acknowledgments require adapter mode.');gateway.acknowledge(message.acknowledgment);await reply('acknowledged',start)}
    else if(message.type==='export')await emit({type:'export',data:gateway.export()});
    else if(message.type==='snapshot')await reply('snapshot',start);
    else if(message.type==='simulation_step'){if(runtimeMode!=='simulation')throw Error('Simulation commands cannot run in adapter mode.');gateway.step();await reply('simulation',start)}
    else if(message.type==='simulation_action'){if(runtimeMode!=='simulation')throw Error('Simulation commands cannot run in adapter mode.');gateway.action(message.kind,message.value);gateway.step();await reply('simulation',start)}
    else throw Error('Unknown message type.');
  }catch(error){await emit({type:'error',message:error.message})}};
  let buffer='',discard=false;
  process.stdin.setEncoding('utf8');
  for await(const chunk of process.stdin){
    for(const part of chunk.split(/(\n)/)){
      if(part==='\n'){if(!discard&&buffer.trim())await consume(buffer);buffer='';discard=false;continue}
      if(discard)continue;
      if(Buffer.byteLength(buffer)+Buffer.byteLength(part)>65536){buffer='';discard=true;await emit({type:'error',message:'Message exceeds the 64 KiB adapter limit.'})}else buffer+=part;
    }
  }
  if(!discard&&buffer.trim())await consume(buffer);
}
