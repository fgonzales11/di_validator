const PATH = '/outage-analyzer/api/street-view';
export function streetViewAPI(request, env) {
  const url = new URL(request.url);
  if (url.pathname !== PATH) return null;
  const json = (value, status = 200) => Response.json(value, {status, headers: {
    'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'
  }});
  if (request.method !== 'GET') return json({error:'Method not allowed.'}, 405);
  const latitude = url.searchParams.get('lat'), longitude = url.searchParams.get('lon');
  const lat = Number(latitude), lon = Number(longitude);
  if (!latitude?.trim() || !longitude?.trim() || !Number.isFinite(lat) || !Number.isFinite(lon) ||
      Math.abs(lat) > 90 || Math.abs(lon) > 180) return json({error:'Choose a valid map location.'}, 400);
  const key = env.MAPS_EMBED_KEY || env.GOOGLE_MAPS_EMBED_API_KEY;
  if (!key) return json({error:'Street View is temporarily unavailable. Open this location in Google Maps.'}, 503);
  // Browser-visible key shared with Transformer Analyzer's Google 3D map.
  // Restrict it to the required Maps APIs and this site's HTTP referrers.
  const embed = new URL('https://www.google.com/maps/embed/v1/streetview');
  embed.search = new URLSearchParams({
    key, location:lat.toFixed(6)+','+lon.toFixed(6),
    source:'outdoor', radius:'100'
  });
  return json({url:embed.href});
}
