import test from 'node:test';
import assert from 'node:assert/strict';
import gateway from './index.mjs';
const request=method=>new Request('https://ppgui.com/transformer-analyzer/api/maps-config',{method});
test('Google 3D reuses only the configured browser Maps key and prevents caching',async()=>{
  const response=await gateway.fetch(request('GET'),{MAPS_EMBED_KEY:'test-key',GOOGLE_MAPS_EMBED_API_KEY:'old',OTHER_SECRET:'not-public'});
  assert.equal(response.status,200);
  assert.equal(response.headers.get('cache-control'),'no-store');
  assert.deepEqual(await response.json(),{apiKey:'test-key'});
  const fallback=await gateway.fetch(request('GET'),{GOOGLE_MAPS_EMBED_API_KEY:'legacy'});
  assert.deepEqual(await fallback.json(),{apiKey:'legacy'});
});
test('Maps configuration rejects writes and reports a missing key explicitly',async()=>{
  assert.equal((await gateway.fetch(request('POST'),{MAPS_EMBED_KEY:'test'})).status,405);
  assert.equal((await gateway.fetch(request('GET'),{})).status,503);
});
