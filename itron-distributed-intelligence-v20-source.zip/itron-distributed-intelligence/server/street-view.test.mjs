import test from 'node:test';
import assert from 'node:assert/strict';
import gateway from './index.mjs';
const get = (query, env = {}, method = 'GET') => gateway.fetch(new Request('https://ppgui.com/outage-analyzer/api/street-view'+query,{method}),env);
test('Street View uses the selected coordinates and runtime Embed key without contacting the simulation backend', async t => {
  t.mock.method(globalThis,'fetch',()=>assert.fail('No upstream request is needed'));
  const response = await get('?lat=27.905179&lon=-82.496074',{GOOGLE_MAPS_EMBED_API_KEY:'test-embed-key',BACKEND_ORIGIN:'https://backend.example'});
  assert.equal(response.status,200);
  assert.equal(response.headers.get('cache-control'),'no-store');
  const url = new URL((await response.json()).url);
  assert.equal(url.origin,'https://www.google.com');
  assert.equal(url.pathname,'/maps/embed/v1/streetview');
  assert.equal(url.searchParams.get('location'),'27.905179,-82.496074');
  assert.equal(url.searchParams.get('key'),'test-embed-key');
  assert.equal(url.searchParams.get('source'),'outdoor');
});
test('Street View rejects invalid coordinates and writes, and reports missing configuration explicitly', async () => {
  for (const query of ['', '?lat=&lon=0', '?lat=91&lon=0', '?lat=0&lon=-181', '?lat=NaN&lon=0']) {
    assert.equal((await get(query)).status,400);
  }
  assert.equal((await get('?lat=0&lon=0')).status,503);
  assert.equal((await get('?lat=0&lon=0',{},'POST')).status,405);
});


test('profile MAPS_EMBED_KEY is supported and preferred over the legacy alias', async () => {
  const response=await get('?lat=37.543216&lon=-121.858489',{MAPS_EMBED_KEY:'profile-test-key',GOOGLE_MAPS_EMBED_API_KEY:'legacy-test-key'});
  const url=new URL((await response.json()).url);
  assert.equal(response.status,200);assert.equal(url.searchParams.get('key'),'profile-test-key');
});
