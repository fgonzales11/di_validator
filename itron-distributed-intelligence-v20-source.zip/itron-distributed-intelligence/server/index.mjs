import {streetViewAPI} from './street-view.mjs';
import {mapsConfigAPI} from './maps-config.mjs';
const pages = typeof __CLIENT_PAGES__ === 'undefined' ? {} : __CLIENT_PAGES__;
export default {
  async fetch(request, env) {
    const response = streetViewAPI(request, env) || mapsConfigAPI(request, env);
    if (response) return response;
    const path = new URL(request.url).pathname;
    const page = pages[path];
    if (page && ['GET','HEAD'].includes(request.method)) {
      return new Response(request.method==='HEAD'?null:page, {headers:{
        'Content-Type':'text/html; charset=utf-8', 'Cache-Control':'no-cache',
        'X-Content-Type-Options':'nosniff'
      }});
    }
    if (env.ASSETS) return env.ASSETS.fetch(request);
    return new Response('Not found', {status:404});
  }
};
