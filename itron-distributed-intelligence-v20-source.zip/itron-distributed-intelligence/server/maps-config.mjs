export function mapsConfigAPI(request, env) {
  if (new URL(request.url).pathname !== '/transformer-analyzer/api/maps-config') return null;
  const headers = {'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff'};
  if (request.method !== 'GET') return Response.json({error:'Method not allowed.'}, {status:405, headers});
  const apiKey = env.MAPS_EMBED_KEY || env.GOOGLE_MAPS_EMBED_API_KEY;
  if (!apiKey) return Response.json({error:'The Google Maps key is not configured.'}, {status:503, headers});
  // Maps JavaScript keys are browser-visible. Reuse the configured Street View
  // key; Google Cloud controls allowed APIs and website referrers.
  return Response.json({apiKey}, {headers});
}
